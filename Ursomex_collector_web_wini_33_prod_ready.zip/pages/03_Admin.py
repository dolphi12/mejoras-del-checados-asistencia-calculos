from __future__ import annotations

import os
import json
from datetime import datetime

import streamlit as st

from collector.config import load_config
from components.layout import render_topbar, section_header
from components.auth_ui import login_panel, current_user
from components.sidebar_settings import render_sidebar_settings
from utils.page_bootstrap import bootstrap_page
from utils.auth_store import (
    append_audit,
    delete_user,
    get_audit,
    list_users,
    set_password,
    upsert_user,
)
from utils.config_manager import load_raw_config, list_backups, restore_backup, update_config
from utils.runtime_store import get_cfg_path, get_data_dir
from utils.attendance_rules import load_rules, save_rules, AttendanceRules
from utils.audit_log import tail_events, audit_path
from utils.areas_store import (
    add_members,
    delete_area,
    ensure_default_areas,
    list_areas,
    remove_member,
    remove_member_everywhere,
    upsert_area,
)


def _store_path(data_dir: str) -> str:
    return os.path.join(data_dir, "web_users.json")


def render():
    bootstrap_page("Admin | URSOMEX", page_icon="🔐")

    render_sidebar_settings()

    data_dir = get_data_dir()
    login_panel(data_dir)

    u = current_user()
    if not u:
        st.warning("Inicia sesión.")
        return
    if u.role != "admin":
        st.error("Acceso restringido: requiere rol admin.")
        return

    store_path = _store_path(data_dir)

    render_topbar("Admin", "Usuarios, roles, parámetros y auditoría.")
    
    st.caption("Gestiona usuarios y parámetros sin tocar el código del collector.")

    tabs = st.tabs(["Usuarios", "Config", "Áreas", "Asistencia", "Auditoría"])

    # --- Users ---
    with tabs[0]:
        st.subheader("Usuarios")
        users = list_users(store_path)
        if users:
            st.dataframe(
                [
                    {
                        "username": k,
                        "role": v.get("role"),
                        "disabled": v.get("disabled"),
                        "must_change_password": v.get("must_change_password"),
                        "created_at_utc": v.get("created_at_utc"),
                        "updated_at_utc": v.get("updated_at_utc"),
                    }
                    for k, v in sorted(users.items())
                ],
                width="stretch",
                height=260,
            )
        else:
            st.info("No hay usuarios.")

        st.markdown("#### Alta / edición")
        c1, c2, c3 = st.columns(3)
        with c1:
            username = st.text_input("Usuario", value="")
        with c2:
            role = st.selectbox("Rol", ["admin", "operator", "viewer"], index=1)
        with c3:
            disabled = st.checkbox("Deshabilitado", value=False)

        password = st.text_input("Contraseña (opcional)", type="password", value="")
        if st.button("Guardar usuario", width="stretch"):
            if not username.strip():
                st.error("Usuario requerido")
            else:
                upsert_user(store_path, username.strip(), role=role, password=(password if password else None), disabled=disabled)
                append_audit(store_path, u.username, "upsert_user", {"username": username.strip(), "role": role, "disabled": disabled})
                st.success("OK")
                st.rerun()

        st.markdown("#### Acciones")
        target = st.selectbox("Selecciona usuario", [""] + sorted(users.keys()))
        cA, cB, cC = st.columns(3)
        with cA:
            new_pw = st.text_input("Reset contraseña", type="password", key="reset_pw")
            if st.button("Aplicar reset", width="stretch", disabled=not target or not new_pw):
                set_password(store_path, target, new_pw, require_change=True)
                append_audit(store_path, u.username, "reset_password", {"username": target})
                st.success("OK")
                st.rerun()
        with cB:
            if st.button("Forzar cambio contraseña", width="stretch", disabled=not target):
                # set require_change without changing hash: do a read/merge by setting same password is not possible
                # we mark it by setting password to itself isn't available; instead we upsert without password and set must_change via store manipulation is not exposed.
                st.info("Usa 'Reset contraseña' para forzar cambio en el siguiente login.")
        with cC:
            if st.button("Eliminar usuario", width="stretch", disabled=not target):
                if target == u.username:
                    st.error("No puedes eliminar tu propio usuario desde tu sesión.")
                else:
                    delete_user(store_path, target)
                    append_audit(store_path, u.username, "delete_user", {"username": target})
                    st.success("OK")
                    st.rerun()

    # --- Config ---
    with tabs[1]:
        st.subheader("Config")
        st.caption("Archivo config.json del collector.")
        cfg_path = get_cfg_path()
        st.markdown(f"**Ruta:** `{cfg_path}`")

        raw = load_raw_config(cfg_path)
        if not raw:
            st.error("No se pudo leer config.json")
        else:
            cfg = load_config(cfg_path)

            st.markdown("#### Parámetros operativos")
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                shift_cutoff = st.text_input("operation.shift_cutoff (HH:MM)", value=str(cfg.operation.get("shift_cutoff") or "03:00"))
            with c2:
                break_max = st.number_input("export.break_max_minutes", min_value=1, max_value=600, value=int(cfg.export.get("break_max_minutes") or 75))
            with c3:
                rest_min = st.number_input("export.min_rest_between_shifts_minutes", min_value=1, max_value=1440, value=int(cfg.export.get("min_rest_between_shifts_minutes") or 240))
            with c4:
                debounce = st.number_input("export.debounce_minutes", min_value=0, max_value=60, value=int(cfg.export.get("debounce_minutes") or 3))

            c5, c6 = st.columns(2)
            with c5:
                max_shift = st.number_input("export.max_shift_hours", min_value=1, max_value=72, value=int(cfg.export.get("max_shift_hours") or 24))
            with c6:
                lookahead = st.text_input("export.close_lookahead_hhmm", value=str(cfg.export.get("close_lookahead_hhmm") or "12:00"))

            hc = cfg.export.get("hybrid_close") or {}
            st.markdown("#### Hybrid close / aprendizaje")
            c7, c8, c9 = st.columns(3)
            with c7:
                hc_enabled = st.checkbox("hybrid_close.enabled", value=bool(hc.get("enabled", False)))
            with c8:
                fp_window = st.number_input("anti_fp_window_minutes", min_value=1, max_value=180, value=int(hc.get("anti_fp_window_minutes") or 30))
            with c9:
                max_duration = st.number_input("max_join_shift_hours", min_value=1, max_value=72, value=int(hc.get("max_join_shift_hours") or 16))

            adv = (hc.get("advanced_learning") or {})
            c10, c11, c12 = st.columns(3)
            with c10:
                adv_enabled = st.checkbox("advanced_learning.enabled", value=bool(adv.get("enabled", False)))
            with c11:
                audit_enabled = st.checkbox("advanced_learning.audit.enabled", value=bool((adv.get("audit") or {}).get("enabled", False)))
            with c12:
                audit_export_excel = st.checkbox("advanced_learning.audit.export_excel", value=bool((adv.get("audit") or {}).get("export_excel", False)))

            if st.button("Guardar cambios", width="stretch"):
                patch = {
                    "operation": {"shift_cutoff": shift_cutoff.strip() or "03:00"},
                    "export": {
                        "break_max_minutes": int(break_max),
                        "min_rest_between_shifts_minutes": int(rest_min),
                        "debounce_minutes": int(debounce),
                        "max_shift_hours": int(max_shift),
                        "close_lookahead_hhmm": lookahead.strip() or "12:00",
                        "hybrid_close": {
                            **(hc or {}),
                            "enabled": bool(hc_enabled),
                            "anti_fp_window_minutes": int(fp_window),
                            "max_join_shift_hours": int(max_duration),
                            "advanced_learning": {
                                **(adv or {}),
                                "enabled": bool(adv_enabled),
                                "audit": {
                                    **((adv.get("audit") or {}) if isinstance(adv, dict) else {}),
                                    "enabled": bool(audit_enabled),
                                    "export_excel": bool(audit_export_excel),
                                },
                            },
                        },
                    },
                }
                bak, _ = update_config(cfg_path, patch)
                append_audit(store_path, u.username, "update_config", {"backup": bak, "patch": patch})
                st.success(f"OK. Backup: {bak or '—'}")

            st.markdown("#### Patch JSON")
            st.caption("Aplica un deep-merge sobre el config actual (se hace backup).")
            patch_text = st.text_area("JSON", value="{\n  \"export\": {\n    \"hybrid_close\": {\n      \"enabled\": true\n    }\n  }\n}", height=180)
            if st.button("Aplicar patch JSON", width="stretch"):
                try:
                    patch = json.loads(patch_text)
                    if not isinstance(patch, dict):
                        raise ValueError("Patch debe ser objeto JSON")
                    bak, _ = update_config(cfg_path, patch)
                    append_audit(store_path, u.username, "update_config_patch", {"backup": bak})
                    st.success(f"OK. Backup: {bak or '—'}")
                except Exception as e:
                    st.error(f"Patch inválido: {e}")

            st.markdown("#### Rollback")
            baks = list_backups(cfg_path)
            if not baks:
                st.info("No hay backups")
            else:
                sel = st.selectbox("Selecciona backup", baks)
                if st.button("Restaurar", width="stretch"):
                    restore_backup(cfg_path, sel)
                    append_audit(store_path, u.username, "restore_backup", {"backup": sel})
                    st.success("OK")

    # --- Areas ---
    with tabs[2]:
        st.subheader("Áreas / Grupos")
        st.caption("Permite agrupar employee_id por área para filtrar/ordenar exports sin tocar el collector.")

        ensure_default_areas(data_dir)
        areas = list_areas(data_dir)

        if areas:
            st.dataframe(
                [
                    {
                        "code": a.get("code"),
                        "name": a.get("name"),
                        "order": a.get("order"),
                        "members": len(a.get("members") or []),
                    }
                    for a in areas
                ],
                width="stretch",
                height=240,
            )
        else:
            st.info("Sin áreas.")

        st.markdown("#### Crear / editar")
        c1, c2, c3 = st.columns(3)
        with c1:
            code = st.text_input("Code (ej: 000-, F-, FT-)", value="")
        with c2:
            name = st.text_input("Nombre", value="")
        with c3:
            order = st.number_input("Orden", min_value=0, max_value=100000, value=10)

        colS, colD = st.columns(2)
        with colS:
            if st.button("Guardar área", width="stretch"):
                try:
                    upsert_area(data_dir, code=code.strip(), name=(name.strip() or None), order=int(order))
                    append_audit(store_path, u.username, "upsert_area", {"code": code.strip(), "name": name.strip(), "order": int(order)})
                    st.success("OK")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")
        with colD:
            del_code = st.selectbox("Eliminar", [""] + [str(a.get("code")) for a in areas])
            if st.button("Eliminar área", width="stretch", disabled=not del_code):
                delete_area(data_dir, del_code)
                append_audit(store_path, u.username, "delete_area", {"code": del_code})
                st.success("OK")
                st.rerun()

        st.divider()
        st.markdown("#### Miembros")
        st.caption("Employee_id por área (web_areas.json).")

        area_sel = st.selectbox("Área", [""] + [str(a.get("code")) for a in areas])
        if area_sel:
            members = next((a.get("members") or [] for a in areas if str(a.get("code")) == area_sel), [])
            st.caption(f"Miembros: {len(members)}")
            if members:
                st.code(", ".join([str(x) for x in members][:80]) + (" …" if len(members) > 80 else ""))

            ids_txt = st.text_area("Agregar IDs (coma/espacio/nueva línea)", value="", height=90)
            unique = st.checkbox("Un ID solo puede pertenecer a 1 área", value=True)

            def _parse_ids(txt: str):
                if not txt:
                    return []
                txt = txt.replace("\n", ",").replace(" ", ",").replace(";", ",")
                return [x.strip() for x in txt.split(",") if x.strip()]

            if st.button("Agregar IDs", width="stretch"):
                try:
                    ids = _parse_ids(ids_txt)
                    info = add_members(data_dir, area_sel, ids, unique_across_areas=bool(unique))
                    append_audit(store_path, u.username, "add_area_members", {"area": area_sel, "added": info.get("added"), "moved": info.get("moved")})
                    st.success(f"OK | added={len(info.get('added') or [])} | moved={len(info.get('moved') or [])}")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")

            cR1, cR2 = st.columns(2)
            with cR1:
                rm_id = st.text_input("Quitar ID de esta área", value="")
                if st.button("Quitar", width="stretch", disabled=not rm_id.strip()):
                    ok = remove_member(data_dir, area_sel, rm_id.strip())
                    append_audit(store_path, u.username, "remove_area_member", {"area": area_sel, "employee_id": rm_id.strip(), "ok": bool(ok)})
                    st.success("OK" if ok else "No estaba")
                    st.rerun()
            with cR2:
                rm_all = st.text_input("Quitar ID de TODAS las áreas", value="", key="rm_all")
                if st.button("Quitar de todas", width="stretch", disabled=not rm_all.strip()):
                    removed = remove_member_everywhere(data_dir, rm_all.strip())
                    append_audit(store_path, u.username, "remove_area_member_everywhere", {"employee_id": rm_all.strip(), "removed_from": removed})
                    st.success(f"OK | removed_from={removed}")
                    st.rerun()

    # --- Audit ---

    # --- Attendance Rules ---
    with tabs[3]:
        st.subheader("Asistencia | Reglas")
        st.caption("Parámetros del módulo de cálculo de asistencia (web). No afecta al collector.")
        rules = load_rules(data_dir)
        with st.form("admin_att_rules"):
            lm = st.selectbox(
                "Regla comida",
                options=["fixed_if_within_else_full", "full", "none"],
                index=["fixed_if_within_else_full", "full", "none"].index(rules.lunch_mode),
            )
            thr = st.number_input("Umbral comida (min)", min_value=0, max_value=600, value=int(rules.lunch_threshold_minutes), step=1)
            fixed = st.number_input("Descuento fijo comida si cumple umbral (min)", min_value=0, max_value=600, value=int(rules.lunch_discount_minutes_if_within), step=1)
            inc = st.checkbox("Umbral inclusivo (≤)", value=bool(rules.lunch_threshold_inclusive))
            dinner_apply = st.checkbox("Descontar cena completo", value=bool(rules.apply_dinner_deduction))
            perm_apply = st.checkbox("Descontar permisos", value=bool(rules.apply_permissions_deduction))
            ot_apply = st.checkbox("Calcular horas extra", value=bool(rules.compute_overtime))
            ot_thr_h = st.number_input("Umbral horas extra (horas)", min_value=0.0, max_value=24.0, value=float(rules.overtime_threshold_minutes)/60.0, step=0.25)
            clamp = st.checkbox("No permitir neto negativo", value=bool(rules.clamp_negative_to_zero))
            cA, cB, cC = st.columns(3)
            save_btn = cA.form_submit_button("Guardar", type="primary")
            reset_btn = cB.form_submit_button("Reset")
            show_btn = cC.form_submit_button("Ver JSON")

        if save_btn or reset_btn:
            if reset_btn:
                new_rules = AttendanceRules()
            else:
                new_rules = AttendanceRules(
                    lunch_threshold_minutes=int(thr),
                    lunch_discount_minutes_if_within=int(fixed),
                    lunch_threshold_inclusive=bool(inc),
                    lunch_mode=str(lm),
                    apply_dinner_deduction=bool(dinner_apply),
                    apply_permissions_deduction=bool(perm_apply),
                    overtime_threshold_minutes=int(round(float(ot_thr_h) * 60)),
                    compute_overtime=bool(ot_apply),
                    clamp_negative_to_zero=bool(clamp),
                )
            save_rules(data_dir, new_rules)
            append_audit(store_path, u.username, "update_attendance_rules", new_rules.to_dict())
            st.success("Reglas guardadas.")

        if show_btn:
            st.code(json.dumps(load_rules(data_dir).to_dict(), ensure_ascii=False, indent=2), language="json")

    with tabs[4]:
        st.subheader("Auditoría")
        mode = st.radio("Fuente", options=["Accesos y Admin (usuarios)", "Asistencia (ediciones/export)"], horizontal=True)

        if mode == "Accesos y Admin (usuarios)":
            rows = get_audit(store_path)
            if not rows:
                st.info("Sin auditoría")
            else:
                st.dataframe(list(reversed(rows)), width="stretch", height=420)
        else:
            st.caption("Registro append-only (JSONL). Incluye cambios por celda, permisos detallados, cambios de reglas y exportaciones.")
            limit = st.slider("Mostrar últimos N eventos", min_value=50, max_value=2000, value=500, step=50)
            events = tail_events(data_dir, limit=limit, name="attendance_audit.jsonl")

            if not events:
                st.info("Sin eventos de auditoría de asistencia.")
            else:
                # filtros básicos
                actors = sorted({str(e.get("actor","")) for e in events if e.get("actor")})
                actions = sorted({str(e.get("action","")) for e in events if e.get("action")})
                c1, c2, c3 = st.columns([1,1,2])
                f_actor = c1.selectbox("Actor", options=["(todos)"] + actors, index=0)
                f_action = c2.selectbox("Acción", options=["(todas)"] + actions, index=0)
                q = c3.text_input("Buscar (ID/FECHA/archivo)", value="")

                filtered = []
                qn = q.strip().lower()
                for e in events[::-1]:
                    if f_actor != "(todos)" and str(e.get("actor","")) != f_actor:
                        continue
                    if f_action != "(todas)" and str(e.get("action","")) != f_action:
                        continue
                    if qn:
                        blob = json.dumps(e, ensure_ascii=False).lower()
                        if qn not in blob:
                            continue
                    filtered.append(e)

                st.dataframe(filtered, width="stretch", height=420)

                p = audit_path(data_dir, name="attendance_audit.jsonl")
                if os.path.isfile(p):
                    with open(p, "rb") as f:
                        st.download_button("Descargar JSONL", data=f.read(), file_name="attendance_audit.jsonl", mime="application/json")


if __name__ == "__main__":
    render()