from __future__ import annotations

import os
import json
import uuid
from datetime import datetime
import tempfile

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

# Tabla editable tipo Excel (búsqueda, filtros, vista amplia)
try:
    from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode, DataReturnMode, JsCode
except Exception:
    AgGrid = None
    GridOptionsBuilder = None
    GridUpdateMode = None
    DataReturnMode = None
    JsCode = None


from components.layout import render_topbar, section_header
from components.auth_ui import login_panel, current_user
from components.area_filter import render_area_filter
from components.sidebar_settings import render_sidebar_settings
from components.ui import kpi_card
from utils.page_bootstrap import bootstrap_page
from utils.runtime_store import get_data_dir
from utils.attendance_calc import build_attendance_table_from_export_xlsx, recalc_attendance_table, recalc_attendance_rows, autodetect_permiso_detail_from_eventos
from utils.attendance_rules import load_rules, save_rules, AttendanceRules
from utils.attendance_export import export_attendance_excel, DEFAULT_COLUMNS
from utils.audit_log import ensure_session_id, append_event, compute_row_changes


def _list_export_files(exports_dir: str):
    if not os.path.isdir(exports_dir):
        return []
    items = []
    for fn in os.listdir(exports_dir):
        if fn.lower().endswith(".xlsx") and not fn.startswith("~$"):
            p = os.path.join(exports_dir, fn)
            try:
                mt = os.path.getmtime(p)
            except Exception:
                mt = 0
            items.append((fn, p, mt))
    items.sort(key=lambda x: x[2], reverse=True)
    return items


@st.cache_data(show_spinner=False)
def _load_attendance_from_xlsx(path: str, rules_json: str) -> pd.DataFrame:
    d = json.loads(rules_json) if rules_json else {}
    return build_attendance_table_from_export_xlsx(path, rules=AttendanceRules.from_dict(d))


def _apply_id_filter(df: pd.DataFrame, employee_ids: list[str]) -> pd.DataFrame:
    if not employee_ids:
        return df
    s = set([str(x).strip() for x in employee_ids if str(x).strip()])
    if not s:
        return df
    return df[df["ID"].astype(str).isin(s)].copy()


def _init_state(df: pd.DataFrame):
    st.session_state["asist_df"] = df.copy()


def _get_state_df() -> pd.DataFrame:
    df = st.session_state.get("asist_df")
    if isinstance(df, pd.DataFrame):
        return df
    return pd.DataFrame()

# --- Persistencia y auditoría de ediciones ---
def _load_overrides(data_dir: str):
    """
    Carga overrides desde un archivo JSONL en data_dir.
    Devuelve un mapa overrides { (ID, FECHA): {campo: valor} },
    la lista de registros de auditoría y la ruta del archivo y su mtime.
    """
    overrides_map: dict[tuple[str,str], dict[str,str]] = {}
    history = []
    overrides_file = os.path.join(data_dir, "attendance_overrides.jsonl")
    mtime = None
    try:
        if os.path.exists(overrides_file):
            mtime = os.path.getmtime(overrides_file)
            with open(overrides_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except Exception:
                        continue
                    id_ = str(rec.get("ID") or "").strip()
                    fecha = str(rec.get("FECHA") or "").strip()
                    if not id_ or not fecha:
                        continue
                    key = (id_, fecha)
                    chgs = rec.get("changes") or {}
                    for c, detail in chgs.items():
                        # Para overrides persistimos el valor "to"
                        overrides_map.setdefault(key, {})[c] = detail.get("to")
                    history.append(rec)
    except Exception:
        pass
    return overrides_map, history, overrides_file, mtime

def _append_override_record(data_dir: str, record: dict) -> None:
    """Añade un registro de override a attendance_overrides.jsonl."""
    overrides_file = os.path.join(data_dir, "attendance_overrides.jsonl")
    try:
        with open(overrides_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass

def _export_df_to_excel(df: pd.DataFrame, filename_prefix: str = "attendance_view") -> str:
    """
    Exporta un DataFrame a un archivo Excel temporal y devuelve la ruta.
    No aplica estilos complejos; solo columnas visibles.
    """
    if df is None or len(df) == 0:
        raise ValueError("DataFrame vacío")
    temp_dir = tempfile.mkdtemp(prefix="asist_export_")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = os.path.join(temp_dir, f"{filename_prefix}_{timestamp}.xlsx")
    try:
        # Utiliza pandas para exportar rápidamente
        df.to_excel(out_path, index=False)
    except Exception:
        # intento de fallback: sin estilos
        df.to_excel(out_path, index=False)
    return out_path

def _build_filtered_view(df: pd.DataFrame, show_cols: list[str], search_id: str, search_name: str, only_alert: bool) -> pd.DataFrame:
    """Construye la vista filtrada sobre el estado actual."""
    df_view = df[show_cols].copy()
    if search_id:
        df_view = df_view[df_view["ID"].astype(str).str.contains(str(search_id).strip(), case=False, na=False)]
    if search_name:
        df_view = df_view[df_view["NOMBRE"].astype(str).str.contains(str(search_name).strip(), case=False, na=False)]
    if only_alert and "_ALERTA" in df_view.columns:
        df_view = df_view[df_view["_ALERTA"].astype(str).str.strip() != ""]
    return df_view

def main():
    bootstrap_page("Cálculo de Asistencia | URSOMEX", page_icon="🧮")

    render_sidebar_settings()

    data_dir = get_data_dir()
    login_panel(data_dir)

    u = current_user()
    ensure_session_id(st.session_state)
    if not u:
        st.warning("Inicia sesión para usar esta sección.")
        return

    render_topbar("Cálculo de Asistencia", "Procesa eventos exportados, edita y exporta a Excel.")
    
    st.caption("Selecciona un Excel exportado por el Colector y genera una tabla de asistencia editable con recálculo en tiempo real.")

    # --- Reglas de cálculo (persistentes, editables por admin) ---
    if "attendance_rules" not in st.session_state:
        st.session_state["attendance_rules"] = load_rules(data_dir).to_dict()
    rules_dict = dict(st.session_state.get("attendance_rules") or {})
    rules_json = json.dumps(rules_dict, ensure_ascii=False, sort_keys=True)
    rules = AttendanceRules.from_dict(rules_dict)

    if u.role == "admin":
        with st.sidebar.expander("Reglas de cálculo (Asistencia)", expanded=False):
            st.markdown("Ajusta parámetros sin tocar código. Cambios se aplican al recálculo en esta pantalla.")
            with st.form("rules_form"):
                lm = st.selectbox(
                    "Regla comida",
                    options=["fixed_if_within_else_full", "full", "none"],
                    index=["fixed_if_within_else_full", "full", "none"].index(rules.lunch_mode),
                    help="fixed_if_within_else_full = ≤umbral descuenta fijo, si excede descuenta completo.",
                )
                thr = st.number_input("Umbral comida (min)", min_value=0, max_value=600, value=int(rules.lunch_threshold_minutes), step=1)
                fixed = st.number_input("Descuento fijo comida si cumple umbral (min)", min_value=0, max_value=600, value=int(rules.lunch_discount_minutes_if_within), step=1)
                inc = st.checkbox("Umbral inclusivo (≤)", value=bool(rules.lunch_threshold_inclusive))
                dinner_apply = st.checkbox("Descontar cena completo", value=bool(rules.apply_dinner_deduction))
                perm_apply = st.checkbox("Descontar permisos", value=bool(rules.apply_permissions_deduction))
                ot_apply = st.checkbox("Calcular horas extra", value=bool(rules.compute_overtime))
                ot_thr_h = st.number_input("Umbral horas extra (horas)", min_value=0.0, max_value=24.0, value=float(rules.overtime_threshold_minutes)/60.0, step=0.25)
                clamp = st.checkbox("No permitir neto negativo", value=bool(rules.clamp_negative_to_zero))
                cA, cB, cC = st.columns(3)
                apply_btn = cA.form_submit_button("Aplicar", type="primary")
                save_btn = cB.form_submit_button("Guardar")
                reset_btn = cC.form_submit_button("Reset")

            if apply_btn or save_btn or reset_btn:
                before_rules = dict(st.session_state.get('attendance_rules') or {})
                if reset_btn:
                    new_rules = AttendanceRules()
                else:
                    new_rules = AttendanceRules(
                        lunch_threshold_minutes=int(thr),
                        lunch_discount_minutes_if_within=int(fixed),
                        lunch_threshold_inclusive=bool(inc),
                        lunch_mode=str(lm),
                        apply_dinner_deduction=bool(dinner_apply),
                        apply_permissions_deduction=bool(perm_apply),
                        overtime_threshold_minutes=int(round(float(ot_thr_h) * 60)),
                        compute_overtime=bool(ot_apply),
                        clamp_negative_to_zero=bool(clamp),
                    )
                st.session_state["attendance_rules"] = new_rules.to_dict()
                after_rules = new_rules.to_dict()
                try:
                    append_event(data_dir, {
                        'category': 'attendance',
                        'action': 'rules_change',
                        'actor': u.username,
                        'role': u.role,
                        'session_id': st.session_state.get('session_id'),
                        'details': {
                            'trigger': 'reset' if reset_btn else ('save' if save_btn else 'apply'),
                            'before': before_rules,
                            'after': after_rules,
                        },
                    }, name='attendance_audit.jsonl')
                except Exception:
                    pass
                if save_btn or reset_btn:
                    save_rules(data_dir, new_rules)
                # fuerza recarga/recalc
                st.session_state.pop("asist_df_src", None)
                st.rerun()

    exports_dir = os.path.join(data_dir, "exports")
    files = _list_export_files(exports_dir)

    c1, c2 = st.columns([2, 1])
    with c1:
        st.markdown("#### 1) Seleccionar archivo origen")
        st.caption("Archivos XLSX en la carpeta exports del collector.")
        if files:
            labels = [f"{fn}  —  {datetime.fromtimestamp(mt).strftime('%Y-%m-%d %H:%M:%S')}" for fn, _, mt in files]
            idx = st.selectbox("Archivo", options=list(range(len(files))), format_func=lambda i: labels[i], index=0, key="asist_src_sel")
            src_path = files[idx][1]
        else:
            st.info("No se encontraron .xlsx en la carpeta de exports. Puedes subir uno manualmente.")
            src_path = ""
        up = st.file_uploader("O subir un Excel (.xlsx) exportado por el colector", type=["xlsx"], key="asist_upload")
        if up is not None:
            tmp_dir = os.path.join(data_dir, "tmp")
            os.makedirs(tmp_dir, exist_ok=True)
            src_path = os.path.join(tmp_dir, f"upload_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
            with open(src_path, "wb") as f:
                f.write(up.getbuffer())
            st.success("Archivo cargado para procesar.")
    with c2:
        st.markdown("#### 2) Filtro por Áreas / IDs")
        flt = render_area_filter(
            st,
            data_dir=data_dir,
            key_prefix="asistencia__",
            show_manual_ids=True,
            default_order_by_area=True,
        )
        filter_active = bool(flt["filter_active"])
        employee_ids = list(flt["employee_ids"])
        order_ids = employee_ids if bool(flt["order_in_export"]) else []

    if not src_path:
        return

    try:
        base_df = _load_attendance_from_xlsx(src_path, rules_json)
    except Exception as e:
        st.error(f"No se pudo leer el archivo: {e}")
        return

    # ------------------------------------------------------------------
    # Opcional: ignorar el recálculo inicial de métricas
    #
    # Por defecto, build_attendance_table_from_export_xlsx calcula las
    # columnas "DESCUENTO NO LABORADO", "TIEMPO TRABAJADO" y "HORAS EXTRA"
    # en el momento de cargar el archivo.  Si se desea permitir al
    # usuario editar horarios sin recalcular de inmediato, se vacían
    # estas columnas aquí.  De esa manera, los valores actualizados se
    # obtendrán únicamente al presionar "Recalcular" o al exportar.
    for _col in ["DESCUENTO NO LABORADO", "TIEMPO TRABAJADO", "HORAS EXTRA", "_ALERTA"]:
        if _col in base_df.columns:
            try:
                base_df[_col] = ""
            except Exception:
                pass

    if filter_active:
        base_df = _apply_id_filter(base_df, employee_ids)
        if order_ids:
            base_df["_ORDER"] = base_df["ID"].astype(str).apply(lambda x: order_ids.index(x) if x in order_ids else 10**9)
            base_df = base_df.sort_values(["FECHA", "_ORDER", "ID"], kind="stable").drop(columns=["_ORDER"])

    # --- Cargar overrides persistentes y aplicarlos al DataFrame base ---
    overrides_map, overrides_history, overrides_file_path, overrides_mtime = _load_overrides(data_dir)
    if overrides_map:
        # Aplicamos cada override al DataFrame base
        try:
            for (oid, ofecha), chg in overrides_map.items():
                mask = (base_df.get("ID", "").astype(str) == str(oid)) & (base_df.get("FECHA", "").astype(str) == str(ofecha))
                if mask.any():
                    for col, val in chg.items():
                        if col in base_df.columns:
                            # Guardamos como NA si el valor es vacío
                            base_df.loc[mask, col] = val if val not in ("", None) else pd.NA
        except Exception:
            pass
    # Guardar overrides en estado para referencia posterior (auditoría, estilo)
    st.session_state["asist_overrides_map"] = overrides_map
    st.session_state["asist_overrides_history"] = overrides_history
    st.session_state["asist_overrides_mtime"] = overrides_mtime

    if "asist_df_src" not in st.session_state or st.session_state.get("asist_df_src") != src_path:
        _init_state(base_df)
        st.session_state["asist_df_src"] = src_path

    st.markdown("#### 3) Tabla editable")
    st.caption("Edita horas y el recálculo se aplica al momento. La búsqueda filtra solo la vista.")
    df_state = _get_state_df()
    # Marcar filas editadas previamente (overrides) para resaltado
    try:
        overrides_map_state = st.session_state.get("asist_overrides_map") or {}
        if overrides_map_state:
            df_state["_CHANGED"] = df_state.apply(lambda r: (str(r.get("ID", "")).strip(), str(r.get("FECHA", "")).strip()) in overrides_map_state, axis=1)
        else:
            df_state["_CHANGED"] = False
    except Exception:
        # Si falla, asignar False
        df_state["_CHANGED"] = False
    if df_state.empty:
        st.info("No hay filas para procesar con el filtro actual.")
        return

    def _hhmm_to_min(x: str) -> int:
        s = str(x or "").strip()
        if not s or s == "—":
            return 0
        try:
            h, m = s.split(":")
            return int(h) * 60 + int(m)
        except Exception:
            return 0

    try:
        total_rows = int(len(df_state))
        total_emp = int(df_state["ID"].astype(str).nunique())
        total_days = int(df_state["FECHA"].astype(str).nunique())
        total_worked_min = int(df_state.get("TIEMPO TRABAJADO", "").apply(_hhmm_to_min).sum())
        total_ot_min = int(df_state.get("HORAS EXTRA", "").apply(_hhmm_to_min).sum())
        if "_ALERTA" in df_state.columns:
            s_alert = df_state["_ALERTA"].astype(str).fillna("").str.strip()
            s_alert = s_alert.replace({"nan": "", "None": ""})
            alerts = int(s_alert.ne("").sum())
        else:
            alerts = 0
        worked_h = total_worked_min / 60.0
        ot_h = total_ot_min / 60.0
    except Exception:
        total_rows = total_emp = total_days = alerts = 0
        worked_h = ot_h = 0.0

    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(kpi_card("Registros", f"{total_rows}", f"Empleados: {total_emp} | Días: {total_days}"), unsafe_allow_html=True)
    with k2:
        st.markdown(kpi_card("Tiempo trabajado", f"{worked_h:,.2f} h", "Suma en el filtro actual"), unsafe_allow_html=True)
    with k3:
        st.markdown(kpi_card("Horas extra", f"{ot_h:,.2f} h", "Se activa tras umbral"), unsafe_allow_html=True)
    with k4:
        st.markdown(kpi_card("Alertas", f"{alerts}", "Registros con datos incompletos"), unsafe_allow_html=True)

    st.divider()

    # Columns visible in editor
    show_cols = [
        "ID",
        "FECHA",
        "NOMBRE",
        "ENTRADA",
        "SALIDA A COMER",
        "REGRESO DE COMER",
        "SALIDA A CENAR",
        "REGRESO DE CENAR",
        "SALIDA",
        "PERMISO",
        "DESCUENTO NO LABORADO",
        "TIEMPO TRABAJADO",
        "HORAS EXTRA",
        "_ALERTA",
        # Columna interna para resaltar filas con ediciones
        "_CHANGED",
    ]
    for c in show_cols:
        if c not in df_state.columns:
            # Aseguramos que _CHANGED sea booleano, las demás columnas se inicializan vacías
            if c == "_CHANGED":
                df_state[c] = False
            else:
                df_state[c] = ""

        # Campos editables en la tabla principal
    editable_cols = [
        "ENTRADA",
        "SALIDA A COMER",
        "REGRESO DE COMER",
        "SALIDA A CENAR",
        "REGRESO DE CENAR",
        "SALIDA",
        "PERMISO",
    ]

    # Búsqueda (filtra solo la vista; la exportación usa el dataset completo cargado)
    b1, b2, b3 = st.columns([1, 2, 1])
    with b1:
        search_id = st.text_input("Buscar ID", key="asist_search_id", placeholder="Ej. 10 (muestra 1012, 1018...)")
    with b2:
        search_name = st.text_input("Buscar nombre", key="asist_search_name", placeholder="Texto parcial (contiene)")
    with b3:
        only_alert = st.checkbox("Solo con alerta", key="asist_only_alert", value=False)

    st.caption("La búsqueda filtra solo la vista; no afecta el archivo exportado.")

    df_view = _build_filtered_view(df_state, show_cols, search_id, search_name, only_alert)

    st.caption(f"Mostrando {len(df_view)} de {len(df_state)} registros.")
    fs = bool(st.session_state.get('asist_fullscreen', False))
    # Modo pantalla completa (ancha). No afecta datos; solo vista.
    if st.session_state.get("asist_fullscreen", False):
        st.markdown(
            """<style>
            .block-container {max-width: 98vw !important; padding-left: 1.5rem; padding-right: 1.5rem;}
            </style>""",
            unsafe_allow_html=True,
        )


    # Editor (AgGrid si está disponible; fallback a st.data_editor)
    edited = None
    if AgGrid is not None and GridOptionsBuilder is not None:
        # Controles de vista (derecha: pantalla completa)
        ctl_l, ctl_r = st.columns([3, 1])
        with ctl_l:
            full_height = st.checkbox("Vista amplia", value=True, key="asist_full_height")
        with ctl_r:
            # Pantalla completa para la tabla solamente. Se solicita fullscreen sobre el contenedor que envuelve el grid.
            fs_uid = st.session_state.get("asist_fs_uid")
            if not fs_uid:
                fs_uid = uuid.uuid4().hex
                st.session_state["asist_fs_uid"] = fs_uid
            # id único para el contenedor de la tabla (se guarda en session_state para usarlo al renderizar el grid)
            container_id = f"asist_grid_container_{fs_uid}"
            st.session_state["asist_grid_container_id"] = container_id
            # Botón que permite ampliar la tabla a toda la pantalla. En lugar de
            # utilizar la API de pantalla completa del navegador (que puede
            # mostrar una pantalla negra en algunos casos), se aplica una
            # clase CSS que fija el contenedor de la tabla (identificado por
            # container_id) en posición fija y con tamaño de ventana. Se
            # inyecta dinámicamente una hoja de estilos al documento padre
            # para definir la clase.
            components.html(
                f"""<div style='display:flex;justify-content:flex-end;'>
<button id='{fs_uid}' style='padding:0.45rem 0.8rem;border-radius:10px;border:1px solid rgba(49,51,63,0.2);background:rgba(255,255,255,0.6);cursor:pointer;'>
⛶ Pantalla completa
</button>
<script>
(function() {{
  const btn = document.getElementById('{fs_uid}');
  if (!btn) return;
  // Inserta una regla de estilo para la clase de pantalla completa en el documento padre si no existe
  const pdoc = parent.document;
  const styleId = 'asist-grid-fullscreen-style';
  if (!pdoc.getElementById(styleId)) {{
    const style = pdoc.createElement('style');
    style.id = styleId;
    style.innerHTML = '.asist-grid-fullscreen {{ position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 10000; background: white; overflow: auto; padding: 1rem; box-sizing: border-box; }}';
    (pdoc.head || pdoc.getElementsByTagName('head')[0]).appendChild(style);
  }}
  btn.addEventListener('click', function() {{
    try {{
      const container = pdoc.getElementById('{container_id}');
      if (!container) return;
      // Alternar clase que expande o contrae el contenedor
      if (container.classList.contains('asist-grid-fullscreen')) {{
        container.classList.remove('asist-grid-fullscreen');
      }} else {{
        container.classList.add('asist-grid-fullscreen');
        // Desplazar al inicio en modo pantalla completa para que se vea el encabezado de la tabla
        container.scrollTop = 0;
      }}
    }} catch (e) {{}}
  }});
}})();
</script>
</div>""",
                 height=52
            )

        # Altura del grid
        if fs:
            grid_h = 920
        else:
            grid_h = 720 if full_height else 480

        gb = GridOptionsBuilder.from_dataframe(df_view[show_cols])
        gb.configure_default_column(resizable=True, sortable=True, filter=True)

        # Configurar columnas: editable y pin (fijar) en las primeras
        for c in show_cols:
            is_editable = c in editable_cols
            # Fijamos las primeras columnas para que siempre sean visibles al hacer scroll horizontal
            if c in ["ID", "FECHA", "NOMBRE"]:
                gb.configure_column(c, editable=is_editable, pinned=True)
            else:
                gb.configure_column(c, editable=is_editable)

        # Ocultar la columna interna _CHANGED (sirve para resaltar filas editadas)
        try:
            gb.configure_column("_CHANGED", hide=True)
        except Exception:
            pass

        # Mostrar alerta con nombre amigable
        try:
            gb.configure_column("_ALERTA", header_name="ALERTA")
        except Exception:
            pass

        # Construir grid_options con posible estilo de fila para filas editadas
        overrides_map_state = st.session_state.get("asist_overrides_map") or {}
        if JsCode is not None and overrides_map_state:
            # Definimos una función JS para resaltar filas modificadas
            row_style_js = JsCode("""
            function(params) {
                if (params.data && params.data._CHANGED) {
                    return { 'backgroundColor': '#fff7e6' };
                }
            }
            """)
            grid_options = gb.build()
            grid_options['getRowStyle'] = row_style_js
        else:
            grid_options = gb.build()

        # Si se ha definido un contenedor para fullscreen de la tabla, envolvemos el grid en un div con ese id.
        _fs_container_id = st.session_state.get("asist_grid_container_id")
        if _fs_container_id:
            st.markdown(f"<div id='{_fs_container_id}' class='asist-grid-wrapper'>", unsafe_allow_html=True)
        # Para tablas de ~500 filas/día: VALUE_CHANGED reduce payload por edición.
        # Paginación mejora rendimiento del navegador si se vuelve pesado.
        try:
            gb.configure_pagination(enabled=True, paginationPageSize=100)
        except Exception:
            pass

        grid_resp = AgGrid(
            df_view[show_cols],
            gridOptions=grid_options,
            data_return_mode=DataReturnMode.AS_INPUT,
            update_mode=getattr(GridUpdateMode, 'VALUE_CHANGED', GridUpdateMode.MODEL_CHANGED),
            fit_columns_on_grid_load=False,
            height=grid_h,
            reload_data=False,
            key="asistencia_aggrid",
            allow_unsafe_jscode=True,
        )
        if _fs_container_id:
            st.markdown("</div>", unsafe_allow_html=True)

        try:
            edited = pd.DataFrame(grid_resp.get("data") or [])
        except Exception:
            edited = df_view[show_cols].copy()
    else:
        # Fallback a st.data_editor cuando st_aggrid no está disponible.  Añadimos
        # controles de vista similares a los de AgGrid: una casilla para
        # seleccionar vista amplia (alto) y un botón para alternar la tabla a
        # pantalla completa mediante una clase CSS que fija el contenedor.
        ctl_l, ctl_r = st.columns([3, 1])
        with ctl_l:
            # Permite elegir si la tabla debe ocupar más alto (720 px) o un alto compacto (480 px).
            full_height_de = st.checkbox("Vista amplia", value=True, key="asist_full_height_editor")
        with ctl_r:
            # Genera un ID único para el contenedor y el botón de pantalla completa.
            fs_uid_de = st.session_state.get("asist_fs_uid_de")
            if not fs_uid_de:
                fs_uid_de = uuid.uuid4().hex
                st.session_state["asist_fs_uid_de"] = fs_uid_de
            container_id_de = f"asist_data_editor_container_{fs_uid_de}"
            st.session_state["asist_data_editor_container_id"] = container_id_de
            # Botón para alternar clase que expande la tabla sobre la página. Se inserta
            # en un iframe independiente para evitar conflictos con el DOM de Streamlit.
            components.html(
                f"""<div style='display:flex;justify-content:flex-end;'>
<button id='{fs_uid_de}' style='padding:0.45rem 0.8rem;border-radius:10px;border:1px solid rgba(49,51,63,0.2);background:rgba(255,255,255,0.6);cursor:pointer;'>
⛶ Pantalla completa
</button>
<script>
(function() {{
  const btn = document.getElementById('{fs_uid_de}');
  if (!btn) return;
  // Inserta la regla de estilo global una única vez en el documento padre.
  const pdoc = parent.document;
  const styleId = 'asist-grid-fullscreen-style';
  if (!pdoc.getElementById(styleId)) {{
    const style = pdoc.createElement('style');
    style.id = styleId;
    style.innerHTML = '.asist-grid-fullscreen {{ position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 10000; background: white; overflow: auto; padding: 1rem; box-sizing: border-box; }}';
    (pdoc.head || pdoc.getElementsByTagName('head')[0]).appendChild(style);
  }}
  btn.addEventListener('click', function() {{
    try {{
      const container = pdoc.getElementById('{container_id_de}');
      if (!container) return;
      if (container.classList.contains('asist-grid-fullscreen')) {{
        container.classList.remove('asist-grid-fullscreen');
      }} else {{
        container.classList.add('asist-grid-fullscreen');
        container.scrollTop = 0;
      }}
    }} catch (e) {{}}
  }});
}})();
</script>
</div>""",
                height=52
            )

        # Determinar altura para el editor: si pantalla completa está activada (a nivel de
        # página), usamos una altura mayor, de lo contrario se ajusta según la
        # selección de vista amplia. El valor se aplica al parámetro `height` de st.data_editor.
        grid_h_de = 920 if st.session_state.get("asist_fullscreen", False) else (720 if full_height_de else 480)
        # Envuelve el editor en un div con id conocido para que la clase de pantalla completa
        # pueda aplicarse sobre el contenedor y flotarlo sobre la página.
        st.markdown(f"<div id='{container_id_de}' class='asist-grid-wrapper'>", unsafe_allow_html=True)
        edited = st.data_editor(
            df_view[show_cols],
            width="stretch",
            num_rows="fixed",
            disabled=[
                "ID",
                "FECHA",
                "NOMBRE",
                "DESCUENTO NO LABORADO",
                "TIEMPO TRABAJADO",
                "HORAS EXTRA",
                "_ALERTA",
            ],
            column_config={
                "_ALERTA": st.column_config.TextColumn("ALERTA", help="Advertencias de cálculo (si aplica)"),
            },
            key="asistencia_editor",
            height=grid_h_de,
        )
        st.markdown("</div>", unsafe_allow_html=True)

    
# Auditoría + recálculo en tiempo real (robusto con filtros)

    def _norm_edit_key(k: str) -> str:
        """Normaliza llaves de edición SIN cambiar el ID visual.

        Importante: NO eliminamos ceros a la izquierda aquí, porque el cálculo por
        filas (`recalc_attendance_rows`) hace match exacto contra la columna ID.
        """
        return str(k or "").strip()

    def _norm_cell(v):
        # AgGrid puede devolver "" (string vacío). Unificamos a "" para comparar estable.
        if v is None:
            return ""
        if isinstance(v, float) and pd.isna(v):
            return ""
        return str(v).strip()

    # Solo consideramos las filas que están visibles (df_view) para detectar cambios,
    # así el filtro (ID/NOMBRE/ALERTA) NO rompe la detección.
    current_inputs = edited[["ID", "FECHA"] + editable_cols].copy()

    # Mapa previo por llave (ID, FECHA) → valores editables normalizados
    prev_map = st.session_state.get("asist_prev_map")
    if not isinstance(prev_map, dict):
        prev_map = {}

    # Inicialización (primera carga): tomamos snapshot desde el dataset completo
    if not prev_map:
        try:
            _snap0 = df_state[["ID", "FECHA"] + editable_cols].copy()
            _m0 = {}
            for _, r in _snap0.iterrows():
                k = (_norm_edit_key(r.get("ID")), _norm_edit_key(r.get("FECHA")))
                if not k[0] or not k[1]:
                    continue
                _m0[k] = {c: _norm_cell(r.get(c)) for c in editable_cols}
            prev_map = _m0
            st.session_state["asist_prev_map"] = prev_map
        except Exception:
            pass

    cur_map = {}
    for _, r in current_inputs.iterrows():
        k = (_norm_edit_key(r.get("ID")), _norm_edit_key(r.get("FECHA")))
        if not k[0] or not k[1]:
            continue
        cur_map[k] = {c: _norm_cell(r.get(c)) for c in editable_cols}

    # Detectar cambios SOLO para llaves presentes en la vista actual
    changed_keys = []
    pending_changes = []
    for k, cur_vals in cur_map.items():
        prev_vals = prev_map.get(k, None)
        if prev_vals is None:
            # primera vez que vemos esta fila en esta sesión -> no auditar, pero sí guardarla
            continue
        diffs = {}
        for c in editable_cols:
            if _norm_cell(prev_vals.get(c)) != _norm_cell(cur_vals.get(c)):
                diffs[c] = {"from": _norm_cell(prev_vals.get(c)), "to": _norm_cell(cur_vals.get(c))}
        if diffs:
            changed_keys.append(k)
            pending_changes.append({
                "key": {"ID": k[0], "FECHA": k[1]},
                "changes": diffs,
            })

    # Aplicar cambios a la tabla completa (dataset completo) y recalcular SOLO filas cambiadas
    df_mem = df_state.copy()
    if changed_keys:
        # Indexamos por (ID, FECHA) para asignación rápida
        try:
            df_mem_idx = df_mem.set_index(["ID", "FECHA"], drop=False)
        except Exception:
            df_mem_idx = None

        for (mid, mf) in changed_keys:
            if df_mem_idx is None:
                mask = (df_mem["ID"].astype(str) == mid) & (df_mem["FECHA"].astype(str) == mf)
                for c in editable_cols:
                    v = cur_map.get((mid, mf), {}).get(c, "")
                    df_mem.loc[mask, c] = v if v != "" else pd.NA
            else:
                try:
                    for c in editable_cols:
                        v = cur_map.get((mid, mf), {}).get(c, "")
                        df_mem_idx.loc[(mid, mf), c] = v if v != "" else pd.NA
                except Exception:
                    pass
            # Nota: dejamos "" si el usuario vacía la celda (significa "sin dato")

    # Guardar en memoria las ediciones (sin recalcular todavía)
    # Esto permite que el usuario edite varias celdas y luego presione un botón
    # para recalcular de forma explícita.
    st.session_state["asist_df"] = df_mem.copy()
    recalced = df_mem

    # --- Botón explícito para recalcular ---
    pending_n = int(len(changed_keys))
    if pending_n > 0:
        st.warning(f"Hay {pending_n} registro(s) editado(s) pendiente(s) de recalcular. Presiona **Recalcular** para actualizar TIEMPO TRABAJADO / HORAS EXTRA / DESCUENTO.")
    
    # Por defecto deshabilitamos el recálculo automático para que el usuario pueda
    # ajustar los horarios antes de generar los tiempos finales.  Si se quiere
    # que el cálculo se actualice a cada edición, se puede activar manualmente.
    auto_recalc = st.checkbox("Recalcular en tiempo real al editar", value=False, key="asist_auto_recalc")
    cR1, cR2 = st.columns([1, 1])
    with cR1:
        do_recalc = st.button("Recalcular", type="primary", width="stretch", disabled=(pending_n == 0))
    with cR2:
        do_recalc_all = st.button("Recalcular todo", width="stretch")

    if (pending_n > 0 and auto_recalc) or do_recalc or do_recalc_all:
        with st.spinner("Recalculando..."):
            try:
                if do_recalc_all:
                    recalced2 = recalc_attendance_table(df_mem, rules=rules)
                else:
                    recalced2 = recalc_attendance_rows(df_mem, keys=changed_keys, rules=rules)
            except Exception as e:
                st.error(f"Error al recalcular: {e}")
                recalced2 = df_mem

        # Persistir resultado recalculado
        st.session_state["asist_df"] = recalced2.copy()
        recalced = recalced2

        # Guardar overrides persistentes SOLO al recalcular (así el usuario decide cuándo aplicar)
        try:
            overrides_path = os.path.join(data_dir, "attendance_overrides.jsonl")
            overrides_map_state = st.session_state.get("asist_overrides_map") or {}
            for rec in pending_changes:
                key_t = (str(rec["key"]["ID"]), str(rec["key"]["FECHA"]))
                overrides_map_state.setdefault(key_t, {})
                for col, detail in rec.get("changes", {}).items():
                    overrides_map_state[key_t][col] = detail.get("to")
                record = {
                    "ID": rec["key"]["ID"],
                    "FECHA": rec["key"]["FECHA"],
                    "changes": rec.get("changes", {}),
                    "actor": getattr(u, "username", ""),
                    "role": getattr(u, "role", ""),
                    "timestamp": datetime.now().isoformat(),
                }
                _append_override_record(data_dir, record)
            st.session_state["asist_overrides_map"] = overrides_map_state
            try:
                st.session_state["asist_overrides_mtime"] = os.path.getmtime(overrides_path) if os.path.exists(overrides_path) else None
            except Exception:
                pass
        except Exception as _e:
            st.error(f"No se pudo guardar las ediciones de manera persistente: {_e}")

        # Actualizar snapshot (baseline) para futuras ediciones
        try:
            snap_df = recalced2[["ID", "FECHA"] + editable_cols].copy()
            snap_map = {}
            for _, r in snap_df.iterrows():
                k = (_norm_edit_key(r.get("ID")), _norm_edit_key(r.get("FECHA")))
                if not k[0] or not k[1]:
                    continue
                snap_map[k] = {c: _norm_cell(r.get(c)) for c in editable_cols}
            st.session_state["asist_prev_map"] = snap_map
        except Exception:
            st.session_state["asist_prev_map"] = cur_map

        # Si el usuario presionó explícitamente el botón de recálculo, exportamos automáticamente
        if do_recalc or do_recalc_all:
            try:
                # Exportar utilizando los datos recalculados
                _do_export(recalced2, mode='recalc_button_export')
            except Exception as e:
                st.error(f"No se pudo exportar tras el recálculo: {e}")
            # Mostrar mensaje de éxito y finalizar la ejecución para evitar que se ejecute st.rerun
            st.success("Recalculo aplicado y exportado.")
            return

        # Si el recálculo fue automático (al editar), solo actualizamos y recargamos
        st.success("Recalculo aplicado.")
        st.rerun()

    # --- Exportar vista actual y cambios persistentes ---
    st.markdown("#### 3x) Exportar datos")
    with st.expander("Exportar vista actual (filtrada)", expanded=False):
        if st.button("Generar Excel de vista actual", key="asist_export_view"):
            try:
                # Excluir columnas internas como _CHANGED al exportar
                df_exp = _build_filtered_view(recalced, show_cols, search_id, search_name, only_alert)
                if "_CHANGED" in df_exp.columns:
                    df_exp = df_exp.drop(columns=["_CHANGED"])  # columna interna
                out_path = _export_df_to_excel(df_exp)
                with open(out_path, "rb") as _f:
                    _data_bin = _f.read()
                st.success("Excel generado.")
                st.download_button(
                    "Descargar Excel (vista)",
                    data=_data_bin,
                    file_name=os.path.basename(out_path),
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
            except Exception as e:
                st.error(f"No se pudo exportar la vista actual: {e}")
    with st.expander("Exportar solo cambios (overrides)", expanded=False):
        # Preparar DataFrame con las filas editadas de forma persistente
        df_changes = None
        try:
            df_all_changes = _get_state_df()
            if isinstance(df_all_changes, pd.DataFrame) and not df_all_changes.empty:
                if "_CHANGED" in df_all_changes.columns:
                    df_changes = df_all_changes[df_all_changes["_CHANGED"] == True].copy()
        except Exception:
            df_changes = None
        if df_changes is None or df_changes.empty:
            st.info("No hay ediciones persistentes para exportar.")
        else:
            if st.button("Generar Excel solo cambios", key="asist_export_changes"):
                try:
                    df_changes_exp = df_changes.copy()
                    if "_CHANGED" in df_changes_exp.columns:
                        df_changes_exp = df_changes_exp.drop(columns=["_CHANGED"])  # columna interna
                    out_path2 = _export_df_to_excel(df_changes_exp, filename_prefix="attendance_changes")
                    with open(out_path2, "rb") as _f2:
                        _data_bin2 = _f2.read()
                    st.success("Excel generado.")
                    st.download_button(
                        "Descargar Excel (cambios)",
                        data=_data_bin2,
                        file_name=os.path.basename(out_path2),
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    )
                except Exception as e:
                    st.error(f"No se pudo exportar cambios: {e}")

    st.markdown("#### 3b) Permisos detallados")
    st.caption("Edición avanzada: intervalos de permiso por registro.")
    st.caption("Edita permisos como pares Salida/Regreso. Se suman y se descuentan (si la regla lo permite). No se exporta el detalle, solo el total.")
    recalced_df = recalced.copy()
    if "PERMISOS DETALLE" not in recalced_df.columns:
        recalced_df["PERMISOS DETALLE"] = ""

    # Selector de fila por (FECHA, ID)
    row_labels = [f"{recalced_df.iloc[i]['FECHA']} | {recalced_df.iloc[i]['ID']} | {recalced_df.iloc[i]['NOMBRE']}" for i in range(len(recalced_df))]
    sel_i = st.selectbox("Selecciona registro para editar permisos", options=list(range(len(recalced_df))), format_func=lambda i: row_labels[i], key="perm_detail_sel")
    sel_row = recalced_df.iloc[int(sel_i)].to_dict()
    current_detail = str(sel_row.get("PERMISOS DETALLE") or "").strip()

    def _detail_to_df(detail: str) -> pd.DataFrame:
        rows = []
        for part in [p.strip() for p in detail.split(';') if p.strip()]:
            if '-' in part:
                a,b = part.split('-',1)
                rows.append({"Salida": a.strip(), "Regreso": b.strip()})
            else:
                rows.append({"Salida": part.strip(), "Regreso": ""})
        return pd.DataFrame(rows) if rows else pd.DataFrame([{"Salida": "", "Regreso": ""}])

    def _df_to_detail(df_: pd.DataFrame) -> str:
        parts=[]
        for _,rr in df_.iterrows():
            a=str(rr.get('Salida') or '').strip()
            b=str(rr.get('Regreso') or '').strip()
            if not a:
                continue
            if b:
                parts.append(f"{a}-{b}")
            else:
                parts.append(a)
        return ';'.join(parts)

    perm_df = _detail_to_df(current_detail)
    perm_df2 = st.data_editor(
        perm_df,
        width="stretch",
        num_rows="fixed",
        key="perm_detail_editor",
    )
    new_detail = _df_to_detail(perm_df2)
    cA, cB, cC, cD = st.columns([1, 1, 1, 1])
    if cA.button("Aplicar permisos a este registro", type="primary"):
        before_detail = current_detail
        after_detail = new_detail
        # Actualiza el df en memoria y recalcula
        df_mem = _get_state_df()
        # localiza fila por FECHA+ID
        mask = (df_mem.get('FECHA','').astype(str)==str(sel_row.get('FECHA'))) & (df_mem.get('ID','').astype(str)==str(sel_row.get('ID')))
        if mask.any():
            df_mem.loc[mask, 'PERMISOS DETALLE'] = new_detail
            st.session_state['asist_df'] = recalc_attendance_table(df_mem, rules=rules).copy()
            try:
                row0 = st.session_state['asist_df'][(st.session_state['asist_df']['ID'].astype(str)==str(sel_row.get('ID'))) & (st.session_state['asist_df']['FECHA'].astype(str)==str(sel_row.get('FECHA')))].iloc[0].to_dict()
            except Exception:
                row0 = {}
            try:
                append_event(data_dir, {
                    'category': 'attendance',
                    'action': 'permissions_detail_apply',
                    'actor': u.username,
                    'role': u.role,
                    'session_id': st.session_state.get('session_id'),
                    'details': {
                        'key': {'ID': str(sel_row.get('ID')), 'FECHA': str(sel_row.get('FECHA'))},
                        'before': before_detail,
                        'after': after_detail,
                        'derived': {
                            'PERMISO': str(row0.get('PERMISO','')),
                            'DESCUENTO NO LABORADO': str(row0.get('DESCUENTO NO LABORADO','')),
                            'TIEMPO TRABAJADO': str(row0.get('TIEMPO TRABAJADO','')),
                            'HORAS EXTRA': str(row0.get('HORAS EXTRA','')),
                        },
                    },
                }, name='attendance_audit.jsonl')
            except Exception:
                pass
            st.success("Permisos aplicados y recalculados.")
            st.rerun()
        else:
            st.error("No se encontró el registro en memoria (ID/FECHA).")
    if cB.button("Limpiar permisos detallados"):
        before_detail = current_detail
        df_mem = _get_state_df()
        mask = (df_mem.get('FECHA','').astype(str)==str(sel_row.get('FECHA'))) & (df_mem.get('ID','').astype(str)==str(sel_row.get('ID')))
        if mask.any():
            df_mem.loc[mask, 'PERMISOS DETALLE'] = ""
            st.session_state['asist_df'] = recalc_attendance_table(df_mem, rules=rules).copy()
            try:
                row0 = st.session_state['asist_df'][(st.session_state['asist_df']['ID'].astype(str)==str(sel_row.get('ID'))) & (st.session_state['asist_df']['FECHA'].astype(str)==str(sel_row.get('FECHA')))].iloc[0].to_dict()
            except Exception:
                row0 = {}
            try:
                append_event(data_dir, {
                    'category': 'attendance',
                    'action': 'permissions_detail_clear',
                    'actor': u.username,
                    'role': u.role,
                    'session_id': st.session_state.get('session_id'),
                    'details': {
                        'key': {'ID': str(sel_row.get('ID')), 'FECHA': str(sel_row.get('FECHA'))},
                        'before': before_detail,
                        'after': '',
                        'derived': {
                            'PERMISO': str(row0.get('PERMISO','')),
                            'DESCUENTO NO LABORADO': str(row0.get('DESCUENTO NO LABORADO','')),
                            'TIEMPO TRABAJADO': str(row0.get('TIEMPO TRABAJADO','')),
                            'HORAS EXTRA': str(row0.get('HORAS EXTRA','')),
                        },
                    },
                }, name='attendance_audit.jsonl')
            except Exception:
                pass
            st.success("Permisos limpiados y recalculados.")
            st.rerun()

    if cC.button("Autodetectar permisos (este registro)"):
        before_detail = current_detail
        df_mem = _get_state_df()
        mask = (df_mem.get('FECHA','').astype(str)==str(sel_row.get('FECHA'))) & (df_mem.get('ID','').astype(str)==str(sel_row.get('ID')))
        if mask.any():
            evs = str(df_mem.loc[mask, '_EVENTOS'].iloc[0] if '_EVENTOS' in df_mem.columns else '').strip()
            auto_detail = autodetect_permiso_detail_from_eventos(evs)
            df_mem.loc[mask, 'PERMISOS DETALLE'] = auto_detail
            st.session_state['asist_df'] = recalc_attendance_table(df_mem, rules=rules).copy()
            try:
                row0 = st.session_state['asist_df'][(st.session_state['asist_df']['ID'].astype(str)==str(sel_row.get('ID'))) & (st.session_state['asist_df']['FECHA'].astype(str)==str(sel_row.get('FECHA')))].iloc[0].to_dict()
            except Exception:
                row0 = {}
            try:
                append_event(data_dir, {
                    'category': 'attendance',
                    'action': 'permissions_autodetect_one',
                    'actor': u.username,
                    'role': u.role,
                    'session_id': st.session_state.get('session_id'),
                    'details': {
                        'key': {'ID': str(sel_row.get('ID')), 'FECHA': str(sel_row.get('FECHA'))},
                        'before': before_detail,
                        'after': auto_detail,
                        'derived': {
                            'PERMISO': str(row0.get('PERMISO','')),
                            'DESCUENTO NO LABORADO': str(row0.get('DESCUENTO NO LABORADO','')),
                            'TIEMPO TRABAJADO': str(row0.get('TIEMPO TRABAJADO','')),
                            'HORAS EXTRA': str(row0.get('HORAS EXTRA','')),
                        },
                    },
                }, name='attendance_audit.jsonl')
            except Exception:
                pass
            st.success("Permisos autodetectados desde _EVENTOS.")
            st.rerun()
        else:
            st.error("No se encontró el registro en memoria (ID/FECHA).")

    if cD.button("Autodetectar permisos (todos)"):
        df_mem = _get_state_df()
        if '_EVENTOS' not in df_mem.columns:
            st.error("No hay columna _EVENTOS disponible para autodetectar.")
        else:
            df_mem = df_mem.copy()
            df_mem['PERMISOS DETALLE'] = df_mem['_EVENTOS'].astype(str).apply(autodetect_permiso_detail_from_eventos)
            st.session_state['asist_df'] = recalc_attendance_table(df_mem, rules=rules).copy()
            try:
                append_event(data_dir, {
                    'category': 'attendance',
                    'action': 'permissions_autodetect_all',
                    'actor': u.username,
                    'role': u.role,
                    'session_id': st.session_state.get('session_id'),
                    'details': {
                        'source_file': os.path.basename(src_path),
                        'rows': int(len(df_mem)),
                    },
                }, name='attendance_audit.jsonl')
            except Exception:
                pass
            st.success("Permisos autodetectados para todos los registros.")
            st.rerun()
    st.markdown("#### 4) Exportar Excel")
    st.caption("Se exporta sin columnas internas como _EVENTOS y _ALERTA.")
    out_dir = os.path.join(exports_dir, "asistencia")
    os.makedirs(out_dir, exist_ok=True)

    base_name = st.text_input("Nombre base del archivo", value="Asistencia", help="Se agregará timestamp automáticamente.")
    cols_export = DEFAULT_COLUMNS

    # Si hay cambios pendientes (no recalculados), forzamos UX segura: botón combinado.
    pending_n_export = int(len(changed_keys)) if 'changed_keys' in locals() else 0
    if pending_n_export > 0:
        st.warning(f"Hay {pending_n_export} registro(s) editado(s) pendientes de recalcular. Usa **Recalcular y exportar** para evitar exportar resultados desactualizados.")

    cE1, cE2 = st.columns([1, 1])
    with cE1:
        do_recalc_export = st.button("Recalcular y exportar", type="primary", width="stretch")
    with cE2:
        do_export_only = st.button("Exportar (sin recalcular)", width="stretch", disabled=(pending_n_export > 0))

    def _persist_pending_changes(_pending_changes):
        """Guarda overrides persistentes para los cambios detectados."""
        try:
            overrides_path = os.path.join(data_dir, "attendance_overrides.jsonl")
            overrides_map_state = st.session_state.get("asist_overrides_map") or {}
            for rec in (_pending_changes or []):
                key_t = (str(rec["key"]["ID"]), str(rec["key"]["FECHA"]))
                overrides_map_state.setdefault(key_t, {})
                for col, detail in (rec.get("changes", {}) or {}).items():
                    overrides_map_state[key_t][col] = detail.get("to")
                record = {
                    "ID": rec["key"]["ID"],
                    "FECHA": rec["key"]["FECHA"],
                    "changes": rec.get("changes", {}),
                    "actor": getattr(u, "username", ""),
                    "role": getattr(u, "role", ""),
                    "timestamp": datetime.now().isoformat(),
                }
                _append_override_record(data_dir, record)
            st.session_state["asist_overrides_map"] = overrides_map_state
            try:
                st.session_state["asist_overrides_mtime"] = os.path.getmtime(overrides_path) if os.path.exists(overrides_path) else None
            except Exception:
                pass
        except Exception as _e:
            st.error(f"No se pudo guardar las ediciones de manera persistente: {_e}")

    def _do_export(df_to_export: pd.DataFrame, mode: str):
        path = export_attendance_excel(df_to_export, out_dir=out_dir, base_name=base_name, columns=cols_export)
        try:
            append_event(data_dir, {
                'category': 'attendance',
                'action': 'export_excel',
                'actor': u.username,
                'role': u.role,
                'session_id': st.session_state.get('session_id'),
                'details': {
                    'source_file': os.path.basename(src_path),
                    'export_file': os.path.basename(path),
                    'rows': int(len(df_to_export)),
                    'filter_active': bool(filter_active),
                    'ids_count': int(len(employee_ids)) if filter_active else 0,
                    'mode': mode,
                },
            }, name='attendance_audit.jsonl')
        except Exception:
            pass
        st.success(f"Export creado: {path}")
        with open(path, "rb") as f:
            st.download_button(
                "Descargar Excel",
                data=f.read(),
                file_name=os.path.basename(path),
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                width="stretch",
            )

    if do_recalc_export:
        with st.spinner("Recalculando y exportando..."):
            try:
                df_current = st.session_state.get('asist_df') if isinstance(st.session_state.get('asist_df'), pd.DataFrame) else recalced
                recalced_export = recalc_attendance_table(df_current, rules=rules)
                st.session_state['asist_df'] = recalced_export.copy()
                _persist_pending_changes(pending_changes if 'pending_changes' in locals() else [])
                _do_export(recalced_export, mode='recalc_export')
            except Exception as e:
                st.error(f"No se pudo recalcular y exportar: {e}")

    if do_export_only:
        try:
            # Antes de exportar, recalcular siempre para que los tiempos
            # trabajados se generen con las reglas actuales.  De esta forma
            # el usuario puede editar horarios sin recálculo inmediato y
            # obtener los valores finales solo al exportar.
            df_export = st.session_state.get('asist_df') if isinstance(st.session_state.get('asist_df'), pd.DataFrame) else recalced
            df_export_recalc = recalc_attendance_table(df_export, rules=rules)
            # Actualizar en memoria para reflejar los valores finales
            st.session_state['asist_df'] = df_export_recalc.copy()
            # Guardar ediciones persistentes antes de exportar
            _persist_pending_changes(pending_changes if 'pending_changes' in locals() else [])
            _do_export(df_export_recalc, mode='export_final')
        except Exception as e:
            st.error(f"No se pudo exportar: {e}")

    # --- Historial de ediciones persistentes ---
    st.markdown("#### 5) Historial de ediciones")
    with st.expander("Ver historial de cambios", expanded=False):
        hist_list = st.session_state.get("asist_overrides_history") or []
        if not hist_list:
            st.info("No hay historial de ediciones guardadas.")
        else:
            # Construir DataFrame plano con cada campo modificado como fila
            records = []
            try:
                for rec in reversed(hist_list):  # mostrar primero los más recientes
                    ts = rec.get("timestamp", "")
                    actor = rec.get("actor", "")
                    rid = rec.get("ID", "")
                    fec = rec.get("FECHA", "")
                    changes = rec.get("changes", {}) or {}
                    for coln, detail in changes.items():
                        frm_val = (detail.get("from") if isinstance(detail, dict) else None)
                        to_val = (detail.get("to") if isinstance(detail, dict) else None)
                        records.append({
                            "Fecha modificación": ts,
                            "Usuario": actor,
                            "ID": rid,
                            "FECHA": fec,
                            "Campo": coln,
                            "Antes": frm_val,
                            "Después": to_val,
                        })
                if records:
                    hist_df = pd.DataFrame(records)
                    st.dataframe(hist_df, width="stretch")
                else:
                    st.info("No hay entradas para mostrar.")
            except Exception as e:
                st.error(f"No se pudo mostrar el historial: {e}")

    with st.expander("Ver eventos originales (debug)"):
        if "_EVENTOS" in recalced.columns:
            st.dataframe(recalced[["ID", "FECHA", "_EVENTOS"]], width="stretch")
        else:
            st.info("No hay columna _EVENTOS disponible.")


if __name__ == "__main__":
    main()
