from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Tuple

import pandas as pd
import streamlit as st
try:
    from streamlit_autorefresh import st_autorefresh
except Exception:  # pragma: no cover
    st_autorefresh = None


from components.layout import render_topbar, section_header
from components.auth_ui import login_panel, current_user
from components.ui import metric_card, kpi_card
from components.area_filter import render_area_filter
from components.sidebar_settings import render_sidebar_settings
from utils.page_bootstrap import bootstrap_page
from utils.runtime_store import get_runtime, get_data_dir


def _sql_counts_by_date(db, table: str, date_col: str, start: str, end: str) -> pd.DataFrame:
    if db.engine != "sqlite":
        # Keep it simple; for postgres, fall back to per-day iteration using existing methods.
        return pd.DataFrame(columns=["date", "count"]).set_index("date")
    q = f"SELECT {date_col} as d, COUNT(1) as n FROM {table} WHERE {date_col}>=? AND {date_col}<=? GROUP BY {date_col} ORDER BY {date_col}"  # noqa
    with db._lock:
        rows = db._conn.execute(q, (start, end)).fetchall()
    df = pd.DataFrame(rows, columns=["date", "count"]) if rows else pd.DataFrame(columns=["date", "count"])
    if not df.empty:
        df["date"] = df["date"].astype(str)
        df = df.set_index("date")
    return df



def _sql_counts_by_date_processed_filtered(db, start: str, end: str, allowed_employee_ids: List[str]) -> pd.DataFrame:
    """Counts processed_events by event_date filtered by employee_id.
    Implemented for sqlite with chunking (SQLite variable limit)."""
    if not allowed_employee_ids:
        return pd.DataFrame(columns=["date", "count"]).set_index("date")
    if db.engine != "sqlite":
        return pd.DataFrame(columns=["date", "count"]).set_index("date")

    ids = [str(x) for x in allowed_employee_ids if str(x).strip()]
    if not ids:
        return pd.DataFrame(columns=["date", "count"]).set_index("date")

    # chunk to avoid SQLITE_MAX_VARIABLE_NUMBER (~999)
    chunk_size = 900
    counts: Dict[str, int] = {}
    with db._lock:
        for i in range(0, len(ids), chunk_size):
            part = ids[i : i + chunk_size]
            ph = ",".join(["?"] * len(part))
            q = (
                "SELECT event_date as d, COUNT(1) as n "
                f"FROM processed_events WHERE event_date>=? AND event_date<=? AND employee_id IN ({ph}) "
                "GROUP BY event_date"
            )
            rows = db._conn.execute(q, (start, end, *part)).fetchall()
            for d, n in rows:
                counts[str(d)] = counts.get(str(d), 0) + int(n)

    if not counts:
        return pd.DataFrame(columns=["date", "count"]).set_index("date")
    df = pd.DataFrame([{"date": k, "count": v} for k, v in sorted(counts.items())]).set_index("date")
    return df


def _latest_processed(db, limit: int = 200) -> pd.DataFrame:
    if db.engine != "sqlite":
        return pd.DataFrame()
    q = """
        SELECT event_time_utc, event_date, event_time, employee_id, employee_name, event_type
        FROM processed_events
        ORDER BY event_time_utc DESC
        LIMIT ?
    """
    with db._lock:
        rows = db._conn.execute(q, (int(limit),)).fetchall()
    return pd.DataFrame(rows, columns=["event_time_utc", "event_date", "event_time", "employee_id", "employee_name", "event_type"]) if rows else pd.DataFrame()


def render():
    bootstrap_page("Dashboard | URSOMEX", page_icon="📊")

    render_sidebar_settings()

    data_dir = get_data_dir()
    login_panel(data_dir)

    u = current_user()
    if not u:
        st.warning("Inicia sesión para ver el dashboard.")
        return

    rt = get_runtime()

    # --- Global area filter (applies to KPIs, trends and tables) ---
    st.sidebar.header("Filtros")

    flt_global = render_area_filter(
        st.sidebar,
        data_dir,
        key_prefix="dash__global",
        title="Filtro global por áreas",
        show_manual_ids=False,
        show_order_by_area=False,
        show_within_sort=False,
    )
    sel_areas_global = flt_global["sel_areas"]
    allowed_ids_global = flt_global["employee_ids"]



    render_topbar("Dashboard", "Métricas operativas, trazas y actividad reciente.")
    
    st.caption("Métricas del collector, estado del servicio y señales del ecosistema de aprendizaje.")
    cR1, cR2, cR3 = st.columns([1, 1, 2])
    with cR1:
        auto = st.checkbox("Auto-refresh", value=False)
    with cR2:
        interval = st.selectbox("Intervalo", [5, 10, 20, 30, 60], index=2, format_func=lambda x: f"{x}s")
    with cR3:
        st.caption("Si activas auto-refresh, se hace polling de la DB en esta página.")

    if auto:
        if st_autorefresh:
            st_autorefresh(interval=int(interval) * 1000, key="dash_autorefresh")
        else:
            st.info("Auto-refresh no disponible (instala streamlit-autorefresh).")


    colA, colB, colC = st.columns([1.3, 1.0, 1.0])
    with colA:
        st.markdown(f"**Config:** `{rt.cfg_path}`")
        st.markdown(f"**DB:** `{rt.cfg.database.get('engine')}` | `{rt.cfg.database.get('sqlite_path') or rt.cfg.database.get('postgres_dsn')}`")
    with colB:
        st.markdown(f"**Servicio:** {'🟢 corriendo' if rt.is_running else '⚪ detenido'}")
        st.markdown(f"**Modo:** `{rt.bg_mode or '—'}`")
    with colC:
        if st.button("Refrescar", width="stretch"):
            st.rerun()

    st.divider()

    try:
        s = rt.status()
    except Exception as e:
        st.error(f"No se pudo obtener estado: {e}")
        return

    
    if sel_areas_global and allowed_ids_global:
        st.info(f"Filtro activo por áreas: {', '.join(sel_areas_global)} | IDs: {len(allowed_ids_global)}")
    # --- KPI cards (corporativo) ---

    try:
        end_d = datetime.now().date()
        start_7 = (end_d - timedelta(days=6)).isoformat()
        start_14 = (end_d - timedelta(days=13)).isoformat()
        end_s = end_d.isoformat()
        df_proc_14 = _sql_counts_by_date(rt.svc.db, "processed_events", "event_date", start_14, end_s)
        df_raw_14 = _sql_counts_by_date(rt.svc.db, "raw_events", "substr(event_time,1,10)", start_14, end_s)
        proc_last7 = int(df_proc_14.tail(7)["count"].sum()) if not df_proc_14.empty else 0
        proc_prev7 = int(df_proc_14.head(max(0, len(df_proc_14) - 7))["count"].tail(7).sum()) if not df_proc_14.empty else 0
        raw_last7 = int(df_raw_14.tail(7)["count"].sum()) if not df_raw_14.empty else 0
        raw_prev7 = int(df_raw_14.head(max(0, len(df_raw_14) - 7))["count"].tail(7).sum()) if not df_raw_14.empty else 0

        def _delta(a: int, b: int) -> str:
            if b <= 0:
                return ""
            pct = (a - b) / max(b, 1) * 100.0
            sign = "+" if pct >= 0 else ""
            return f"{sign}{pct:.1f}%"

        d_proc = _delta(proc_last7, proc_prev7)
        d_raw = _delta(raw_last7, raw_prev7)
    except Exception:
        d_proc = ""
        d_raw = ""
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(kpi_card("RRHH hoy", f"{s.rrhh_today}", f"Fecha local: {s.today_local}"), unsafe_allow_html=True)
    with k2:
        st.markdown(kpi_card("Audit hoy (raw)", f"{s.audit_today}", "Eventos crudos del día"), unsafe_allow_html=True)
    with k3:
        status = "ok" if s.last_ping_ok == "1" else "bad" if s.last_ping_ok else "neutral"
        st.markdown(metric_card("Ping", "OK" if s.last_ping_ok == "1" else "NO", f"Último: {s.last_ping_utc or '—'}", status=status), unsafe_allow_html=True)
    with k4:
        st.markdown(kpi_card("Último pull", f"{s.last_pull_inserted or '—'}", f"UTC: {s.last_pull_utc or '—'}"), unsafe_allow_html=True)

    k5, k6, k7, k8 = st.columns(4)
    with k5:
        st.markdown(kpi_card("Raw total", f"{s.raw_total}", f"Último raw: {s.last_raw_event_time or '—'}", delta_text=d_raw), unsafe_allow_html=True)
    with k6:
        st.markdown(kpi_card("Processed total", f"{s.processed_total}", f"Último RRHH: {s.last_rrhh_event_time or '—'}", delta_text=d_proc), unsafe_allow_html=True)
    with k7:
        st.markdown(kpi_card("Verify inválidos", f"{s.verify_invalid_pct:.1f}%", f"inv={s.verify_invalid} / total={s.verify_total}"), unsafe_allow_html=True)
    with k8:
        st.markdown(kpi_card("Patrones empleados", f"{s.patterns_employees or 0}", f"Auditoría modelos: {s.model_audit_rows or 0}"), unsafe_allow_html=True)

    st.divider()

    # --- Trend charts ---
    with st.expander("Tendencias (últimos días)", expanded=True):
        days = st.slider("Ventana (días)", min_value=7, max_value=180, value=30)
        end = datetime.now().date().isoformat()
        start = (datetime.now().date() - timedelta(days=int(days))).isoformat()

        df_proc = _sql_counts_by_date(rt.svc.db, "processed_events", "event_date", start, end)
        df_raw = _sql_counts_by_date(rt.svc.db, "raw_events", "substr(event_time,1,10)", start, end)

        df_proc_area = _sql_counts_by_date_processed_filtered(rt.svc.db, start, end, allowed_ids_global) if (sel_areas_global and allowed_ids_global) else pd.DataFrame()

        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Processed por día")
            if df_proc.empty:
                st.info("Sin datos (o engine no-sqlite).")
            else:
                st.line_chart(df_proc)
                if sel_areas_global and allowed_ids_global:
                    st.caption("Procesados filtrados por área")
                    if df_proc_area is None or df_proc_area.empty:
                        st.info("Sin datos para el filtro.")
                    else:
                        st.line_chart(df_proc_area)
        with c2:
            st.subheader("Raw por día")
            if df_raw.empty:
                st.info("Sin datos (o engine no-sqlite).")
            else:
                st.line_chart(df_raw)

    st.divider()

    # --- Latest events + filters ---
    st.subheader("Últimos eventos procesados")
    df_last = _latest_processed(rt.svc.db, limit=300)
    if df_last.empty:
        st.info("No hay eventos en processed_events.")
    else:

        flt_table = render_area_filter(
            st,
            data_dir,
            key_prefix="dash__table",
            title="Filtrar por áreas (tabla)",
            show_manual_ids=False,
            show_order_by_area=False,
            show_within_sort=False,
        )
        allowed_ids_table = flt_table["employee_ids"]

        emp = st.text_input("Filtrar por employee_id (texto opcional)", value="")


        # aplica filtro de tabla (si se seleccionó)
        if allowed_ids_table:
            allowed_t = set([str(x) for x in allowed_ids_table])
            if allowed_t:
                df_last = df_last[df_last["employee_id"].astype(str).isin(list(allowed_t))]

        # aplica filtro global (sidebar)
        if sel_areas_global and allowed_ids_global:
            allowed = set(allowed_ids_global)
            if allowed:
                df_last = df_last[df_last["employee_id"].astype(str).isin(list(allowed))]

        if emp.strip():
            df_last = df_last[df_last["employee_id"].astype(str).str.contains(emp.strip(), na=False)]
        st.dataframe(df_last, width="stretch", height=360)

    st.divider()

    # --- Learning snapshots ---
    with st.expander("Ecosistema de aprendizaje (resumen)", expanded=False):
        st.markdown(f"**Global n:** `{s.global_n or 0}`")
        if s.seasonality_v2:
            st.markdown("**Seasonality v2**")
            st.json(s.seasonality_v2)
        if s.cluster_v2:
            st.markdown("**Cluster v2**")
            st.json(s.cluster_v2)
        if s.weekly_snapshot:
            st.markdown("**Snapshot semanal**")
            st.json(s.weekly_snapshot)


if __name__ == "__main__":
    render()
