from __future__ import annotations

import html
import os
import tempfile
from datetime import datetime, date, timedelta

from zoneinfo import ZoneInfo
from collector.service.backfill import local_window_to_utc

import streamlit as st

from components.layout import render_topbar, section_header
from components.auth_ui import login_panel, current_user
from components.log_viewer import tail_file
from components.area_filter import render_area_filter
from components.sidebar_settings import render_sidebar_settings
from utils.page_bootstrap import bootstrap_page
from utils.runtime_store import get_runtime, get_data_dir
from utils.safe_console import SAFE_COMMANDS



# --- Compat: rebuild/index jornadas (avoid crash if runtime missing method) ---
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
from collector.service.jornadas_indexer import ensure_jornadas_indexed_until


def _fallback_rebuild_indexar_jornadas_range(rt, start_op_date: str, end_op_date: str):
    """Compat implementation for older runtimes lacking rebuild_indexar_jornadas_range()."""
    # Try to get config + DB
    cfg = getattr(rt, "cfg", None)
    svc = getattr(rt, "svc", None)
    db = getattr(svc, "db", None) if svc is not None else getattr(rt, "db", None)

    if cfg is None or db is None:
        raise AttributeError("Runtime sin cfg/db; no se puede ejecutar rebuild/index.")

    # Device timezone
    tz_name = None
    try:
        tz_name = cfg.operation.get("device_tz") or cfg.operation.get("timezone")
    except Exception:
        pass
    tz = ZoneInfo(str(tz_name)) if tz_name else ZoneInfo("America/Mexico_City")

    shift_cutoff = str(
        getattr(cfg, "operation", {}).get("shift_cutoff_hhmm")
        or getattr(cfg, "operation", {}).get("shift_cutoff")
        or "03:00"
    ).strip() or "03:00"

    close_lookahead = str(getattr(cfg, "export", {}).get("close_lookahead_hhmm") or "12:00").strip() or "12:00"
    break_max_minutes = int(getattr(cfg, "export", {}).get("break_max_minutes", 75))
    rest_min_minutes = int(getattr(cfg, "export", {}).get("min_rest_between_shifts_minutes", 240))
    debounce_minutes = int(getattr(cfg, "export", {}).get("debounce_minutes", 3))
    max_shift_hours = int(getattr(cfg, "export", {}).get("max_shift_hours", 24))
    hybrid_close = getattr(cfg, "export", {}).get("hybrid_close") or {}

    d0 = date.fromisoformat(str(start_op_date).strip())
    d1 = date.fromisoformat(str(end_op_date).strip())
    if d1 < d0:
        d0, d1 = d1, d0

    # 1) Clear computed jornadas only (keep patterns)
    if hasattr(db, "clear_jornadas"):
        db.clear_jornadas(preserve_patterns=True)
    if hasattr(db, "reset_employee_state_preserve_patterns"):
        db.reset_employee_state_preserve_patterns()

    # 2) Set index cursor to (d0 - 1) at shift_cutoff (UTC)
    ctx_date = d0 - timedelta(days=1)
    hh, mm_ = [int(x) for x in shift_cutoff.split(":", 1)]
    start_local = datetime(ctx_date.year, ctx_date.month, ctx_date.day, hh, mm_, 0, tzinfo=tz)
    start_ctx_utc = start_local.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"
    if hasattr(db, "upsert_state"):
        db.upsert_state("jornada_index_last_utc", start_ctx_utc)

    # 3) Index until (d1 + 1) at close_lookahead (UTC)
    hh2, mm2 = [int(x) for x in close_lookahead.split(":", 1)]
    end_local = datetime(d1.year, d1.month, d1.day, hh2, mm2, 0, tzinfo=tz) + timedelta(days=1)
    end_utc = end_local.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"

    info = ensure_jornadas_indexed_until(
        db,
        end_utc_iso=end_utc,
        device_tz=tz,
        cutoff_hhmm=shift_cutoff,
        break_max_minutes=break_max_minutes,
        rest_min_minutes=rest_min_minutes,
        debounce_minutes=debounce_minutes,
        max_shift_hours=max_shift_hours,
        rebuild=False,
        hybrid_close=hybrid_close,
    )
    return {"start_ctx_utc": start_ctx_utc, "end_utc": end_utc, "ensure_info": info}

def _download_file(path: str, label: str):
    if not path or not os.path.exists(path):
        st.error("Archivo no disponible")
        return
    with open(path, "rb") as f:
        data = f.read()
    # `use_container_width` is deprecated; span the full container via width="stretch"【968516149440567†L213-L223】
    st.download_button(label=label, data=data, file_name=os.path.basename(path), width="stretch")



def render():
    bootstrap_page("Consola | URSOMEX", page_icon="🧰")

    render_sidebar_settings()

    data_dir = get_data_dir()
    login_panel(data_dir)

    u = current_user()
    if not u:
        st.warning("Inicia sesión para usar la consola.")
        return

    rt = get_runtime()

    render_topbar("Consola", "Operaciones seguras. Se ejecutan acciones permitidas del collector.")
    
    st.caption("Modo seguro activo. No se permiten comandos arbitrarios del sistema.")

    st.divider()

    # --- Safe commands ---
    st.subheader("Comandos seguros")
    cmd_key = st.selectbox(
        "Operación",
        options=[c.key for c in SAFE_COMMANDS],
        format_func=lambda k: next(c.title for c in SAFE_COMMANDS if c.key == k),
    )
    st.info(next(c.description for c in SAFE_COMMANDS if c.key == cmd_key))

    if st.button("Ejecutar", width="stretch"):
        try:
            if cmd_key == "status":
                s = rt.status()
                st.success("OK")
                st.json(s.__dict__)
            elif cmd_key == "ping":
                ok = rt.ping()
                st.success("Ping OK" if ok else "Ping NO")
            elif cmd_key == "pull_once":
                n = rt.pull_once()
                st.success(f"Pull OK. Insertados: {n}")
            elif cmd_key == "start_normal":
                st.success(rt.start_loop(realtime=False))
            elif cmd_key == "start_realtime":
                st.success(rt.start_loop(realtime=True))
            elif cmd_key == "stop":
                st.success(rt.stop_loop())
        except Exception as e:
            st.error(f"Error: {e}")

    st.divider()

    # --- Backfill ---
    st.subheader("Backfill")
    with st.expander("Ejecutar backfill", expanded=False):
        mode = st.radio("Tipo", ["Últimos N días", "Un día", "Rango de días", "Semana operativa (Mié→Mar)", "Ventana HH:MM"], horizontal=True)
        chunk = st.number_input("chunk_hours", min_value=1, max_value=48, value=6)

        if mode == "Últimos N días":
            days = st.number_input("Días", min_value=1, max_value=365, value=7)
            if st.button("Backfill", key="bf_ndays", width="stretch"):
                n = rt.backfill_days(int(days), chunk_hours=int(chunk))
                st.success(f"Backfill OK. Insertados: {n}")

        elif mode == "Un día":
            day = st.date_input("Día", value=datetime.now().date())
            if st.button("Backfill", key="bf_day", width="stretch"):
                n = rt.backfill_one_day(day.isoformat(), chunk_hours=int(chunk))
                st.success(f"Backfill OK. Insertados: {n}")

        elif mode == "Rango de días":
            c1, c2 = st.columns(2)
            with c1:
                d1 = st.date_input("Inicio", value=datetime.now().date())
            with c2:
                d2 = st.date_input("Fin", value=datetime.now().date())
            if st.button("Backfill", key="bf_range", width="stretch"):
                n = rt.backfill_range_days(d1.isoformat(), d2.isoformat(), chunk_hours=int(chunk))
                st.success(f"Backfill OK. Insertados: {n}")

        elif mode == "Semana operativa (Mié→Mar)":
            day = st.date_input("Cualquier día dentro de la semana", value=datetime.now().date())
            if st.button("Backfill", key="bf_opweek", width="stretch"):
                n = rt.backfill_operational_week_containing(day.isoformat(), chunk_hours=int(chunk))
                st.success(f"Backfill OK. Insertados: {n}")

        else:
            s1 = st.text_input("Inicio local", value=f"{datetime.now().date().isoformat()} 04:00")
            s2 = st.text_input("Fin local", value=f"{datetime.now().date().isoformat()} 18:00")
            if st.button("Backfill", key="bf_window", width="stretch"):
                n, start_utc, end_utc = rt.backfill_window(s1, s2, chunk_hours=int(chunk))
                st.success(f"Backfill OK. Insertados: {n}")
                st.caption(f"UTC: {start_utc} → {end_utc}")

    st.divider()

    # --- Export ---
    st.subheader("Export")
    with st.expander("Exportar Excel diario", expanded=False):
        op_day = st.date_input("op_date", value=datetime.now().date())
        source_label = st.text_input("Etiqueta fuente", value="DB")

        flt = render_area_filter(st, data_dir, key_prefix="console__filtro_por_reas_excel_diario", title="Filtro por áreas · Excel diario", default_order_by_area=True)

        filter_active = bool(flt["filter_active"])
        final_ids = flt["employee_ids"]
        order_ids = flt["order_employee_ids"]

        if st.button("Generar Excel", width="stretch"):
            try:
                src = source_label.strip() or "DB"
                if filter_active:
                    order_ids = order_ids
                    out = rt.export_daily_excel_filtered(op_day.isoformat(), employee_ids=final_ids, source_label=src, order_employee_ids=order_ids)
                else:
                    out = rt.export_daily_excel(op_day.isoformat(), source_label=src)
                st.success("Export OK")
                st.write(out)
                _download_file(out, "Descargar Excel")
            except Exception as e:
                st.error(f"Error export: {e}")

    
    with st.expander("Exportar Excel por rango (op_date)", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            d1 = st.date_input("Inicio (op_date)", value=datetime.now().date(), key="rng_d1")
        with c2:
            d2 = st.date_input("Fin (op_date)", value=datetime.now().date(), key="rng_d2")
        source_label2 = st.text_input("Etiqueta fuente", value="DB", key="rng_src")

        flt = render_area_filter(st, data_dir, key_prefix="console__filtro_por_reas_excel_rango", title="Filtro por áreas · Excel rango", default_order_by_area=True)
        filter_active = bool(flt["filter_active"])
        final_ids = flt["employee_ids"]
        order_ids = flt["order_employee_ids"]

        if st.button("Generar Excel (rango)", width="stretch", key="rng_btn"):
            try:
                src = source_label2.strip() or "DB"
                if filter_active:
                    out = rt.export_range_excel_filtered(d1.isoformat(), d2.isoformat(), employee_ids=final_ids, source_label=src, order_employee_ids=order_ids)
                else:
                    out = rt.export_range_excel(d1.isoformat(), d2.isoformat(), source_label=src)
                st.success("Export OK")
                st.write(out)
                _download_file(out, "Descargar Excel")
            except Exception as e:
                st.error(f"Error export: {e}")

    with st.expander("Exportar Excel semana operativa (Mié→Mar)", expanded=False):
        day = st.date_input("Cualquier día dentro de la semana", value=datetime.now().date(), key="opw_day")
        source_label3 = st.text_input("Etiqueta fuente", value="DB", key="opw_src")

        flt = render_area_filter(st, data_dir, key_prefix="console__filtro_por_reas_excel_semana_operativa", title="Filtro por áreas · Excel semana operativa", default_order_by_area=True)
        filter_active = bool(flt["filter_active"])
        final_ids = flt["employee_ids"]
        order_ids = flt["order_employee_ids"]

        if st.button("Generar Excel (semana operativa)", width="stretch", key="opw_btn"):
            try:
                src = source_label3.strip() or "DB"
                if filter_active:
                    out = rt.export_operational_week_excel_filtered(day.isoformat(), employee_ids=final_ids, source_label=src, order_employee_ids=order_ids)
                else:
                    out = rt.export_operational_week_excel(day.isoformat(), source_label=src)
                st.success("Export OK")
                st.write(out)
                _download_file(out, "Descargar Excel")
            except Exception as e:
                st.error(f"Error export: {e}")

    with st.expander("Exportar CSV processed_events (rango op_date)", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            p1 = st.date_input("Inicio", value=datetime.now().date(), key="pcsv_d1")
        with c2:
            p2 = st.date_input("Fin", value=datetime.now().date(), key="pcsv_d2")
        src4 = st.text_input("Etiqueta fuente", value="DB", key="pcsv_src")

        flt = render_area_filter(st, data_dir, key_prefix="console__filtro_por_reas_csv_processed", title="Filtro por áreas · CSV processed", default_order_by_area=True)
        filter_active = bool(flt["filter_active"])
        final_ids = flt["employee_ids"]
        order_ids = flt["order_employee_ids"]

        if st.button("Generar CSV (processed)", width="stretch", key="pcsv_btn"):
            try:
                out = rt.export_processed_csv_range(
                    p1.isoformat(),
                    p2.isoformat(),
                    source_label=(src4.strip() or "DB"),
                    employee_ids=(final_ids if filter_active else None),
                    order_employee_ids=(order_ids if filter_active else None),
                )
                st.success("Export OK")
                st.write(out)
                _download_file(out, "Descargar CSV")
            except Exception as e:
                st.error(f"Error export: {e}")

    with st.expander("Exportar CSV raw_events (ventana local)", expanded=False):
        st.caption("Convierte ventana local a UTC y exporta raw_events. Si hay filtro por áreas, se filtra parseando payload_json.")
        s1 = st.text_input("Inicio local", value=f"{datetime.now().date().isoformat()} 04:00", key="rcsv_s1")
        s2 = st.text_input("Fin local", value=f"{datetime.now().date().isoformat()} 18:00", key="rcsv_s2")
        src5 = st.text_input("Etiqueta fuente", value="DB", key="rcsv_src")

        flt = render_area_filter(st, data_dir, key_prefix="console__filtro_por_reas_csv_raw", title="Filtro por áreas · CSV raw", default_order_by_area=True)
        filter_active = bool(flt["filter_active"])
        final_ids = flt["employee_ids"]
        order_ids = flt["order_employee_ids"]

        if st.button("Generar CSV (raw)", width="stretch", key="rcsv_btn"):
            try:
                tz = rt._device_tz()
                start_utc, end_utc = local_window_to_utc(s1, s2, device_tz=tz)
                start_iso = start_utc.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"
                end_iso = end_utc.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"

                out = rt.export_raw_csv_range(
                    start_iso,
                    end_iso,
                    source_label=(src5.strip() or "DB"),
                    employee_ids=(final_ids if filter_active else None),
                    order_employee_ids=(order_ids if filter_active else None),
                )
                st.success("Export OK")
                st.caption(f"UTC: {start_iso} → {end_iso}")
                st.write(out)
                _download_file(out, "Descargar CSV")
            except Exception as e:
                st.error(f"Error export: {e}")

    st.divider()

    # --- Imports ---
    st.subheader("Import")
    with st.expander("Importar JSONL (raw + processed)", expanded=False):
        up = st.file_uploader("Archivo .jsonl", type=["jsonl"])
        persist = st.checkbox("Persistir en DB", value=True)
        if st.button("Importar", width="stretch", disabled=up is None):
            if up is None:
                st.warning("Selecciona un archivo")
            else:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".jsonl") as tmp:
                    tmp.write(up.getbuffer())
                    tmp_path = tmp.name
                raw_n, rrhh_n, err_n = rt.import_jsonl(tmp_path, persist_to_db=persist)
                st.success(f"Import OK | raw={raw_n} rrhh={rrhh_n} err={err_n}")

    with st.expander("Importar CORRECCIONES + rebuild jornadas", expanded=False):
        upx = st.file_uploader("Archivo .xlsx", type=["xlsx"], key="corr_xlsx")
        if st.button("Importar y Rebuild", width="stretch", disabled=upx is None):
            if upx is None:
                st.warning("Selecciona un archivo")
            else:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                    tmp.write(upx.getbuffer())
                    tmp_path = tmp.name
                try:
                    info = rt.import_corrections_excel_and_rebuild(tmp_path)
                    st.success("OK")
                    st.json(info)
                except Exception as e:
                    st.error(f"Error: {e}")

    with st.expander("Rebuild / Indexar jornadas (sin borrar patrones)", expanded=False):
        is_admin = str(getattr(u, "role", "") or "").lower() == "admin"
        if not is_admin:
            st.info("Disponible solo para ADMIN.")
        else:
            st.write("Recalcula (re-indexa) las jornadas dentro de un rango, **sin borrar patrones aprendidos**.")
            c1, c2 = st.columns(2)
            d0 = c1.date_input("Desde (fecha operativa)", value=date.today() - timedelta(days=7), key="rb_idx_d0")
            d1 = c2.date_input("Hasta (fecha operativa)", value=date.today(), key="rb_idx_d1")

            if st.button("Rebuild / Indexar", type="primary", width="stretch", key="rb_idx_go"):
                with st.spinner("Re-indexando jornadas..."):
                    info = rt.rebuild_indexar_jornadas_range(str(d0), str(d1)) if hasattr(rt, 'rebuild_indexar_jornadas_range') else _fallback_rebuild_indexar_jornadas_range(rt, str(d0), str(d1))
                st.success("Indexación completada.")
                st.json(info)

    st.divider()

    # --- Logs ---
    st.subheader("Logs")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("**Buffer (sesión)**")
        lines = rt.log_handler.tail(450) if rt.log_handler else []
        st.markdown('<div class="ursomex-logbox">' + "<br/>".join([html.escape(x).replace("\n", "<br/>") for x in lines]) + "</div>", unsafe_allow_html=True)

    with col2:
        st.markdown("**Archivo**")
        log_path = os.path.join(rt.cfg.storage["data_dir"], "logs", "collector.log")
        flines = tail_file(log_path, max_lines=450)
        st.markdown('<div class="ursomex-logbox">' + "<br/>".join([html.escape(x).replace("\n", "<br/>") for x in flines]) + "</div>", unsafe_allow_html=True)


if __name__ == "__main__":
    render()