from __future__ import annotations

import os
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pandas as pd
import streamlit as st

from collector.config import load_config
from components.auth_ui import login_panel, current_user
from components.layout import inject_global_css, render_topbar, section_header
from components.ui import theme_css, kpi_card
from utils.areas_store import list_areas
from utils.runtime_store import set_cfg_path, get_cfg_path, get_runtime


APP_TITLE = "URSOMEX | Colector de Eventos (Web)"


def _apply_styles() -> None:
    accent = st.session_state.get("accent_color", "#2BBBAD")
    st.markdown(theme_css(st.session_state.get("theme", "ursomex"), accent_hex=accent), unsafe_allow_html=True)
    inject_global_css()


def _sidebar_settings() -> None:
    st.sidebar.markdown("### Ajustes")

    lp = os.path.join("static", "logo.png")
    if os.path.exists(lp):
        # `use_column_width` is deprecated; use width="stretch" to fill the sidebar
        st.sidebar.image(lp, width="stretch")

    cfg_path = st.sidebar.text_input(
        "Ruta config.json",
        value=get_cfg_path(),
        help="Ruta relativa o absoluta al config.json del collector.",
    )
    if cfg_path and cfg_path != get_cfg_path():
        set_cfg_path(cfg_path)

    theme = st.sidebar.selectbox("Tema", ["ursomex", "minimalista", "tecnologico"], index=0)
    st.session_state["theme"] = theme
    st.session_state["accent_color"] = st.sidebar.color_picker(
        "Color acento", value=st.session_state.get("accent_color", "#2BBBAD")
    )


def _distinct_employee_ids(db, start_date: str, end_date: str | None = None) -> set[str]:
    """Return distinct employee_id with events in processed_events for a date or range (inclusive)."""
    if not db or getattr(db, "engine", "").lower() != "sqlite":
        return set()

    if end_date and end_date != start_date:
        q = (
            "SELECT DISTINCT employee_id "
            "FROM processed_events "
            "WHERE event_date>=? AND event_date<=? AND employee_id IS NOT NULL AND employee_id!=''"
        )
        params = (str(start_date), str(end_date))
    else:
        q = (
            "SELECT DISTINCT employee_id "
            "FROM processed_events "
            "WHERE event_date=? AND employee_id IS NOT NULL AND employee_id!=''"
        )
        params = (str(start_date),)

    try:
        with db._lock:
            rows = db._conn.execute(q, params).fetchall()
    except Exception:
        return set()

    out = set()
    for r in rows or []:
        if not r:
            continue
        x = str(r[0]).strip()
        if x:
            out.add(x)
    return out


def main() -> None:
    st.set_page_config(
        page_title=APP_TITLE,
        page_icon=os.path.join("static", "favicon.png"),
        layout="wide",
        initial_sidebar_state="expanded",
        menu_items={"Get help": None, "Report a bug": None, "About": None},
    )

    _sidebar_settings()
    _apply_styles()

    try:
        cfg = load_config(get_cfg_path())
        data_dir = cfg.storage["data_dir"]
    except Exception as e:
        render_topbar("Configuración", "No se pudo cargar el config.json")
        st.error(f"No se pudo cargar config: {e}")
        st.stop()

    login_panel(data_dir)

    u = current_user()
    if not u:
        st.warning("Inicia sesión para usar la interfaz.")
        return

    render_topbar("Inicio", "Resumen ejecutivo de actividad y accesos rápidos.")

    st.markdown(
        """
<div class='ursomex-card'>
  <div style='font-weight:750; margin-bottom:0.35rem;'>Panel principal</div>
  <div style='color:rgba(15,23,42,0.70); font-size:0.92rem; line-height:1.45;'>
    Usa el menú lateral para abrir <b>Dashboard</b>, <b>Consola</b>, <b>Cálculo de Asistencia</b> y <b>Admin</b>.
    Los cálculos y exportaciones se generan desde la base del collector.
  </div>
</div>
""",
        unsafe_allow_html=True,
    )

    # --- Activity KPIs (processed_events) ---
    tz_name = str(getattr(cfg, "device_timezone", "") or "UTC")
    try:
        tz = ZoneInfo(tz_name)
    except Exception:
        tz = ZoneInfo("UTC")
        tz_name = "UTC"

    today_d = datetime.now(tz).date()
    today = today_d.isoformat()
    yesterday = (today_d - timedelta(days=1)).isoformat()
    start_30 = (today_d - timedelta(days=29)).isoformat()

    rt = None
    db = None
    try:
        rt = get_runtime()
        db = rt.svc.db if rt and getattr(rt, "svc", None) else None
    except Exception:
        rt = None
        db = None

    section_header("Actividad", f"Hoy: {today} · Zona horaria del dispositivo: {tz_name}")

    if not db or getattr(db, "engine", "").lower() != "sqlite":
        st.info("No se pudo abrir la base de datos (o no es SQLite). Los KPIs de actividad no están disponibles aquí.")
    else:
        active_today_ids = _distinct_employee_ids(db, today)
        active_yesterday_ids = _distinct_employee_ids(db, yesterday)
        total_30_ids = _distinct_employee_ids(db, start_30, today)

        active_today = len(active_today_ids)
        active_yesterday = len(active_yesterday_ids)
        delta = active_today - active_yesterday
        total_30 = len(total_30_ids)
        inactive_today = max(total_30 - active_today, 0)

        c1, c2, c3, c4, c5 = st.columns(5)
        with c1:
            st.markdown(
                kpi_card(
                    "Activos hoy",
                    f"{active_today}",
                    subtitle=f"Ayer: {active_yesterday}",
                    delta_text=f"{delta:+d}",
                ),
                unsafe_allow_html=True,
            )
        with c2:
            st.markdown(kpi_card("Activos ayer", f"{active_yesterday}", subtitle=f"Fecha: {yesterday}"), unsafe_allow_html=True)
        with c3:
            st.markdown(kpi_card("Delta", f"{delta:+d}", subtitle="Activos hoy − activos ayer"), unsafe_allow_html=True)
        with c4:
            st.markdown(
                kpi_card(
                    "Inactivos hoy",
                    f"{inactive_today}",
                    subtitle="Total 30 días − activos hoy",
                ),
                unsafe_allow_html=True,
            )
        with c5:
            st.markdown(kpi_card("Total 30 días", f"{total_30}", subtitle=f"{start_30} → {today}"), unsafe_allow_html=True)

        # --- By areas (web_areas.json) ---
        areas = list_areas(data_dir)
        rows = []
        for a in areas:
            code = str(a.get("code") or "").strip()
            if not code:
                continue
            name = str(a.get("name") or code).strip()
            members = [str(x).strip() for x in (a.get("members") or []) if str(x).strip()]
            mset = set(members)

            rows.append(
                {
                    "Área": f"{code} · {name}" if name and name != code else code,
                    "Miembros": len(mset),
                    "Activos hoy": len(active_today_ids.intersection(mset)) if mset else 0,
                    "Activos ayer": len(active_yesterday_ids.intersection(mset)) if mset else 0,
                }
            )

        if rows:
            df = pd.DataFrame(rows)
            df["Delta"] = df["Activos hoy"] - df["Activos ayer"]

            section_header("Resumen por áreas", "Activos hoy vs ayer por grupo (web_areas.json).")
            st.dataframe(df, width="stretch", hide_index=True)

            try:
                chart_df = df.set_index("Área")[["Activos hoy"]]
                st.bar_chart(chart_df)
            except Exception:
                pass


if __name__ == "__main__":
    main()
