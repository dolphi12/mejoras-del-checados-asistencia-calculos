from __future__ import annotations

import importlib.util
from pathlib import Path
import pytest
import pandas as pd

_PAGE_PATH = Path(__file__).resolve().parents[1] / "pages" / "04_Calculo_Asistencia.py"
_SPEC = importlib.util.spec_from_file_location("page_calculo_asistencia", str(_PAGE_PATH))
_MODULE = None
try:
    import streamlit  # noqa: F401
    if _SPEC and _SPEC.loader:
        _MODULE = importlib.util.module_from_spec(_SPEC)
        _SPEC.loader.exec_module(_MODULE)
except ModuleNotFoundError:
    # When streamlit is not available, skip tests that require the page
    pytest.skip("streamlit no está instalado, omitiendo pruebas de la página", allow_module_level=True)


def test_build_filtered_view_applies_filters_and_uses_current_state():
    show_cols = ["ID", "NOMBRE", "TIEMPO TRABAJADO", "_ALERTA"]
    df = pd.DataFrame(
        [
            {"ID": "10", "NOMBRE": "Ana", "TIEMPO TRABAJADO": "08:00", "_ALERTA": ""},
            {"ID": "11", "NOMBRE": "Beto", "TIEMPO TRABAJADO": "09:15", "_ALERTA": "Falta salida"},
        ]
    )

    out = _MODULE._build_filtered_view(df, show_cols, search_id="11", search_name="", only_alert=True)

    assert len(out) == 1
    assert out.iloc[0]["ID"] == "11"
    assert out.iloc[0]["TIEMPO TRABAJADO"] == "09:15"
