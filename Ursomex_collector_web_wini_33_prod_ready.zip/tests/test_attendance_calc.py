from datetime import datetime

import pandas as pd

from utils.attendance_calc import compute_attendance_from_events, autodetect_permiso_detail_from_eventos, recalc_attendance_table
from utils.attendance_rules import AttendanceRules


def test_lunch_discount_rule_60_minutes():
    row = compute_attendance_from_events(
        op_date="2026-02-24",
        employee_id="1",
        employee_name="X",
        start_local=datetime(2026, 2, 24, 6, 0),
        end_local=None,
        event_times_hhmm=["06:00", "11:00", "12:00", "16:00"],  # entry, lunch out/in, exit
    )
    # gross = 10h = 600
    # lunch 60 => discount 30
    assert row.descuento_no_laborado_hhmm == "00:30"
    assert row.tiempo_trabajado_hhmm == "09:30"
    assert row.horas_extra_hhmm == "01:30"


def test_lunch_discount_rule_65_minutes_full():
    row = compute_attendance_from_events(
        op_date="2026-02-24",
        employee_id="1",
        employee_name="X",
        start_local=datetime(2026, 2, 24, 6, 0),
        end_local=None,
        event_times_hhmm=["06:00", "11:00", "12:05", "16:00"],
    )
    # gross 600, lunch 65 => discount 65
    assert row.descuento_no_laborado_hhmm == "01:05"
    assert row.tiempo_trabajado_hhmm == "08:55"
    assert row.horas_extra_hhmm == "00:55"


def test_dinner_discount_full_and_permissions():
    row = compute_attendance_from_events(
        op_date="2026-02-24",
        employee_id="1",
        employee_name="X",
        start_local=datetime(2026, 2, 24, 6, 0),
        end_local=None,
        # entry, lunch out/in, dinner out/in, perm out/in, exit
        event_times_hhmm=["06:00", "11:00", "12:00", "16:00", "16:30", "18:00", "18:15", "20:00"],
    )
    # gross 14h = 840
    # lunch 60 => 30; dinner 30; permiso 15 => total 75
    assert row.descuento_no_laborado_hhmm == "01:15"
    assert row.tiempo_trabajado_hhmm == "12:45"
    assert row.horas_extra_hhmm == "04:45"


def test_custom_rules_lunch_and_overtime_threshold():
    rules = AttendanceRules(
        lunch_threshold_minutes=90,
        lunch_discount_minutes_if_within=45,
        lunch_threshold_inclusive=True,
        lunch_mode="fixed_if_within_else_full",
        overtime_threshold_minutes=9 * 60,
        compute_overtime=True,
    )
    row = compute_attendance_from_events(
        op_date="2026-02-24",
        employee_id="1",
        employee_name="X",
        start_local=datetime(2026, 2, 24, 6, 0),
        end_local=None,
        event_times_hhmm=["06:00", "11:00", "12:00", "16:00"],
        rules=rules,
    )
    # gross 600, lunch 60 => discount 45, net 555 => overtime vs 540 => 15 min
    assert row.descuento_no_laborado_hhmm == "00:45"
    assert row.tiempo_trabajado_hhmm == "09:15"
    assert row.horas_extra_hhmm == "00:15"


def test_permiso_intervals_override_pairs():
    rules = AttendanceRules()
    row = compute_attendance_from_events(
        op_date="2026-02-24",
        employee_id="1",
        employee_name="X",
        start_local=datetime(2026, 2, 24, 6, 0),
        end_local=None,
        event_times_hhmm=["06:00", "11:00", "12:00", "16:00"],  # no permiso events
        permiso_override_minutes=0,
        permiso_intervals_override=[("13:00", "13:30"), ("14:00", "14:10")],
        rules=rules,
    )
    # gross 600, lunch 60 => 30, permisos 40 => total discount 70, net 530 => overtime 50
    assert row.permiso_hhmm == "00:40"
    assert row.descuento_no_laborado_hhmm == "01:10"
    assert row.tiempo_trabajado_hhmm == "08:50"
    assert row.horas_extra_hhmm == "00:50"


def test_autodetect_permiso_detail_from_eventos():
    eventos = "06:00, 11:00, 12:00, 16:00, 16:30, 18:00, 18:15, 20:00"
    assert autodetect_permiso_detail_from_eventos(eventos) == "18:00-18:15"


def test_recalc_uses_permiso_detalle_over_total():
    df = pd.DataFrame(
        [
            {
                "ID": "1",
                "FECHA": "2026-02-24",
                "NOMBRE": "X",
                "ENTRADA": "06:00",
                "SALIDA A COMER": "11:00",
                "REGRESO DE COMER": "12:00",
                "SALIDA A CENAR": "16:00",
                "REGRESO DE CENAR": "16:30",
                "SALIDA": "20:00",
                "PERMISO": "00:00",  # should be overridden by detail
                "PERMISOS DETALLE": "18:00-18:15",
            }
        ]
    )
    out = recalc_attendance_table(df)
    r = out.iloc[0].to_dict()
    assert r["PERMISO"] == "00:15"
    # gross 14h (06:00-20:00)=840; lunch 60=>30; dinner 30; permiso 15 => discount 75
    assert r["DESCUENTO NO LABORADO"] == "01:15"
    assert r["TIEMPO TRABAJADO"] == "12:45"
    assert r["HORAS EXTRA"] == "04:45"
