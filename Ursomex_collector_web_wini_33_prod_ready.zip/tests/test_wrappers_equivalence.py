from __future__ import annotations

import os
from datetime import datetime

from utils.wrappers import CollectorRuntime
from openpyxl import load_workbook


def test_status_matches_db(temp_cfg: str):
    rt = CollectorRuntime(cfg_path=temp_cfg)
    try:
        s = rt.status()
        today = rt.local_today_iso()

        assert s.today_local == today
        assert s.processed_total == int(rt.svc.db.count_processed() or 0)
        assert s.raw_total == int(rt.svc.db.count_raw() or 0)
        assert s.rrhh_today == int(rt.svc.db.count_processed_by_date(today) or 0)
        assert s.audit_today == int(rt.svc.db.count_raw_by_date(today) or 0)

        vm = rt.svc.db.get_verify_mode_counts_raw_by_date(today) or {}
        assert s.verify_total == int(vm.get("total", 0) or 0)
        assert s.verify_invalid == int(vm.get("invalid", 0) or 0)
        assert s.verify_valid == int(vm.get("valid", 0) or 0)

    finally:
        rt.close()


def test_export_creates_excel(temp_cfg: str, tmp_path):
    rt = CollectorRuntime(cfg_path=temp_cfg)
    try:
        # choose a date that exists in sim30
        op_day = "2026-01-10"
        out = rt.export_daily_excel(op_day, source_label="DB")
        assert out.endswith(".xlsx")
        assert os.path.exists(out)
        assert os.path.getsize(out) > 0
    finally:
        rt.close()


def test_export_filtered_excel(temp_cfg: str):
    rt = CollectorRuntime(cfg_path=temp_cfg)
    try:
        op_day = "2026-01-10"
        base = rt.export_daily_excel(op_day, source_label="DB")
        wb = load_workbook(base)
        ws = wb["JORNADAS_CIERRE"]
        headers = [c.value for c in ws[1]]
        emp_idx = headers.index("employee_id") + 1
        uniq = []
        seen = set()
        for r in range(2, ws.max_row + 1):
            v = ws.cell(row=r, column=emp_idx).value
            s = str(v).strip() if v is not None else ""
            if s and s not in seen:
                uniq.append(s)
                seen.add(s)
        assert len(uniq) >= 2
        chosen = uniq[:3]
        order = list(reversed(chosen))

        out = rt.export_daily_excel_filtered(op_day, employee_ids=chosen, source_label="DB", order_employee_ids=order)
        assert out.endswith(".xlsx")
        assert os.path.exists(out)

        wb2 = load_workbook(out)
        ws2 = wb2["JORNADAS_CIERRE"]
        headers2 = [c.value for c in ws2[1]]
        emp_idx2 = headers2.index("employee_id") + 1
        allowed = set(chosen)
        first_emp = None
        for r in range(2, ws2.max_row + 1):
            v = ws2.cell(row=r, column=emp_idx2).value
            s = str(v).strip() if v is not None else ""
            assert s in allowed
            if first_emp is None and s:
                first_emp = s

        # best-effort: ordering by employee_id list should place the first order id first if present
        if first_emp is not None:
            assert first_emp == order[0]
    finally:
        rt.close()


def test_export_range_excel_and_filtered(temp_cfg: str):
    rt = CollectorRuntime(cfg_path=temp_cfg)
    try:
        start_op = "2026-01-10"
        end_op = "2026-01-12"
        base = rt.export_range_excel(start_op, end_op, source_label="DB")
        assert base.endswith(".xlsx")
        assert os.path.exists(base)

        wb = load_workbook(base)
        ws = wb["JORNADAS_CIERRE"]
        headers = [c.value for c in ws[1]]
        emp_idx = headers.index("employee_id") + 1
        uniq = []
        seen = set()
        for r in range(2, ws.max_row + 1):
            v = ws.cell(row=r, column=emp_idx).value
            s = str(v).strip() if v is not None else ""
            if s and s not in seen:
                uniq.append(s)
                seen.add(s)
        assert len(uniq) >= 2
        chosen = uniq[:4]
        order = chosen[:]  # preserve as-is

        out = rt.export_range_excel_filtered(start_op, end_op, employee_ids=chosen, source_label="DB", order_employee_ids=order)
        assert out.endswith(".xlsx")
        assert os.path.exists(out)

        wb2 = load_workbook(out)
        ws2 = wb2["JORNADAS_CIERRE"]
        headers2 = [c.value for c in ws2[1]]
        emp_idx2 = headers2.index("employee_id") + 1
        allowed = set(chosen)
        for r in range(2, ws2.max_row + 1):
            v = ws2.cell(row=r, column=emp_idx2).value
            s = str(v).strip() if v is not None else ""
            assert s in allowed
    finally:
        rt.close()


def test_export_operational_week_excel(temp_cfg: str):
    rt = CollectorRuntime(cfg_path=temp_cfg)
    try:
        day = "2026-01-10"
        out = rt.export_operational_week_excel(day, source_label="DB")
        assert out.endswith(".xlsx")
        assert os.path.exists(out)
        assert os.path.getsize(out) > 0
    finally:
        rt.close()


def test_export_processed_csv_range_filtered(temp_cfg: str):
    rt = CollectorRuntime(cfg_path=temp_cfg)
    try:
        start_op = "2026-01-10"
        end_op = "2026-01-10"
        # use daily export to pick a few employee_ids
        xlsx = rt.export_daily_excel(start_op, source_label="DB")
        wb = load_workbook(xlsx)
        ws = wb["JORNADAS_CIERRE"]
        headers = [c.value for c in ws[1]]
        emp_idx = headers.index("employee_id") + 1
        uniq = []
        seen = set()
        for r in range(2, ws.max_row + 1):
            v = ws.cell(row=r, column=emp_idx).value
            s = str(v).strip() if v is not None else ""
            if s and s not in seen:
                uniq.append(s)
                seen.add(s)
        chosen = uniq[:3]
        out = rt.export_processed_csv_range(start_op, end_op, source_label="DB", employee_ids=chosen, order_employee_ids=chosen)
        assert out.endswith(".csv")
        assert os.path.exists(out)
        assert os.path.getsize(out) > 0
    finally:
        rt.close()
