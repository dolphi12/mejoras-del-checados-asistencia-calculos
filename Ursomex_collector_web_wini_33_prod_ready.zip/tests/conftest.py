from __future__ import annotations

import sys

import json
import shutil
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


import pytest


@pytest.fixture()
def temp_cfg(tmp_path: Path) -> str:
    root = Path(__file__).resolve().parents[1]
    base_cfg = json.loads((root / "config.web.json").read_text(encoding="utf-8"))

    data_dir = tmp_path / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    # copy sqlite
    sqlite_src = root / "storage" / "sim30.sqlite"
    sqlite_dst = data_dir / "collector.sqlite"
    shutil.copy2(sqlite_src, sqlite_dst)

    base_cfg["storage"]["data_dir"] = str(data_dir)
    base_cfg["database"]["engine"] = "sqlite"
    base_cfg["database"]["sqlite_path"] = str(sqlite_dst)

    cfg_path = tmp_path / "config.test.json"
    cfg_path.write_text(json.dumps(base_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(cfg_path)
