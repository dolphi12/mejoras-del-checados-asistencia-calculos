from __future__ import annotations

import os
import tempfile

import pandas as pd

from utils.attendance_upload_excel import parse_upload_excel


def _write_xlsx(df: pd.DataFrame) -> str:
    """Write a DataFrame to a temp xlsx with sheet JORNADAS_CIERRE."""
    tmpdir = tempfile.mkdtemp(prefix="test_asist_")
    path = os.path.join(tmpdir, "in.xlsx")
    with pd.ExcelWriter(path, engine="openpyxl") as w:
        df.to_excel(w, sheet_name="JORNADAS_CIERRE", index=False)
    return path


def test_cross_midnight_shift_is_computed_without_negative_duration():
    df = pd.DataFrame(
        [
            {
                "employee_id": "E01",
                "employee_name": "Ana",
                "fecha_registro": "2026-02-26",
                "E01": "23:00",
                "E02": "07:00",
            }
        ]
    )
    xlsx = _write_xlsx(df)
    out = parse_upload_excel(xlsx, jornada_base=480)
    assert int(out.iloc[0]["TIEMPO TRABAJADO (min)"]) == 480
    assert int(out.iloc[0]["HORAS EXTRA (min)"]) == 0
    assert str(out.iloc[0]["ALERTAS"] or "") == ""


def test_lunch_tolerance_window_applies_fixed_discount_when_within():
    # Lunch duration = 62 min (12:00 -> 13:02)
    df = pd.DataFrame(
        [
            {
                "employee_id": "E02",
                "employee_name": "Beto",
                "fecha_registro": "2026-02-26",
                "E01": "08:00",
                "E02": "12:00",
                "E03": "13:02",
                "E04": "17:00",
            }
        ]
    )
    xlsx = _write_xlsx(df)

    # With tolerance ±2, apply fixed 30
    out = parse_upload_excel(
        xlsx,
        jornada_base=480,
        lunch_expected_minutes=60,
        lunch_discount_minutes=30,
        lunch_tolerance_minus=2,
        lunch_tolerance_plus=2,
    )
    assert int(out.iloc[0]["DESCUENTO NO LABORADO (min)"]) == 30
    assert int(out.iloc[0]["TIEMPO TRABAJADO (min)"]) == 510
    assert int(out.iloc[0]["HORAS EXTRA (min)"]) == 30


def test_lunch_without_tolerance_uses_full_duration_discount():
    # Same input as previous test
    df = pd.DataFrame(
        [
            {
                "employee_id": "E03",
                "employee_name": "Caro",
                "fecha_registro": "2026-02-26",
                "E01": "08:00",
                "E02": "12:00",
                "E03": "13:02",
                "E04": "17:00",
            }
        ]
    )
    xlsx = _write_xlsx(df)
    out = parse_upload_excel(
        xlsx,
        jornada_base=480,
        lunch_expected_minutes=60,
        lunch_discount_minutes=30,
        lunch_tolerance_minus=0,
        lunch_tolerance_plus=0,
    )
    # Full lunch duration discount = 62
    assert int(out.iloc[0]["DESCUENTO NO LABORADO (min)"]) == 62
    assert int(out.iloc[0]["TIEMPO TRABAJADO (min)"]) == 478
    assert int(out.iloc[0]["HORAS EXTRA (min)"]) == 0


def test_blank_event_cells_are_ignored_not_counted_as_events():
    # Export-style rows often have E01..E12 with most cells blank.
    # Ensure blanks/NaN are not treated as literal "nan" events.
    df = pd.DataFrame(
        [
            {
                "employee_id": "E04",
                "employee_name": "Dani",
                "fecha_registro": "2026-02-26",
                "E01": "07:00",
                "E02": "15:00",
                "E03": "",
                "E04": "",
                "E05": "",
                "E06": "",
                "E07": "",
                "E08": "",
                "E09": "",
                "E10": "",
                "E11": "",
                "E12": "",
            }
        ]
    )
    xlsx = _write_xlsx(df)
    out = parse_upload_excel(xlsx, jornada_base=480)
    assert int(out.iloc[0]["TIEMPO TRABAJADO (min)"]) == 480
    assert str(out.iloc[0]["ALERTAS"] or "") == ""
