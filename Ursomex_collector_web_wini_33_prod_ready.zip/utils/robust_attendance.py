"""
Utility functions for computing attendance metrics using a robust event‑sourced
approach.  This module implements the pairing logic described in the
assistant's research: given a sequence of check‑in/out events for an
employee on a given day, it constructs working intervals, intersects them
with a scheduled shift window and returns several derived metrics such as
total worked time, missing time within the scheduled window, and different
overtime measures.

The main entry point is ``compute_summary`` which accepts a list of raw
events (timestamps and types), a schedule (shift start/end and break
minutes) and an instance of ``RobustRules``.  It returns a dict with
human‑readable HH:MM strings for each metric and a list of anomalies
encountered during pairing.

This implementation is standalone and does not modify the existing
attendance calculation logic in the project.  It can be used for
experimentation or to build new pages that adopt the more flexible
event‑sourced approach.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, date, time, timedelta
from typing import List, Tuple, Dict, Optional, Any

import math

try:
    # Python 3.9+: zoneinfo is standard
    from zoneinfo import ZoneInfo  # type: ignore
except Exception:
    ZoneInfo = None  # fall back to naive datetimes


@dataclass(frozen=True)
class RobustRules:
    """Configuration for the robust attendance calculator.

    - ``tz``: IANA timezone name used when localizing naive datetimes.
    - ``rounding_minutes``: resolution for rounding durations.  If set
      to 5, durations are rounded to the nearest multiple of 5 minutes.
    - ``rounding_mode``: one of ``nearest``, ``floor`` or ``ceil``.
    - ``overtime_threshold_minutes``: scheduled minutes above which
      overtime is computed.  If ``None`` or ``0``, overtime_excess_total
      is simply max(0, worked_total - scheduled_work).
    """

    tz: str = "America/Mexico_City"
    rounding_minutes: int = 5
    rounding_mode: str = "nearest"  # "nearest" | "floor" | "ceil"
    overtime_threshold_minutes: Optional[int] = 8 * 60


def _round_seconds(seconds: float, rules: RobustRules) -> int:
    """Round a duration in seconds according to rules.  Supports nearest,
    floor and ceil modes and clamps to zero for negative values."""
    if seconds is None or (isinstance(seconds, float) and math.isnan(seconds)):
        return 0
    seconds = max(0.0, float(seconds))
    step = max(1, rules.rounding_minutes * 60)
    mode = rules.rounding_mode
    if mode == "nearest":
        return int(round(seconds / step) * step)
    if mode == "floor":
        return int(math.floor(seconds / step) * step)
    if mode == "ceil":
        return int(math.ceil(seconds / step) * step)
    # Default to nearest
    return int(round(seconds / step) * step)


def _make_shift_window(work_date: date, shift_start: time, shift_end: time, tz: Optional[ZoneInfo]) -> Tuple[datetime, datetime]:
    """Construct start/end datetimes for a shift.  If shift_end <= shift_start
    the shift is assumed to cross midnight."""
    tzinfo = tz
    start_dt = datetime.combine(work_date, shift_start)
    end_dt = datetime.combine(work_date, shift_end)
    if tzinfo is not None:
        start_dt = start_dt.replace(tzinfo=tzinfo)
        end_dt = end_dt.replace(tzinfo=tzinfo)
    if end_dt <= start_dt:
        end_dt = end_dt + timedelta(days=1)
    return start_dt, end_dt


def _overlap_seconds(a_start: datetime, a_end: datetime, b_start: datetime, b_end: datetime) -> float:
    """Return the number of seconds of overlap between two [start, end) intervals."""
    if a_end <= a_start or b_end <= b_start:
        return 0.0
    start = max(a_start, b_start)
    end = min(a_end, b_end)
    if end <= start:
        return 0.0
    return (end - start).total_seconds()


def _pair_intervals(events: List[Tuple[datetime, str]], rules: RobustRules, shift_start_dt: Optional[datetime], shift_end_dt: Optional[datetime]) -> Tuple[List[Tuple[datetime, datetime]], List[str]]:
    """Pair IN/OUT events into intervals.  Returns a list of (start,end) and a list
    of anomaly messages.  Supports mismatched events and can optionally
    auto‑close an open interval at the end of the scheduled shift."""
    intervals: List[Tuple[datetime, datetime]] = []
    anomalies: List[str] = []
    open_in: Optional[datetime] = None
    for ts, typ in events:
        typ_u = str(typ or "").strip().upper()
        if typ_u == "IN":
            # If there's already an open IN, we replace it (drop previous)
            if open_in is not None:
                anomalies.append(
                    f"Doble IN: se reemplaza {open_in.isoformat()} por {ts.isoformat()}"
                )
            open_in = ts
        elif typ_u == "OUT":
            if open_in is None:
                anomalies.append(f"OUT sin IN: {ts.isoformat()} ignorado")
                continue
            if ts <= open_in:
                anomalies.append(
                    f"OUT {ts.isoformat()} antes o igual que IN {open_in.isoformat()} ignorado"
                )
                continue
            intervals.append((open_in, ts))
            open_in = None
        else:
            anomalies.append(f"Evento desconocido '{typ}' en {ts.isoformat()} ignorado")
    if open_in is not None:
        # If there's an open interval, close it at shift_end_dt if provided
        if shift_end_dt and shift_end_dt > open_in:
            anomalies.append(
                f"Intervalo abierto sin OUT para {open_in.isoformat()}, se cierra en {shift_end_dt.isoformat()}"
            )
            intervals.append((open_in, shift_end_dt))
        else:
            anomalies.append(f"Intervalo abierto sin OUT para {open_in.isoformat()} sin cierre")
    return intervals, anomalies


def hhmm_from_seconds(seconds: float) -> str:
    """Return an HH:MM string from seconds (non‑negative)."""
    seconds = max(0.0, float(seconds))
    minutes = int(round(seconds / 60.0))
    h = minutes // 60
    m = minutes % 60
    return f"{h:02d}:{m:02d}"


def compute_summary(
    event_times: List[Tuple[str, str]],
    work_date: date,
    shift_start: time,
    shift_end: time,
    break_minutes: int = 30,
    rules: Optional[RobustRules] = None,
    tz: Optional[str] = None,
) -> Dict[str, Any]:
    """Compute attendance metrics from raw events.  ``event_times`` must be a list
    of tuples ``(ts_str, typ)`` where ``ts_str`` is an ISO or ``YYYY‑MM‑DD HH:MM:SS``
    string and ``typ`` is either ``"IN"`` or ``"OUT"``.  ``work_date`` is the
    operational day (shift day).  ``shift_start``/``shift_end`` define the
    scheduled working window (may cross midnight).  ``break_minutes`` is the
    amount of meal break included in the schedule.  ``rules`` controls
    rounding and overtime calculations.

    Returns a dict with keys:

    - ``programado``: scheduled HH:MM (excluding break)
    - ``trabajado_total``: total time between each IN and OUT
    - ``trabajado_en_turno``: time worked within scheduled window
    - ``no_laborado_en_turno``: max(0, scheduled_work - worked_in_shift)
    - ``extra_exceso_total``: max(0, worked_total - scheduled_work)
    - ``extra_fuera_turno``: max(0, worked_total - worked_in_shift)
    - ``anomalies``: list of strings describing anomalies
    """
    rules = rules or RobustRules()
    tz_name = tz or rules.tz
    zone: Optional[ZoneInfo] = None
    try:
        if ZoneInfo is not None:
            zone = ZoneInfo(tz_name)
    except Exception:
        zone = None
    # Parse events into datetimes and reconstruct a monotonic timeline.
    # When only HH:MM is provided, we anchor to ``work_date`` and increment
    # days whenever times go backwards to support shifts that cross midnight.
    parsed_events: List[Tuple[datetime, str]] = []
    prev_dt: Optional[datetime] = None
    day_offset = 0
    for ts_str, typ in event_times:
        ts_s = str(ts_str or "").strip()
        if not ts_s:
            continue
        dt0: Optional[datetime] = None
        # parse full ISO or date/time string
        try:
            if len(ts_s) >= 16 and ("T" in ts_s or ts_s[10] in (" ", "T")):
                # try ISO, allow space separator
                dt0 = datetime.fromisoformat(ts_s.replace(" ", "T"))
            else:
                dt0 = None
        except Exception:
            dt0 = None
        if dt0 is None:
            # fallback: HH:MM
            parts = ts_s.split(":")
            if len(parts) >= 2:
                try:
                    hh = int(parts[0])
                    mm = int(parts[1])
                    dt0 = datetime.combine(work_date, time(hh, mm))
                except Exception:
                    dt0 = None
        if dt0 is None:
            continue
        # localize if needed
        if zone is not None and dt0.tzinfo is None:
            dt0 = dt0.replace(tzinfo=zone)
        # adjust day offset to ensure monotonic sequence
        dt = dt0 + timedelta(days=day_offset)
        if prev_dt is not None and dt <= prev_dt:
            day_offset += 1
            dt = dt0 + timedelta(days=day_offset)
        parsed_events.append((dt, typ))
        prev_dt = dt
    # Build shift window
    shift_start_dt, shift_end_dt = _make_shift_window(work_date, shift_start, shift_end, zone)
    scheduled_seconds = (shift_end_dt - shift_start_dt).total_seconds() - break_minutes * 60
    if scheduled_seconds < 0:
        scheduled_seconds = 0.0
    # Pair intervals
    intervals, anomalies = _pair_intervals(parsed_events, rules, shift_start_dt, shift_end_dt)
    worked_total_seconds = sum((b - a).total_seconds() for a, b in intervals)
    # Compute worked in shift
    worked_in_shift_seconds = 0.0
    for a, b in intervals:
        worked_in_shift_seconds += _overlap_seconds(a, b, shift_start_dt, shift_end_dt)
    # Missing time within shift
    missing_in_shift_seconds = max(0.0, scheduled_seconds - worked_in_shift_seconds)
    # Overtime definitions
    overtime_excess_total_seconds = max(0.0, worked_total_seconds - scheduled_seconds)
    overtime_outside_shift_seconds = max(0.0, worked_total_seconds - worked_in_shift_seconds)
    # Round durations
    worked_total_r = _round_seconds(worked_total_seconds, rules)
    worked_in_shift_r = _round_seconds(worked_in_shift_seconds, rules)
    missing_in_shift_r = _round_seconds(missing_in_shift_seconds, rules)
    overtime_excess_total_r = _round_seconds(overtime_excess_total_seconds, rules)
    overtime_outside_shift_r = _round_seconds(overtime_outside_shift_seconds, rules)
    # If overtime threshold is provided, cap overtime_excess_total at (worked_total - threshold)
    overtime_hhmm = hhmm_from_seconds(overtime_excess_total_r)
    if rules.overtime_threshold_minutes and rules.overtime_threshold_minutes > 0:
        thr = max(0, int(rules.overtime_threshold_minutes) * 60)
        net_after_thr = max(0.0, worked_total_seconds - thr)
        net_after_thr_r = _round_seconds(net_after_thr, rules)
        overtime_hhmm = hhmm_from_seconds(net_after_thr_r)
    return {
        "programado": hhmm_from_seconds(scheduled_seconds),
        "trabajado_total": hhmm_from_seconds(worked_total_r),
        "trabajado_en_turno": hhmm_from_seconds(worked_in_shift_r),
        "no_laborado_en_turno": hhmm_from_seconds(missing_in_shift_r),
        "extra_exceso_total": hhmm_from_seconds(overtime_excess_total_r),
        "extra_fuera_turno": hhmm_from_seconds(overtime_outside_shift_r),
        "anomalies": anomalies,
    }


if __name__ == "__main__":  # pragma: no cover
    # Simple manual test when run directly.  This will print out
    # representative calculations for a few synthetic scenarios.  Running
    # ``python utils/robust_attendance.py`` should display human‑readable
    # summaries which can be used to verify correctness during development.
    examples = [
        {
            "events": [
                ("08:05", "IN"), ("13:00", "OUT"), ("13:30", "IN"), ("17:50", "OUT"),
            ],
            "work_date": date(2026, 2, 26),
            "shift": (time(8, 0), time(17, 0)),
            "break": 30,
            "label": "Normal day with lunch break"
        },
        {
            "events": [
                ("07:50", "IN"), ("12:00", "OUT"), ("12:45", "IN"), ("16:10", "OUT"), ("16:30", "IN"), ("20:15", "OUT"),
            ],
            "work_date": date(2026, 2, 26),
            "shift": (time(8, 0), time(17, 0)),
            "break": 45,
            "label": "Extended day with two breaks and overtime"
        },
        {
            "events": [
                ("22:00", "IN"), ("02:00", "OUT"), ("03:00", "IN"), ("07:30", "OUT"),
            ],
            "work_date": date(2026, 2, 26),
            "shift": (time(22, 0), time(6, 0)),
            "break": 0,
            "label": "Night shift crossing midnight"
        },
    ]
    for ex in examples:
        rules = RobustRules()
        res = compute_summary(
            ex["events"], ex["work_date"], ex["shift"][0], ex["shift"][1], break_minutes=ex["break"], rules=rules
        )
        print("Example:", ex["label"])
        for k, v in res.items():
            print(f"  {k}: {v}")
        print()