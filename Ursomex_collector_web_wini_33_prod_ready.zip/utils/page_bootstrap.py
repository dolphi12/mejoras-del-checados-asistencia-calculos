from __future__ import annotations

import os

import streamlit as st

from components.layout import inject_global_css
from components.ui import theme_css


def bootstrap_page(page_title: str, page_icon: str = "", *, layout: str = "wide") -> None:
    """Apply page config + global styles.

    Streamlit multipage executes each file independently; we inject CSS on every page
    to keep the UI consistent.
    """

    st.set_page_config(
        page_title=page_title,
        page_icon=page_icon or os.path.join("static", "favicon.png"),
        layout=layout,
        initial_sidebar_state="expanded",
        menu_items={"Get help": None, "Report a bug": None, "About": None},
    )

    theme = st.session_state.get("theme", "ursomex")
    accent = st.session_state.get("accent_color", "#2BBBAD")
    st.markdown(theme_css(str(theme), accent_hex=str(accent)), unsafe_allow_html=True)
    inject_global_css()
