"""
attendance_upload_excel.py
---------------------------

This module provides a simple parser and calculator to build an attendance
table from an Excel export of the collector.  It emulates the behaviour of
the separate web prototype provided by the user (a React/Vite app) and is
intended to be used as an optional, simplified calculation path within
Streamlit.  The goal is to enable uploading an Excel file, editing times
manually and recalculating the derived metrics (descuento no laborado,
tiempo trabajado, horas extra) without relying on the legacy event-based
engine in ``attendance_calc.py``.

Key assumptions and behaviours:

* The input Excel sheet is named ``JORNADAS_CIERRE`` and contains columns
  ``employee_id``, ``employee_name``, ``fecha_registro`` or ``start_local``,
  plus event columns ``E01`` .. ``E12``.  Any missing columns are treated
  as empty strings.  The first row is the header.
* Each row represents one day of work for an employee.  The ``E`` columns
  contain timestamps in ``HH:MM`` or full ISO formats.  Only the time
  component is extracted.
* Events are counted and assigned to named slots following these rules:

    - If there are exactly 2 events → ``entrada`` and ``salida``.
    - If there are exactly 4 events → ``entrada``, ``salidaComer``,
      ``regresoComer``, ``salida``.
    - If there are exactly 6 events → ``entrada``, ``salidaComer``,
      ``regresoComer``, ``salidaCenar``, ``regresoCenar``, ``salida``.
    - Otherwise, the first six events are assigned in order and any
      additional events are treated as permission intervals.  Every pair
      of consecutive events beyond the 6th (e.g. 7–8, 9–10) is summed as
      minutes and added to the ``permiso`` field.  Unpaired trailing events
      are ignored.

* ``descuentoNoLaborado`` is the sum of the lunch discount, dinner discount
  and any manual permission minutes.  The lunch discount is 30 minutes
  when the lunch break lasts exactly 60 minutes; otherwise the full
  duration of the break is deducted.  The dinner discount always equals
  the duration of the dinner break.
* ``tiempoTrabajado`` is ``(salida - entrada) - descuentoNoLaborado`` when
  both ``entrada`` and ``salida`` exist.  If either is missing, it is set
  to ``None``.
* ``horasExtra`` is the positive amount of ``tiempoTrabajado`` minus the
  jornada base (default 480 minutes).  Negative values are clamped to 0.
* Alerts are generated whenever the number of events is unusual (not
  0/2/4/6), when required fields are missing or out of order, or when
  incidence codes indicate anomalies (``FALTA_SALIDA``, ``JORNADA_ABIERTA``,
  ``EVENTO_SUELTO`` or ``PAUSA_LARGA``).  These alerts are returned as a
  list of strings.

This module can be imported by Streamlit pages to implement an upload-and-
calculate workflow.  It avoids any dependencies on Streamlit to remain
usable outside of a web context.  Pandas is used for convenience when
reading Excel files; if ``openpyxl`` is not available, a useful error
message is raised.
"""

from __future__ import annotations

from typing import List, Dict, Any, Optional, Tuple

import pandas as pd


def _time_to_minutes(time_str: str) -> Optional[int]:
    """Convert ``HH:MM`` strings to minutes since midnight.

    Returns ``None`` for empty or malformed inputs.  Accepts strings of
    length 4–8 with a single colon.  Any non-numeric parts are silently
    ignored.
    """
    if not time_str or ":" not in time_str:
        return None
    parts = time_str.split(":")
    if len(parts) != 2:
        return None
    try:
        h = int(parts[0])
        m = int(parts[1])
    except Exception:
        return None
    if h < 0 or h > 23 or m < 0 or m > 59:
        return None
    return h * 60 + m


def _minutes_to_time(minutes: Optional[int]) -> str:
    """Render minutes back to a ``HH:MM`` string.

    Values ``None`` or negative produce an empty string.  Minutes are
    clamped to non-negative integers.  Hours can exceed 23 for overtime.
    """
    if minutes is None or minutes < 0:
        return ""
    minutes = int(round(minutes))
    h = minutes // 60
    m = minutes % 60
    return f"{h:02d}:{m:02d}"


def _clean_time(value: Any) -> str:
    """Normalize Excel cells to ``HH:MM`` or empty string.

    Excel may return time-formatted cells as ``datetime.time`` or
    ``pandas.Timestamp`` objects.  Strings may include ISO date/time
    parts.  Only the ``HH:MM`` portion is retained.  If parsing fails,
    returns the trimmed string as-is.
    """
    # Handle NaN/NaT coming from pandas even when dtype=str
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass

    if value is None or value == "":
        return ""
    # Pandas may return Timestamp for Excel times
    if isinstance(value, (pd.Timestamp,)):
        # Use UTC attributes to avoid timezone confusion
        return f"{value.hour:02d}:{value.minute:02d}"
    s = str(value).strip()
    if s.lower() in {"nan", "nat", "none"}:
        return ""
    # If string contains a 'T' or space, split off the date part
    if "T" in s:
        s = s.split("T", 1)[1]
    if " " in s:
        s = s.split(" ", 1)[1]
    # Keep only HH:MM
    if len(s) >= 5 and s[2] == ":":
        return s[:5]
    return s


def _clean_str(value: Any) -> str:
    """Normalize non-time string cells, collapsing NaN/None to '' and stripping."""
    try:
        if pd.isna(value):
            return ""
    except Exception:
        pass
    if value is None:
        return ""
    s = str(value).strip()
    return "" if s.lower() in {"nan", "nat", "none"} else s


def _duration_minutes(start_min: Optional[int], end_min: Optional[int]) -> int:
    """Return duration in minutes between two clock times, supporting next-day wrap.

    If either value is None, returns 0. If end <= start, assumes end is on the
    following day (adds 1440).
    """
    if start_min is None or end_min is None:
        return 0
    if end_min <= start_min:
        end_min = end_min + 1440
    return max(0, int(end_min - start_min))


def _assign_events(events: List[str]) -> Tuple[Dict[str, str], int]:
    """Assign a list of event strings into named fields.

    Returns a tuple ``(fields, permiso)`` where ``fields`` contains keys
    ``entrada``, ``salidaComer``, ``regresoComer``, ``salidaCenar``,
    ``regresoCenar`` and ``salida``, and ``permiso`` is the total
    permission minutes derived from any extra events beyond the first six.
    """
    slots = ["entrada", "salidaComer", "regresoComer", "salidaCenar", "regresoCenar", "salida"]
    fields: Dict[str, str] = {k: "" for k in slots}
    count = len(events)

    # Match the prototype behaviour:
    # 2 events -> entrada / salida
    # 4 events -> entrada / comida(out,in) / salida
    # 6 events -> entrada / comida(out,in) / cena(out,in) / salida
    if count == 2:
        fields["entrada"] = events[0]
        fields["salida"] = events[1]
    elif count == 4:
        fields["entrada"] = events[0]
        fields["salidaComer"] = events[1]
        fields["regresoComer"] = events[2]
        fields["salida"] = events[3]
    elif count == 6:
        fields["entrada"] = events[0]
        fields["salidaComer"] = events[1]
        fields["regresoComer"] = events[2]
        fields["salidaCenar"] = events[3]
        fields["regresoCenar"] = events[4]
        fields["salida"] = events[5]
    else:
        # Odd or > 6: assign up to 6, rest -> permiso
        for i in range(min(count, len(slots))):
            fields[slots[i]] = events[i]
    # Permission minutes from additional pairs (beyond the 6th)
    permiso = 0
    if count > len(slots):
        # start at index 6 (0-based) → event #7
        extra = events[len(slots):]
        for j in range(0, len(extra), 2):
            start = _time_to_minutes(extra[j])
            end = _time_to_minutes(extra[j + 1]) if (j + 1) < len(extra) else None
            if start is not None and end is not None:
                permiso += _duration_minutes(start, end)
    return fields, permiso


def _detect_alerts(record: Dict[str, Any]) -> List[str]:
    """Generate a list of alerts for a record based on missing or invalid fields."""
    alerts: List[str] = []
    count = record.get("eventCount", 0)
    if count not in (0, 2, 4, 6):
        alerts.append(f"Número de eventos inusual: {count}")
    entrada = record.get("entrada") or ""
    salida = record.get("salida") or ""
    if not entrada:
        alerts.append("Falta ENTRADA")
    if not salida:
        alerts.append("Falta SALIDA")
    em = _time_to_minutes(entrada)
    sm = _time_to_minutes(salida)
    # Mixed/24-7: allow cross-midnight by treating salida<=entrada as next-day.
    if em is not None and sm is not None:
        dur = _duration_minutes(em, sm)
        if dur == 0:
            alerts.append("SALIDA antes o igual que ENTRADA")
    # Lunch pairing
    sc = record.get("salidaComer") or ""
    rc = record.get("regresoComer") or ""
    if sc and not rc:
        alerts.append("Falta REGRESO DE COMER")
    if rc and not sc:
        alerts.append("Falta SALIDA A COMER")
    if sc and rc:
        sc_m = _time_to_minutes(sc)
        rc_m = _time_to_minutes(rc)
        if sc_m is not None and rc_m is not None and _duration_minutes(sc_m, rc_m) == 0:
            alerts.append("REGRESO DE COMER antes o igual que SALIDA A COMER")
    # Dinner pairing
    sd = record.get("salidaCenar") or ""
    rd = record.get("regresoCenar") or ""
    if sd and not rd:
        alerts.append("Falta REGRESO DE CENAR")
    if rd and not sd:
        alerts.append("Falta SALIDA A CENAR")
    if sd and rd:
        sd_m = _time_to_minutes(sd)
        rd_m = _time_to_minutes(rd)
        if sd_m is not None and rd_m is not None and _duration_minutes(sd_m, rd_m) == 0:
            alerts.append("REGRESO DE CENAR antes o igual que SALIDA A CENAR")
    # Incidence codes
    has_code_alert = record.get("hasCodeAlert", False)
    if has_code_alert:
        for code in (record.get("incidenciaCodes") or []):
            if code in {"FALTA_SALIDA", "JORNADA_ABIERTA", "EVENTO_SUELTO", "PAUSA_LARGA"}:
                alerts.append(f"Código de incidencia: {code}")
    return alerts


def _calculate_row(
    record: Dict[str, Any],
    jornada_base: int,
    lunch_expected_minutes: int = 60,
    lunch_discount_minutes: int = 30,
    lunch_tolerance_minus: int = 0,
    lunch_tolerance_plus: int = 0,
    max_shift_minutes: int = 24 * 60,
) -> Dict[str, Any]:
    """Compute discounts, time worked and overtime for a single row."""
    entrada = record.get("entrada") or ""
    salida = record.get("salida") or ""
    salida_comer = record.get("salidaComer") or ""
    regreso_comer = record.get("regresoComer") or ""
    salida_cenar = record.get("salidaCenar") or ""
    regreso_cenar = record.get("regresoCenar") or ""
    permiso = int(record.get("permiso") or 0)

    entrada_min = _time_to_minutes(entrada)
    salida_min = _time_to_minutes(salida)
    lunch_out_min = _time_to_minutes(salida_comer)
    lunch_in_min = _time_to_minutes(regreso_comer)
    dinner_out_min = _time_to_minutes(salida_cenar)
    dinner_in_min = _time_to_minutes(regreso_cenar)

    # Lunch duration (supports cross-midnight)
    dur_comida = _duration_minutes(lunch_out_min, lunch_in_min) if (lunch_out_min is not None and lunch_in_min is not None) else 0
    comida_discount = 0
    if dur_comida > 0:
        lo = max(0, int(lunch_expected_minutes) - max(0, int(lunch_tolerance_minus)))
        hi = max(0, int(lunch_expected_minutes) + max(0, int(lunch_tolerance_plus)))
        if lo <= dur_comida <= hi:
            comida_discount = max(0, int(lunch_discount_minutes))
        else:
            comida_discount = dur_comida

    # Dinner discount: full duration (supports cross-midnight)
    cena_discount = 0
    if dinner_out_min is not None and dinner_in_min is not None:
        cena_discount = _duration_minutes(dinner_out_min, dinner_in_min)

    descuento_no_laborado = (comida_discount + cena_discount + permiso)

    tiempo_trabajado = None
    shift_dur = 0
    if entrada_min is not None and salida_min is not None:
        shift_dur = _duration_minutes(entrada_min, salida_min)
        if shift_dur > 0:
            tiempo_trabajado = shift_dur - descuento_no_laborado

    horas_extra = 0
    if tiempo_trabajado is not None:
        horas_extra = max(0, tiempo_trabajado - jornada_base)

    alerts = _detect_alerts(record)
    if entrada_min is not None and salida_min is not None and shift_dur > int(max_shift_minutes):
        alerts.append(f"Duración de jornada inusual: {shift_dur} min")

    return {
        **record,
        "comidaDiscount": comida_discount,
        "cenaDiscount": cena_discount,
        "descuentoNoLaborado": descuento_no_laborado,
        "tiempoTrabajado": tiempo_trabajado if tiempo_trabajado is not None else None,
        "horasExtra": horas_extra,
        "alerts": alerts,
        "hasAlert": bool(alerts),
    }


def recalc_upload_table(
    df: pd.DataFrame,
    jornada_base: int = 480,
    lunch_expected_minutes: int = 60,
    lunch_discount_minutes: int = 30,
    lunch_tolerance_minus: int = 0,
    lunch_tolerance_plus: int = 0,
    max_shift_minutes: int = 24 * 60,
) -> pd.DataFrame:
    """Recalculate metrics from an already-expanded table (post-edit).

    Expects columns: ID, FECHA, NOMBRE, ENTRADA, SALIDA A COMER, REGRESO DE COMER,
    SALIDA A CENAR, REGRESO DE CENAR, SALIDA, PERMISO (min).
    """
    if df is None or not isinstance(df, pd.DataFrame) or df.empty:
        return df

    d2 = df.copy()
    if "PERMISO (min)" in d2.columns:
        d2["PERMISO (min)"] = pd.to_numeric(d2["PERMISO (min)"], errors="coerce").fillna(0).astype(int)
    else:
        d2["PERMISO (min)"] = 0

    out_rows = []
    for _, r in d2.iterrows():
        record = {
            "id": str(r.get("ID") or "").strip(),
            "fecha": str(r.get("FECHA") or "").strip(),
            "nombre": str(r.get("NOMBRE") or "").strip(),
            "entrada": str(r.get("ENTRADA") or "").strip(),
            "salidaComer": str(r.get("SALIDA A COMER") or "").strip(),
            "regresoComer": str(r.get("REGRESO DE COMER") or "").strip(),
            "salidaCenar": str(r.get("SALIDA A CENAR") or "").strip(),
            "regresoCenar": str(r.get("REGRESO DE CENAR") or "").strip(),
            "salida": str(r.get("SALIDA") or "").strip(),
            "permiso": int(r.get("PERMISO (min)") or 0),
            "eventCount": 0,
            "incidenciaCodes": [],
            "hasCodeAlert": False,
        }
        record["eventCount"] = sum(1 for x in [record["entrada"], record["salidaComer"], record["regresoComer"], record["salidaCenar"], record["regresoCenar"], record["salida"]] if x)

        calc = _calculate_row(
            record,
            jornada_base=jornada_base,
            lunch_expected_minutes=lunch_expected_minutes,
            lunch_discount_minutes=lunch_discount_minutes,
            lunch_tolerance_minus=lunch_tolerance_minus,
            lunch_tolerance_plus=lunch_tolerance_plus,
            max_shift_minutes=max_shift_minutes,
        )

        out_rows.append(
            {
                "ID": calc.get("id"),
                "FECHA": calc.get("fecha"),
                "NOMBRE": calc.get("nombre"),
                "ENTRADA": calc.get("entrada"),
                "SALIDA A COMER": calc.get("salidaComer"),
                "REGRESO DE COMER": calc.get("regresoComer"),
                "SALIDA A CENAR": calc.get("salidaCenar"),
                "REGRESO DE CENAR": calc.get("regresoCenar"),
                "SALIDA": calc.get("salida"),
                "PERMISO (min)": calc.get("permiso"),
                "DESCUENTO NO LABORADO (min)": calc.get("descuentoNoLaborado"),
                "TIEMPO TRABAJADO (min)": calc.get("tiempoTrabajado"),
                "HORAS EXTRA (min)": calc.get("horasExtra"),
                "ALERTAS": "; ".join(calc.get("alerts") or []),
            }
        )

    out_df = pd.DataFrame(out_rows)
    if not out_df.empty and "FECHA" in out_df.columns and "ID" in out_df.columns:
        out_df = out_df.sort_values(["FECHA", "ID"], kind="stable")
    return out_df


def parse_upload_excel(
    xlsx_path: str,
    sheet_name: str = "JORNADAS_CIERRE",
    jornada_base: int = 480,
    lunch_expected_minutes: int = 60,
    lunch_discount_minutes: int = 30,
    lunch_tolerance_minus: int = 0,
    lunch_tolerance_plus: int = 0,
    max_shift_minutes: int = 24 * 60,
) -> pd.DataFrame:
    """Read and process an Excel export into a DataFrame with derived metrics.

    Parameters
    ----------
    xlsx_path : str
        Path to the Excel file.  Only the specified sheet is read.  An
        exception is raised if the sheet does not exist.
    sheet_name : str
        Name of the sheet containing the attendance data.
    jornada_base : int
        Base work day in minutes.  Defaults to 480 (8 hours).

    Returns
    -------
    pandas.DataFrame
        A DataFrame with columns:
        ID, FECHA, NOMBRE, ENTRADA, SALIDA A COMER, REGRESO DE COMER,
        SALIDA A CENAR, REGRESO DE CENAR, SALIDA, PERMISO (min),
        DESCUENTO NO LABORADO (min), TIEMPO TRABAJADO (min), HORAS EXTRA (min),
        ALERTAS
    """
    try:
        df = pd.read_excel(xlsx_path, sheet_name=sheet_name, dtype=str)
    except ValueError as exc:
        # Pandas raises ValueError if sheet is missing
        raise RuntimeError(f"No se pudo leer la hoja '{sheet_name}' del archivo: {exc}")

    # Normalize columns: strip names
    cols = {c: str(c).strip() for c in df.columns}
    df = df.rename(columns=cols)

    # Ensure required columns exist
    for col in ["employee_id", "employee_name", "fecha_registro", "start_local", "incidencia_codes"]:
        if col not in df.columns:
            df[col] = ""

    # Identify event columns strictly (E01 .. E12)
    ecols = [c for c in df.columns if re.match(r"^E\d{2}$", str(c).strip(), flags=re.IGNORECASE)]
    ecols = sorted(ecols, key=lambda x: str(x).upper())

    records: List[Dict[str, Any]] = []
    for _, row in df.iterrows():
        # Extract events
        ev: List[str] = []
        for c in ecols:
            val = _clean_time(row.get(c))
            if val:
                ev.append(val)
        fields, permiso_minutes = _assign_events(ev)

        # Incidence codes may be a string separated by commas/semicolons
        codes_raw = _clean_str(row.get("incidencia_codes"))
        codes = [c.strip() for c in re.split(r"[,;]", codes_raw) if c.strip()] if codes_raw else []
        has_code_alert = any(code in {"FALTA_SALIDA", "JORNADA_ABIERTA", "EVENTO_SUELTO", "PAUSA_LARGA"} for code in codes)

        record = {
            "id": _clean_str(row.get("employee_id")),
            "fecha": (_clean_str(row.get("fecha_registro")) or _clean_str(row.get("start_local"))).split(" ")[0],
            "nombre": _clean_str(row.get("employee_name")),
            "entrada": fields.get("entrada") or "",
            "salidaComer": fields.get("salidaComer") or "",
            "regresoComer": fields.get("regresoComer") or "",
            "salidaCenar": fields.get("salidaCenar") or "",
            "regresoCenar": fields.get("regresoCenar") or "",
            "salida": fields.get("salida") or "",
            "permiso": permiso_minutes,
            "eventCount": len(ev),
            "incidenciaCodes": codes,
            "hasCodeAlert": has_code_alert,
        }
        calc = _calculate_row(
            record,
            jornada_base=jornada_base,
            lunch_expected_minutes=lunch_expected_minutes,
            lunch_discount_minutes=lunch_discount_minutes,
            lunch_tolerance_minus=lunch_tolerance_minus,
            lunch_tolerance_plus=lunch_tolerance_plus,
            max_shift_minutes=max_shift_minutes,
        )
        records.append(calc)

    # Build DataFrame
    out_rows = []
    for r in records:
        out_rows.append(
            {
                "ID": r.get("id"),
                "FECHA": r.get("fecha"),
                "NOMBRE": r.get("nombre"),
                "ENTRADA": r.get("entrada"),
                "SALIDA A COMER": r.get("salidaComer"),
                "REGRESO DE COMER": r.get("regresoComer"),
                "SALIDA A CENAR": r.get("salidaCenar"),
                "REGRESO DE CENAR": r.get("regresoCenar"),
                "SALIDA": r.get("salida"),
                "PERMISO (min)": r.get("permiso"),
                "DESCUENTO NO LABORADO (min)": r.get("descuentoNoLaborado"),
                "TIEMPO TRABAJADO (min)": r.get("tiempoTrabajado") if r.get("tiempoTrabajado") is not None else None,
                "HORAS EXTRA (min)": r.get("horasExtra"),
                "ALERTAS": "; ".join(r.get("alerts") or []),
            }
        )

    out_df = pd.DataFrame(out_rows)
    if not out_df.empty:
        # Stable sort by date and ID if present
        out_df = out_df.sort_values(["FECHA", "ID"], kind="stable")
    return out_df

import re  # Placed at end to avoid circular import issues during type checking
