from __future__ import annotations

import json
import os
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from openpyxl import load_workbook


DEFAULT_EMPLOYEE_KEYS: Tuple[str, ...] = (
    "employee_id",
    "employeeNoString",
    "employeeNo",
    "employeeID",
    "employeeId",
)

DEFAULT_NESTED_KEYS: Tuple[str, ...] = (
    "AccessControllerEvent",
    "event",
    "data",
)


def normalize_ids(ids: Optional[Sequence[Any]]) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in ids or []:
        s = str(x).strip()
        if not s:
            continue
        if s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out


def make_order_map(order_employee_ids: Optional[Sequence[Any]]) -> Dict[str, int]:
    order = normalize_ids(order_employee_ids)
    return {emp: i for i, emp in enumerate(order)}


def extract_employee_id_from_payload(payload_json: Any) -> str:
    try:
        obj = json.loads(payload_json) if isinstance(payload_json, str) else payload_json
    except Exception:
        return ""
    if not isinstance(obj, dict):
        return ""

    for k in DEFAULT_EMPLOYEE_KEYS:
        if k in obj and obj.get(k) is not None:
            return str(obj.get(k)).strip()

    for nk in DEFAULT_NESTED_KEYS:
        v = obj.get(nk)
        if isinstance(v, dict):
            for k in DEFAULT_EMPLOYEE_KEYS:
                if k in v and v.get(k) is not None:
                    return str(v.get(k)).strip()

    return ""


def _num_or_lex(x: str) -> Tuple[int, Any]:
    try:
        return (0, int(x))
    except Exception:
        return (1, x)


def filter_sort_records(
    records: List[Dict[str, Any]],
    allowed_employee_ids: Optional[Sequence[Any]] = None,
    order_employee_ids: Optional[Sequence[Any]] = None,
    employee_getter: Optional[Callable[[Dict[str, Any]], str]] = None,
    time_getter: Optional[Callable[[Dict[str, Any]], str]] = None,
) -> List[Dict[str, Any]]:
    allow = set(normalize_ids(allowed_employee_ids))
    order_map = make_order_map(order_employee_ids)

    if employee_getter is None:
        employee_getter = lambda r: str(r.get("employee_id") or "").strip()
    if time_getter is None:
        time_getter = lambda r: str(r.get("event_time_utc") or "")

    out = records
    if allow:
        out = [r for r in out if employee_getter(r) in allow]

    if order_map:

        def _key(r: Dict[str, Any]):
            emp = employee_getter(r)
            pos = order_map.get(emp, 10_000_000)
            empk = _num_or_lex(emp)
            return (pos, empk[0], empk[1], time_getter(r))

        out.sort(key=_key)

    return out


def postprocess_xlsx(
    src_path: str,
    dst_path: str,
    allowed_employee_ids: Optional[Sequence[Any]] = None,
    order_employee_ids: Optional[Sequence[Any]] = None,
    sheet_names: Optional[Sequence[str]] = None,
    header_candidates: Optional[Sequence[str]] = None,
    start_time_candidates: Optional[Sequence[str]] = None,
) -> str:
    allow = set(normalize_ids(allowed_employee_ids))
    if not allow:
        return src_path

    order_ids = normalize_ids(order_employee_ids)
    pos = {emp: i for i, emp in enumerate(order_ids)}

    if header_candidates is None:
        header_candidates = ("employee_id",)
    if start_time_candidates is None:
        start_time_candidates = ("__start_time_utc", "start_local", "event_time_utc")

    wb = load_workbook(src_path)

    targets = list(sheet_names) if sheet_names else list(wb.sheetnames)

    for sname in targets:
        if sname not in wb.sheetnames:
            continue
        ws = wb[sname]
        if ws.max_row < 2:
            continue

        headers = [c.value for c in ws[1]]
        emp_idx = None
        for cand in header_candidates:
            if cand in headers:
                emp_idx = headers.index(cand) + 1
                break
        if emp_idx is None:
            continue

        start_idx = None
        for cand in start_time_candidates:
            if cand in headers:
                start_idx = headers.index(cand) + 1
                break

        rows: List[List[Any]] = []
        for r in range(2, ws.max_row + 1):
            emp = ws.cell(row=r, column=emp_idx).value
            emp_s = str(emp).strip() if emp is not None else ""
            if emp_s not in allow:
                continue
            row_vals = [ws.cell(row=r, column=c).value for c in range(1, ws.max_column + 1)]
            rows.append(row_vals)

        def _sort_key(row: List[Any]):
            emp_val = row[emp_idx - 1]
            emp_s = str(emp_val).strip() if emp_val is not None else ""
            p = pos.get(emp_s, 10_000_000)
            empk = _num_or_lex(emp_s)
            start_val = ""
            if start_idx is not None and start_idx - 1 < len(row):
                start_val = str(row[start_idx - 1] or "")
            return (p, empk[0], empk[1], start_val)

        rows.sort(key=_sort_key)

        ws.delete_rows(2, ws.max_row)
        for row in rows:
            ws.append(row)

    if "__META" in wb.sheetnames:
        ws = wb["__META"]
        try:
            for r in range(1, ws.max_row + 1):
                k = ws.cell(row=r, column=1).value
                if str(k).strip() == "file_name":
                    ws.cell(row=r, column=2).value = os.path.basename(dst_path)
        except Exception:
            pass

    wb.save(dst_path)
    return dst_path


def postprocess_csv(
    src_path: str,
    dst_path: str,
    allowed_employee_ids: Optional[Sequence[Any]] = None,
    order_employee_ids: Optional[Sequence[Any]] = None,
    employee_field: str = "employee_id",
    payload_field: Optional[str] = None,
) -> str:
    import csv

    allow = set(normalize_ids(allowed_employee_ids))
    if not allow:
        return src_path

    order_map = make_order_map(order_employee_ids)

    with open(src_path, "r", encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        fieldnames = r.fieldnames or []
        rows = list(r)

    def _emp(row: Dict[str, Any]) -> str:
        if payload_field:
            return extract_employee_id_from_payload(row.get(payload_field))
        return str(row.get(employee_field) or "").strip()

    rows = [row for row in rows if _emp(row) in allow]

    if order_map:

        def _key(row: Dict[str, Any]):
            emp = _emp(row)
            pos = order_map.get(emp, 10_000_000)
            empk = _num_or_lex(emp)
            t = row.get("event_time_utc") or row.get("event_time") or ""
            return (pos, empk[0], empk[1], str(t))

        rows.sort(key=_key)

    with open(dst_path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow(row)

    return dst_path


def postprocess_export(
    src_path: str,
    allowed_employee_ids: Optional[Sequence[Any]] = None,
    order_employee_ids: Optional[Sequence[Any]] = None,
    dst_path: Optional[str] = None,
    xlsx_sheet_names: Optional[Sequence[str]] = None,
    xlsx_header_candidates: Optional[Sequence[str]] = None,
    csv_employee_field: str = "employee_id",
    csv_payload_field: Optional[str] = None,
) -> str:
    allow = normalize_ids(allowed_employee_ids)
    if not allow:
        return src_path

    if dst_path is None:
        out_dir = os.path.dirname(src_path)
        base_name, ext = os.path.splitext(os.path.basename(src_path))
        dst_path = os.path.join(out_dir, f"{base_name}_FILTRADO{ext}")

    _, ext = os.path.splitext(src_path)
    ext = ext.lower()
    if ext in (".xlsx", ".xlsm"):
        return postprocess_xlsx(
            src_path,
            dst_path,
            allowed_employee_ids=allow,
            order_employee_ids=order_employee_ids,
            sheet_names=xlsx_sheet_names,
            header_candidates=xlsx_header_candidates,
        )

    if ext == ".csv":
        return postprocess_csv(
            src_path,
            dst_path,
            allowed_employee_ids=allow,
            order_employee_ids=order_employee_ids,
            employee_field=csv_employee_field,
            payload_field=csv_payload_field,
        )

    return src_path
