from __future__ import annotations

import json
import os
import secrets
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional


def _now_utc_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def ensure_session_id(session_state: dict) -> str:
    sid = session_state.get("session_id")
    if isinstance(sid, str) and sid:
        return sid
    sid = secrets.token_hex(8)
    session_state["session_id"] = sid
    return sid


def _audit_dir(data_dir: str) -> str:
    p = os.path.join(data_dir, "audit")
    os.makedirs(p, exist_ok=True)
    return p


def audit_path(data_dir: str, name: str = "attendance_audit.jsonl") -> str:
    return os.path.join(_audit_dir(data_dir), name)


def append_event(data_dir: str, event: Dict[str, Any], name: str = "attendance_audit.jsonl") -> None:
    path = audit_path(data_dir, name=name)
    event = dict(event)
    event.setdefault("ts_utc", _now_utc_iso())
    # Always keep JSONL append-only for traceability
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _norm(v: Any) -> str:
    if v is None:
        return ""
    s = str(v).strip()
    # normalize common NaN representations
    if s.lower() in {"nan", "none", "nat"}:
        return ""
    return s


def compute_row_changes(
    before_df,
    after_df,
    key_cols: List[str],
    watch_cols: List[str],
) -> List[Dict[str, Any]]:
    """
    Returns changes grouped by row key. Expects both dfs to have the same rows (order may differ).
    """
    if before_df is None or after_df is None:
        return []
    if before_df.empty or after_df.empty:
        return []

    b = before_df.copy()
    a = after_df.copy()

    for c in key_cols + watch_cols:
        if c not in b.columns:
            b[c] = ""
        if c not in a.columns:
            a[c] = ""

    b["_KEY"] = b[key_cols].astype(str).agg("||".join, axis=1)
    a["_KEY"] = a[key_cols].astype(str).agg("||".join, axis=1)

    b = b.set_index("_KEY", drop=True)
    a = a.set_index("_KEY", drop=True)

    common = [k for k in b.index if k in a.index]
    changes: List[Dict[str, Any]] = []
    for k in common:
        row_changes = []
        for c in watch_cols:
            bv = _norm(b.loc[k, c])
            av = _norm(a.loc[k, c])
            if bv != av:
                row_changes.append({"field": c, "before": bv, "after": av})
        if row_changes:
            key_parts = k.split("||")
            key_obj = {key_cols[i]: key_parts[i] if i < len(key_parts) else "" for i in range(len(key_cols))}
            changes.append({"key": key_obj, "changes": row_changes})
    return changes


def tail_events(data_dir: str, limit: int = 500, name: str = "attendance_audit.jsonl") -> List[Dict[str, Any]]:
    path = audit_path(data_dir, name=name)
    if not os.path.isfile(path):
        return []
    rows: List[Dict[str, Any]] = []
    # read from end without fancy seeks: file sizes expected manageable; limit default 500
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return []
    return rows[-limit:]
