from __future__ import annotations

import os
from datetime import datetime
from typing import Iterable, List, Optional

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter


DEFAULT_COLUMNS: List[str] = [
    "ID",
    "FECHA",
    "NOMBRE",
    "ENTRADA",
    "SALIDA A COMER",
    "REGRESO DE COMER",
    "SALIDA A CENAR",
    "REGRESO DE CENAR",
    "SALIDA",
    "PERMISO",
    "DESCUENTO NO LABORADO",
    "TIEMPO TRABAJADO",
    "HORAS EXTRA",
]


def export_attendance_excel(
    df: pd.DataFrame,
    out_dir: str,
    base_name: str,
    columns: Optional[List[str]] = None,
) -> str:
    columns = columns or DEFAULT_COLUMNS
    os.makedirs(out_dir, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"{base_name}_{ts}.xlsx"
    path = os.path.join(out_dir, fname)

    wb = Workbook()
    ws = wb.active
    ws.title = "ASISTENCIA"

    # Header
    header_font = Font(bold=True)
    for j, col in enumerate(columns, start=1):
        cell = ws.cell(row=1, column=j, value=col)
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    # Rows
    for i, (_, r) in enumerate(df.iterrows(), start=2):
        for j, col in enumerate(columns, start=1):
            ws.cell(row=i, column=j, value=(None if pd.isna(r.get(col)) else r.get(col)))

    # Basic column width auto-fit (bounded)
    for j, col in enumerate(columns, start=1):
        maxlen = len(str(col))
        for i in range(2, min(ws.max_row + 1, 4000)):
            v = ws.cell(row=i, column=j).value
            if v is None:
                continue
            maxlen = max(maxlen, len(str(v)))
        ws.column_dimensions[get_column_letter(j)].width = min(max(maxlen + 2, 10), 40)

    wb.save(path)
    return path