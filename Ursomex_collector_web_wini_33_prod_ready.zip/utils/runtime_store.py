from __future__ import annotations

from typing import Optional

import streamlit as st

from collector.config import load_config
from utils.wrappers import CollectorRuntime


def get_cfg_path() -> str:
    return st.session_state.get("cfg_path", "config.web.json")


def set_cfg_path(p: str) -> None:
    st.session_state["cfg_path"] = p


def get_runtime() -> CollectorRuntime:
    cfg_path = get_cfg_path()
    rt = st.session_state.get("collector_runtime")
    if isinstance(rt, CollectorRuntime) and getattr(rt, "cfg_path", None) == cfg_path:
        return rt

    if isinstance(rt, CollectorRuntime):
        try:
            rt.close()
        except Exception:
            pass

    rt = CollectorRuntime(cfg_path=cfg_path)
    st.session_state["collector_runtime"] = rt
    return rt


def get_data_dir() -> str:
    cfg = load_config(get_cfg_path())
    return cfg.storage["data_dir"]
