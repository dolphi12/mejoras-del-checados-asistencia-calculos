from __future__ import annotations

import json
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional


def _now_ts() -> int:
    return int(time.time())


def _read_json(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {"version": 1, "tokens": {}}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {"version": 1, "tokens": {}}


def _atomic_write_json(path: str, payload: Dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(str(tmp), str(p))


def _cleanup(store: Dict[str, Any]) -> Dict[str, Any]:
    now = _now_ts()
    tokens = store.get("tokens") or {}
    keep: Dict[str, Any] = {}
    for t, rec in tokens.items():
        try:
            exp = int(rec.get("exp_ts") or 0)
        except Exception:
            exp = 0
        if exp and exp > now:
            keep[str(t)] = rec
    store["tokens"] = keep
    return store


def store_path(data_dir: str) -> str:
    return os.path.join(data_dir, "web_sessions.json")


@dataclass
class TokenUser:
    username: str
    role: str


def issue_token(path: str, username: str, role: str, ttl_days: int = 14) -> str:
    store = _cleanup(_read_json(path))
    tok = secrets.token_urlsafe(32)
    now = _now_ts()
    exp = now + int(ttl_days) * 86400
    store.setdefault("tokens", {})[tok] = {
        "u": username,
        "r": role,
        "iat_ts": now,
        "exp_ts": exp,
    }
    _atomic_write_json(path, store)
    return tok


def validate_token(path: str, token: str) -> Optional[TokenUser]:
    if not token:
        return None
    store = _cleanup(_read_json(path))
    rec = (store.get("tokens") or {}).get(token)
    if not rec:
        _atomic_write_json(path, store)
        return None
    now = _now_ts()
    try:
        exp = int(rec.get("exp_ts") or 0)
    except Exception:
        exp = 0
    if exp and exp <= now:
        (store.get("tokens") or {}).pop(token, None)
        _atomic_write_json(path, store)
        return None
    u = str(rec.get("u") or "").strip()
    r = str(rec.get("r") or "viewer").strip() or "viewer"
    if not u:
        return None
    _atomic_write_json(path, store)
    return TokenUser(username=u, role=r)


def revoke_token(path: str, token: str) -> None:
    if not token:
        return
    store = _cleanup(_read_json(path))
    tokens = store.get("tokens") or {}
    tokens.pop(token, None)
    store["tokens"] = tokens
    _atomic_write_json(path, store)
