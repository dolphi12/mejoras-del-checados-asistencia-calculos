
from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class AttendanceRules:
    # Lunch rule
    lunch_threshold_minutes: int = 60
    lunch_discount_minutes_if_within: int = 30
    lunch_threshold_inclusive: bool = True
    lunch_mode: str = "fixed_if_within_else_full"  # fixed_if_within_else_full | full | none

    # Dinner rule
    apply_dinner_deduction: bool = True

    # Permissions rule
    apply_permissions_deduction: bool = True

    # Overtime rule
    overtime_threshold_minutes: int = 8 * 60
    compute_overtime: bool = True

    # Misc
    clamp_negative_to_zero: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "AttendanceRules":
        # Keep forward-compatible defaults; ignore unknown keys.
        base = AttendanceRules()
        kw = {}
        for k in base.to_dict().keys():
            if k in d:
                kw[k] = d[k]
        # sanitize
        def _int(x, default):
            try:
                return int(x)
            except Exception:
                return default

        kw["lunch_threshold_minutes"] = _int(kw.get("lunch_threshold_minutes", base.lunch_threshold_minutes), base.lunch_threshold_minutes)
        kw["lunch_discount_minutes_if_within"] = _int(kw.get("lunch_discount_minutes_if_within", base.lunch_discount_minutes_if_within), base.lunch_discount_minutes_if_within)
        kw["overtime_threshold_minutes"] = _int(kw.get("overtime_threshold_minutes", base.overtime_threshold_minutes), base.overtime_threshold_minutes)

        lm = str(kw.get("lunch_mode", base.lunch_mode)).strip()
        if lm not in ("fixed_if_within_else_full", "full", "none"):
            lm = base.lunch_mode
        kw["lunch_mode"] = lm

        for b in ("lunch_threshold_inclusive", "apply_dinner_deduction", "apply_permissions_deduction", "compute_overtime", "clamp_negative_to_zero"):
            kw[b] = bool(kw.get(b, getattr(base, b)))

        return AttendanceRules(**kw)


def rules_path(data_dir: str) -> str:
    return os.path.join(data_dir, "attendance_rules.json")


def ensure_rules_file(data_dir: str) -> str:
    p = rules_path(data_dir)
    if os.path.isfile(p):
        return p
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(AttendanceRules().to_dict(), f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return p


def load_rules(data_dir: str) -> AttendanceRules:
    p = ensure_rules_file(data_dir)
    try:
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            return AttendanceRules.from_dict(d)
    except Exception:
        return AttendanceRules()
    return AttendanceRules()


def save_rules(data_dir: str, rules: AttendanceRules) -> None:
    p = ensure_rules_file(data_dir)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(rules.to_dict(), f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
