from __future__ import annotations

import json
import os
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Tuple


def _now_tag() -> str:
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


def load_raw_config(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


def write_raw_config(path: str, cfg: Dict[str, Any]) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(p)


def backup_config(path: str) -> str:
    p = Path(path)
    if not p.exists():
        return ""
    bak = p.with_suffix(p.suffix + f".bak_{_now_tag()}")
    bak.write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
    return str(bak)


def deep_merge(dst: Dict[str, Any], src: Dict[str, Any]) -> Dict[str, Any]:
    out = deepcopy(dst)
    for k, v in (src or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def update_config(path: str, patch: Dict[str, Any]) -> Tuple[str, str]:
    """Apply a patch (deep merge) to config.json.

    Returns: (backup_path, config_path)
    """
    current = load_raw_config(path)
    bak = backup_config(path)
    merged = deep_merge(current, patch)
    write_raw_config(path, merged)
    return bak, path


def list_backups(path: str) -> list[str]:
    p = Path(path)
    parent = p.parent
    if not parent.exists():
        return []
    patt = p.name + ".bak_"
    items = [str(x) for x in parent.glob(p.name + ".bak_*")]
    return sorted(items, reverse=True)


def restore_backup(path: str, backup_path: str) -> str:
    bp = Path(backup_path)
    if not bp.exists():
        raise FileNotFoundError("Backup no existe")
    p = Path(path)
    p.write_text(bp.read_text(encoding="utf-8"), encoding="utf-8")
    return str(p)
