from __future__ import annotations

import json
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


DEFAULT_AREAS = ["000-", "F-", "FT-"]


def _utcnow_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _store_path(data_dir: str) -> str:
    return os.path.join(data_dir, "web_areas.json")


def _normalize_id(x: Any) -> str:
    return str(x).strip() if x is not None else ""


def _normalize_code(x: Any) -> str:
    return str(x).strip() if x is not None else ""


def _ensure_list(obj: Any) -> List[Any]:
    return obj if isinstance(obj, list) else []


def _migrate_area_item(a: Any) -> Optional[Dict[str, Any]]:
    """Be tolerant with older schema versions.

    Supported legacy shapes:
      - {"name": "...", "ids": [...]}
      - {"code": "...", "members": [...]}
      - "F-" (string code)
    """
    if a is None:
        return None
    if isinstance(a, str):
        code = _normalize_code(a)
        if not code:
            return None
        return {
            "code": code,
            "name": code,
            "order": 10_000,
            "members": [],
            "created_at_utc": _utcnow_iso(),
        }
    if not isinstance(a, dict):
        return None

    out = dict(a)

    # Legacy: {name, ids}
    if not _normalize_code(out.get("code")) and _normalize_code(out.get("name")):
        out["code"] = _normalize_code(out.get("name"))

    if "members" not in out or not isinstance(out.get("members"), list):
        if isinstance(out.get("ids"), list):
            out["members"] = list(out.get("ids") or [])
        else:
            out["members"] = []

    # Ensure fields
    code = _normalize_code(out.get("code"))
    if not code:
        return None
    out["code"] = code
    if not _normalize_code(out.get("name")):
        out["name"] = code
    try:
        out["order"] = int(out.get("order") or 10_000)
    except Exception:
        out["order"] = 10_000
    if "created_at_utc" not in out:
        out["created_at_utc"] = _utcnow_iso()

    # Normalize members: strings, unique, preserve order
    seen = set()
    memb: List[str] = []
    for m in _ensure_list(out.get("members")):
        mid = _normalize_id(m)
        if mid and mid not in seen:
            memb.append(mid)
            seen.add(mid)
    out["members"] = memb

    return out


def _ensure_schema(doc: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(doc, dict):
        doc = {}
    if "version" not in doc:
        doc["version"] = 1
    raw_areas = doc.get("areas")
    migrated: List[Dict[str, Any]] = []
    for a in _ensure_list(raw_areas):
        ma = _migrate_area_item(a)
        if ma:
            migrated.append(ma)
    doc["areas"] = migrated

    if "updated_at_utc" not in doc:
        doc["updated_at_utc"] = _utcnow_iso()
    return doc


def load_areas(data_dir: str) -> Dict[str, Any]:
    p = _store_path(data_dir)
    if not os.path.exists(p):
        doc = {"version": 1, "areas": [], "updated_at_utc": _utcnow_iso()}
        save_areas(data_dir, doc)
        return doc
    try:
        with open(p, "r", encoding="utf-8") as f:
            doc = json.load(f)
        # migrate on load (and persist)
        doc = _ensure_schema(doc)
        save_areas(data_dir, doc)
        return doc
    except Exception:
        doc = {"version": 1, "areas": [], "updated_at_utc": _utcnow_iso()}
        save_areas(data_dir, doc)
        return doc


def save_areas(data_dir: str, doc: Dict[str, Any]) -> None:
    doc = _ensure_schema(doc)
    doc["updated_at_utc"] = _utcnow_iso()
    p = _store_path(data_dir)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)


def ensure_default_areas(data_dir: str, defaults: Optional[List[str]] = None) -> Dict[str, Any]:
    """Ensure required default areas always exist.

    Fix: do NOT use `(doc.get("areas") or [])` to mutate, because an empty list is falsy
    and creates a temporary list. We always mutate `doc["areas"]` directly.
    """
    defaults = defaults or list(DEFAULT_AREAS)
    doc = load_areas(data_dir)

    if not isinstance(doc.get("areas"), list):
        doc["areas"] = []
    areas: List[Dict[str, Any]] = doc["areas"]

    existing = {str(a.get("code", "")).strip() for a in areas if isinstance(a, dict)}
    changed = False
    order_base = 10
    for i, code in enumerate(defaults):
        code = _normalize_code(code)
        if not code or code in existing:
            continue
        areas.append(
            {
                "code": code,
                "name": code,
                "order": order_base + i,
                "members": [],
                "created_at_utc": _utcnow_iso(),
            }
        )
        existing.add(code)
        changed = True

    if changed:
        save_areas(data_dir, doc)
    return doc


def list_areas(data_dir: str) -> List[Dict[str, Any]]:
    doc = ensure_default_areas(data_dir)
    areas = [a for a in (doc.get("areas") or []) if isinstance(a, dict) and _normalize_code(a.get("code"))]
    areas.sort(key=lambda x: (int(x.get("order") or 10_000), str(x.get("code") or "")))
    return areas


def upsert_area(data_dir: str, code: str, name: Optional[str] = None, order: Optional[int] = None) -> None:
    code = _normalize_code(code)
    if not code:
        raise ValueError("code requerido")
    doc = load_areas(data_dir)

    if not isinstance(doc.get("areas"), list):
        doc["areas"] = []
    areas: List[Dict[str, Any]] = doc["areas"]

    found = None
    for a in areas:
        if isinstance(a, dict) and _normalize_code(a.get("code")) == code:
            found = a
            break
    if found is None:
        found = {
            "code": code,
            "name": _normalize_code(name) or code,
            "order": int(order or 10_000),
            "members": [],
            "created_at_utc": _utcnow_iso(),
        }
        areas.append(found)
    else:
        if name is not None:
            found["name"] = _normalize_code(name) or code
        if order is not None:
            try:
                found["order"] = int(order)
            except Exception:
                pass

    save_areas(data_dir, doc)


def delete_area(data_dir: str, code: str) -> None:
    code = _normalize_code(code)
    if not code:
        return
    doc = load_areas(data_dir)
    areas = [a for a in (doc.get("areas") or []) if not (isinstance(a, dict) and _normalize_code(a.get("code")) == code)]
    doc["areas"] = areas
    save_areas(data_dir, doc)


def _remove_member_from_area(area: Dict[str, Any], emp_id: str) -> bool:
    members = area.get("members")
    if not isinstance(members, list):
        area["members"] = []
        return False
    before = len(members)
    area["members"] = [m for m in members if _normalize_id(m) != emp_id]
    return len(area["members"]) != before


def add_members(
    data_dir: str,
    code: str,
    employee_ids: List[str],
    unique_across_areas: bool = True,
) -> Dict[str, Any]:
    code = _normalize_code(code)
    if not code:
        raise ValueError("code requerido")

    doc = ensure_default_areas(data_dir)
    if not isinstance(doc.get("areas"), list):
        doc["areas"] = []
    areas: List[Dict[str, Any]] = doc["areas"]

    target = None
    for a in areas:
        if isinstance(a, dict) and _normalize_code(a.get("code")) == code:
            target = a
            break
    if target is None:
        upsert_area(data_dir, code=code, name=code)
        doc = load_areas(data_dir)
        areas = doc.get("areas") or []
        for a in areas:
            if isinstance(a, dict) and _normalize_code(a.get("code")) == code:
                target = a
                break
    if target is None:
        raise RuntimeError("No se pudo crear/ubicar el área")

    moved: List[Tuple[str, str]] = []  # (emp_id, from_code)
    added: List[str] = []
    cleaned = [_normalize_id(x) for x in (employee_ids or [])]
    cleaned = [x for x in cleaned if x]

    if not isinstance(target.get("members"), list):
        target["members"] = []
    cur = {_normalize_id(x) for x in (target.get("members") or [])}

    for emp_id in cleaned:
        if unique_across_areas:
            for a in areas:
                if not isinstance(a, dict):
                    continue
                acode = _normalize_code(a.get("code"))
                if acode and acode != code:
                    if _remove_member_from_area(a, emp_id):
                        moved.append((emp_id, acode))
        if emp_id not in cur:
            target["members"].append(emp_id)
            cur.add(emp_id)
            added.append(emp_id)

    save_areas(data_dir, doc)
    return {"added": added, "moved": moved}


def remove_member(data_dir: str, code: str, employee_id: str) -> bool:
    code = _normalize_code(code)
    emp_id = _normalize_id(employee_id)
    if not code or not emp_id:
        return False
    doc = load_areas(data_dir)
    changed = False
    for a in (doc.get("areas") or []):
        if isinstance(a, dict) and _normalize_code(a.get("code")) == code:
            changed = _remove_member_from_area(a, emp_id)
            break
    if changed:
        save_areas(data_dir, doc)
    return changed


def remove_member_everywhere(data_dir: str, employee_id: str) -> List[str]:
    emp_id = _normalize_id(employee_id)
    if not emp_id:
        return []
    doc = load_areas(data_dir)
    removed_from: List[str] = []
    for a in (doc.get("areas") or []):
        if not isinstance(a, dict):
            continue
        code = _normalize_code(a.get("code"))
        if code and _remove_member_from_area(a, emp_id):
            removed_from.append(code)
    if removed_from:
        save_areas(data_dir, doc)
    return removed_from


def members_for_areas(data_dir: str, codes: List[str]) -> List[str]:
    wanted = {_normalize_code(c) for c in (codes or []) if _normalize_code(c)}
    if not wanted:
        return []
    areas = list_areas(data_dir)
    out: List[str] = []
    seen = set()
    for a in areas:
        code = _normalize_code(a.get("code"))
        if code not in wanted:
            continue
        for m in (a.get("members") or []):
            mid = _normalize_id(m)
            if mid and mid not in seen:
                out.append(mid)
                seen.add(mid)
    return out


def ordered_employee_ids_for_areas(data_dir: str, codes: List[str], within_group_sort: str = "numeric") -> List[str]:
    """Return employee_ids ordered by area order, then within each area."""

    wanted = {_normalize_code(c) for c in (codes or []) if _normalize_code(c)}
    if not wanted:
        return []

    areas = list_areas(data_dir)
    out: List[str] = []
    seen = set()

    def _sort_key(x: str):
        if within_group_sort == "lex":
            return (1, x)
        if within_group_sort == "as_is":
            return (1, x)
        try:
            return (0, int(x))
        except Exception:
            return (1, x)

    for a in areas:
        code = _normalize_code(a.get("code"))
        if code not in wanted:
            continue
        members = [_normalize_id(m) for m in (a.get("members") or [])]
        members = [m for m in members if m]
        if within_group_sort in ("numeric", "lex"):
            members.sort(key=_sort_key)
        for m in members:
            if m not in seen:
                out.append(m)
                seen.add(m)
    return out
