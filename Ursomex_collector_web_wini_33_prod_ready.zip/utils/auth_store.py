from __future__ import annotations

import json
import os
import secrets
from dataclasses import dataclass
from datetime import datetime
from hashlib import pbkdf2_hmac
from pathlib import Path
from typing import Any, Dict, Optional


PBKDF2_ITERS = 240_000


def _now_utc() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _hash_password(password: str, salt_hex: str) -> str:
    dk = pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), PBKDF2_ITERS)
    return dk.hex()


@dataclass
class AuthResult:
    ok: bool
    username: str = ""
    role: str = ""
    error: str = ""


def default_store() -> Dict[str, Any]:
    # Default admin (must be changed on first use)
    salt = secrets.token_hex(16)
    return {
        "version": 1,
        "created_at_utc": _now_utc(),
        "users": {
            "admin": {
                "role": "admin",
                "salt": salt,
                "password_hash": _hash_password("admin", salt),
                "created_at_utc": _now_utc(),
                "must_change_password": True,
                "disabled": False,
            }
        },
        "audit": [],
    }


def load_store(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return default_store()
    return json.loads(p.read_text(encoding="utf-8"))


def save_store(path: str, store: Dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")


def ensure_store(path: str) -> Dict[str, Any]:
    store = load_store(path)
    if not Path(path).exists():
        save_store(path, store)
    return store


def authenticate(path: str, username: str, password: str) -> AuthResult:
    store = ensure_store(path)
    u = (store.get("users") or {}).get(username)
    if not u:
        return AuthResult(ok=False, error="Usuario o contraseña inválidos")
    if bool(u.get("disabled", False)):
        return AuthResult(ok=False, error="Usuario deshabilitado")

    salt = str(u.get("salt") or "")
    ph = str(u.get("password_hash") or "")
    if not salt or not ph:
        return AuthResult(ok=False, error="Usuario mal configurado")

    if _hash_password(password, salt) != ph:
        return AuthResult(ok=False, error="Usuario o contraseña inválidos")

    return AuthResult(ok=True, username=username, role=str(u.get("role") or "viewer"))


def set_password(path: str, username: str, new_password: str, require_change: bool = False) -> None:
    store = ensure_store(path)
    users = store.setdefault("users", {})
    if username not in users:
        raise ValueError("Usuario no existe")
    salt = secrets.token_hex(16)
    users[username]["salt"] = salt
    users[username]["password_hash"] = _hash_password(new_password, salt)
    users[username]["must_change_password"] = bool(require_change)
    users[username]["updated_at_utc"] = _now_utc()
    save_store(path, store)


def upsert_user(path: str, username: str, role: str, password: Optional[str] = None, disabled: bool = False) -> None:
    store = ensure_store(path)
    users = store.setdefault("users", {})
    u = users.get(username) or {}
    u["role"] = role
    u["disabled"] = bool(disabled)
    if "created_at_utc" not in u:
        u["created_at_utc"] = _now_utc()
    u["updated_at_utc"] = _now_utc()

    if password is not None:
        salt = secrets.token_hex(16)
        u["salt"] = salt
        u["password_hash"] = _hash_password(password, salt)
        u["must_change_password"] = False

    users[username] = u
    save_store(path, store)


def delete_user(path: str, username: str) -> None:
    store = ensure_store(path)
    users = store.get("users") or {}
    if username in users:
        del users[username]
    save_store(path, store)


def list_users(path: str) -> Dict[str, Any]:
    store = ensure_store(path)
    return store.get("users") or {}


def append_audit(path: str, actor: str, action: str, details: Dict[str, Any] | None = None) -> None:
    store = ensure_store(path)
    rec = {
        "ts_utc": _now_utc(),
        "actor": actor,
        "action": action,
        "details": details or {},
    }
    store.setdefault("audit", []).append(rec)
    # keep last 500
    store["audit"] = store["audit"][-500:]
    save_store(path, store)


def get_audit(path: str) -> list[dict[str, Any]]:
    store = ensure_store(path)
    return store.get("audit") or []
