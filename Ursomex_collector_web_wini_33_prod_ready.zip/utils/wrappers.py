from __future__ import annotations

import contextlib
import io
import csv
import json
import logging
import os
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime, date, timedelta, timedelta
from threading import Thread
from typing import Any, Deque, Dict, List, Optional, Tuple

from zoneinfo import ZoneInfo

from collector.config import load_config
from collector.constants import CHECADOR_LABEL
from collector.log import setup_logger
from collector.service.runner import CollectorService
from collector.service.backfill import (
    backfill_range,
    backfill_weekday,
    day_bounds_utc,
    local_window_to_utc,
    operational_week_bounds_utc,
)
from collector.service.fetch import fetch_from_device_range
from collector.service.import_jsonl import import_jsonl_file
from collector.service.import_corrections_excel import import_manual_corrections_excel
from collector.service.jornadas_indexer import ensure_jornadas_indexed_until, jornadas_to_export_rows
from collector.export.excel_exporter import export_excel_jornadas_summary

from utils.export_filter import (
    extract_employee_id_from_payload,
    filter_sort_records,
    postprocess_export,
)


class InMemoryLogHandler(logging.Handler):
    """Ring-buffer log handler (keeps last N formatted lines)."""

    def __init__(self, capacity: int = 2000):
        super().__init__(level=logging.INFO)
        self.capacity = int(capacity)
        self._buf: Deque[str] = deque(maxlen=self.capacity)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
        except Exception:
            msg = record.getMessage()
        self._buf.append(msg)

    def tail(self, n: int = 400) -> List[str]:
        n = int(n)
        if n <= 0:
            return []
        if n >= len(self._buf):
            return list(self._buf)
        return list(self._buf)[-n:]


@dataclass
class ServiceStatus:
    device_label: str
    device_ip: str
    today_local: str

    rrhh_today: int
    audit_today: int
    verify_total: int
    verify_invalid: int
    verify_valid: int
    verify_invalid_pct: float

    last_raw_event_time: str
    last_rrhh_event_time: str

    last_ping_utc: str
    last_ping_ok: str
    last_pull_utc: str
    last_pull_inserted: str

    page_cap: str

    raw_total: int
    processed_total: int

    patterns_employees: Optional[int] = None
    model_audit_rows: Optional[int] = None
    global_n: Optional[float] = None

    seasonality_v2: Optional[Dict[str, Any]] = None
    cluster_v2: Optional[Dict[str, Any]] = None
    weekly_snapshot: Optional[Dict[str, Any]] = None


class CollectorRuntime:
    """Runtime wrapper around CollectorService.

    Important: does NOT modify collector logic; it only orchestrates calls and captures logs.
    """

    def __init__(self, cfg_path: str = "config.json"):
        self.cfg_path = cfg_path
        self.cfg = load_config(cfg_path)

        log_dir = os.path.join(self.cfg.storage["data_dir"], "logs")
        self.logger = setup_logger(log_dir)

        self.log_handler = InMemoryLogHandler(capacity=5000)
        self.log_handler.setFormatter(logging.Formatter(fmt="%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
        if not any(isinstance(h, InMemoryLogHandler) for h in self.logger.handlers):
            self.logger.addHandler(self.log_handler)

        self.svc = CollectorService(self.cfg, self.logger)
        self._bg_thread: Optional[Thread] = None
        self._bg_mode: Optional[str] = None

    def close(self) -> None:
        self.stop_loop()
        try:
            self.svc.db.close()
        except Exception:
            pass

    @property
    def is_running(self) -> bool:
        return bool(self._bg_thread and self._bg_thread.is_alive())

    @property
    def bg_mode(self) -> Optional[str]:
        return self._bg_mode

    def start_loop(self, realtime: bool = False) -> str:
        if self.is_running:
            return "Servicio ya está corriendo."

        self._bg_mode = "realtime" if realtime else "normal"
        self._bg_thread = Thread(target=self.svc.run_forever, kwargs={"realtime": realtime}, daemon=True)
        self._bg_thread.start()
        return f"Servicio iniciado (modo={self._bg_mode})."

    def stop_loop(self) -> str:
        try:
            self.svc.stop()
        except Exception:
            pass

        if self._bg_thread:
            self._bg_thread.join(timeout=2)
        self._bg_mode = None
        return "Servicio detenido."

    def ping(self) -> bool:
        return self.svc.ping()

    def pull_once(self) -> int:
        return self.svc.pull_once()

    def _device_tz(self) -> ZoneInfo:
        return ZoneInfo(self.cfg.device_timezone)

    def local_today_iso(self) -> str:
        return datetime.now(self._device_tz()).date().isoformat()

    def status(self) -> ServiceStatus:
        today = self.local_today_iso()
        ip = self.cfg.device.get("ip", "")

        last_pull = self.svc.db.get_state("last_pull_utc") or ""
        last_ins = self.svc.db.get_state("last_pull_inserted") or ""
        last_ping = self.svc.db.get_state("last_ping_utc") or ""
        last_ping_ok = self.svc.db.get_state("last_ping_ok") or ""
        cap = self.svc.db.get_state("device_page_cap") or ""

        raw_total = int(self.svc.db.count_raw() or 0)
        proc_total = int(self.svc.db.count_processed() or 0)

        rrhh_today_n = int(self.svc.db.count_processed_by_date(today) or 0)
        audit_today_n = int(self.svc.db.count_raw_by_date(today) or 0)

        vm_counts = self.svc.db.get_verify_mode_counts_raw_by_date(today) or {}
        total = int(vm_counts.get("total", 0) or 0)
        invalid = int(vm_counts.get("invalid", 0) or 0)
        valid = int(vm_counts.get("valid", 0) or 0)
        invalid_pct = (invalid / total * 100.0) if total else 0.0

        last_raw_evt = self.svc.db.get_last_raw_event_time() or ""
        last_rrhh_evt = self.svc.db.get_last_processed_event_time() or ""

        patterns_employees = None
        model_audit_rows = None
        global_n = None
        seasonality_v2 = None
        cluster_v2 = None
        weekly_snapshot = None

        try:
            patterns_employees = int(self.svc.db.count_employee_jornada_states() or 0)
            model_audit_rows = int(self.svc.db.count_model_audit() or 0)
            gp = json.loads(self.svc.db.get_state("model_global_profile") or "{}") or {}
            global_n = float(gp.get("n") or 0.0)

            s2 = json.loads(self.svc.db.get_state("model_seasonality_v2_state") or "{}") or {}
            if isinstance(s2, dict) and bool(s2.get("enabled", False)):
                seasonality_v2 = s2

            c2 = json.loads(self.svc.db.get_state("model_cluster_v2_state") or "{}") or {}
            if isinstance(c2, dict) and bool(c2.get("enabled", False)):
                cluster_v2 = c2

            wa = self.svc.db.get_last_weekly_audit()
            if isinstance(wa, dict) and wa:
                weekly_snapshot = wa

        except Exception:
            pass

        return ServiceStatus(
            device_label=CHECADOR_LABEL,
            device_ip=str(ip),
            today_local=str(today),
            rrhh_today=rrhh_today_n,
            audit_today=audit_today_n,
            verify_total=total,
            verify_invalid=invalid,
            verify_valid=valid,
            verify_invalid_pct=float(invalid_pct),
            last_raw_event_time=str(last_raw_evt),
            last_rrhh_event_time=str(last_rrhh_evt),
            last_ping_utc=str(last_ping),
            last_ping_ok=str(last_ping_ok),
            last_pull_utc=str(last_pull),
            last_pull_inserted=str(last_ins),
            page_cap=str(cap),
            raw_total=raw_total,
            processed_total=proc_total,
            patterns_employees=patterns_employees,
            model_audit_rows=model_audit_rows,
            global_n=global_n,
            seasonality_v2=seasonality_v2,
            cluster_v2=cluster_v2,
            weekly_snapshot=weekly_snapshot,
        )

    # --- Data access helpers (used by Dashboard UI) ---

    def datasets_day(self, source: str, day: str):
        from collector.cli.dashboard import _datasets_day as _dd
        return _dd(self.svc, source, day)

    def datasets_window(self, source: str, start_local: str, end_local: str):
        from collector.cli.dashboard import _datasets_window as _dw
        return _dw(self.svc, source, start_local, end_local)

    # --- Backfill / Import ---

    def backfill_days(self, days: int, chunk_hours: int = 24) -> int:
        end_dt = datetime.utcnow().replace(microsecond=0)
        start_dt = end_dt - timedelta(days=int(days))
        return backfill_range(self.svc, start_dt, end_dt, chunk_hours=int(chunk_hours))

    def backfill_one_day(self, day: str, chunk_hours: int = 24) -> int:
        tz = self._device_tz()
        start_dt, end_dt = day_bounds_utc(day, tz)
        return backfill_range(self.svc, start_dt, end_dt, chunk_hours=int(chunk_hours))

    def backfill_range_days(self, start_day: str, end_day: str, chunk_hours: int = 24) -> int:
        tz = self._device_tz()
        start_dt, _ = day_bounds_utc(start_day, tz)
        _, end_dt = day_bounds_utc(end_day, tz)
        return backfill_range(self.svc, start_dt, end_dt, chunk_hours=int(chunk_hours))

    def backfill_weekday(self, weekday_name: str, days_back: int, chunk_hours: int = 24) -> int:
        return backfill_weekday(self.svc, weekday_name.upper(), int(days_back), chunk_hours=int(chunk_hours))

    def backfill_operational_week_containing(self, day: str, chunk_hours: int = 24) -> int:
        tz = self._device_tz()
        start_dt, end_dt = operational_week_bounds_utc(day, tz)
        return backfill_range(self.svc, start_dt, end_dt, chunk_hours=int(chunk_hours))

    def backfill_window(self, start_local: str, end_local: str, chunk_hours: int = 6) -> Tuple[int, str, str]:
        start_day, start_hhmm = start_local.split()
        end_day, end_hhmm = end_local.split()
        tz = self._device_tz()
        start_utc, end_utc = local_window_to_utc(start_day, start_hhmm, end_day, end_hhmm, tz)
        start_dt = datetime.fromisoformat(start_utc.replace("Z", ""))
        end_dt = datetime.fromisoformat(end_utc.replace("Z", ""))
        n = backfill_range(self.svc, start_dt, end_dt, chunk_hours=int(chunk_hours))
        return n, start_utc, end_utc

    def import_jsonl(self, jsonl_path: str, persist_to_db: bool = True) -> Tuple[int, int, int]:
        raw_n, rrhh_n, err_n = import_jsonl_file(
            self.svc,
            jsonl_path=jsonl_path,
            device_ip_fallback=self.cfg.device.get("ip"),
            persist_to_db=bool(persist_to_db),
        )
        return int(raw_n), int(rrhh_n), int(err_n)

    def import_corrections_excel_and_rebuild(self, excel_path: str) -> Dict[str, Any]:
        tz = self._device_tz()
        res = import_manual_corrections_excel(self.svc.db, excel_path)

        last_utc = (self.svc.db.get_last_processed_event_time_utc() or "").strip()
        if not last_utc:
            raise ValueError("No hay eventos procesados en la DB para rebuild")
        try:
            dt_last = datetime.fromisoformat(last_utc.replace("Z", ""))
        except Exception as e:
            raise ValueError(f"Formato inválido event_time_utc: {last_utc}") from e
        end_utc = (dt_last + timedelta(minutes=1)).isoformat(timespec="seconds") + "Z"

        cutoff = (self.cfg.operation.get("shift_cutoff") or "03:00").strip() or "03:00"
        break_max = int(self.cfg.export.get("break_max_minutes", 75))
        rest_min = int(self.cfg.export.get("min_rest_between_shifts_minutes", 240))
        debounce = int(self.cfg.export.get("debounce_minutes", 3))
        max_shift = int(self.cfg.export.get("max_shift_hours", 24))
        hybrid_close = self.cfg.export.get("hybrid_close", {}) or {}

        info = ensure_jornadas_indexed_until(
            self.svc.db,
            end_utc,
            device_tz=tz,
            cutoff_hhmm=cutoff,
            break_max_minutes=break_max,
            rest_min_minutes=rest_min,
            debounce_minutes=debounce,
            max_shift_hours=max_shift,
            rebuild=True,
            hybrid_close=hybrid_close,
        )

        return {
            "export_id": getattr(res, "export_id", ""),
            "imported": getattr(res, "imported", 0),
            "skipped": getattr(res, "skipped", 0),
            "errors": getattr(res, "errors", 0),
            "decisions": getattr(res, "decisions", None),
            "rebuild": info,
        }

    
        def rebuild_indexar_jornadas_range(self, start_op_date: str, end_op_date: str) -> Dict[str, Any]:
            """Rebuild/Index jornadas for a date range, preserving learned patterns.
    
            Mirrors the CLI option "REBUILD/INDEXAR JORNADAS":
    
            - Clears only computed jornadas & employee runtime state
            - Preserves learned patterns (patrones)
            - Forces re-index from (start_op_date - 1 day at shift_cutoff) until (end_op_date + 1 day at close_lookahead)
    
            Notes:
            - Uses minute/hour settings from config.web.json / config.json (export/operation sections)
            - Compatible with collector.service.jornadas_indexer.ensure_jornadas_indexed_until(...)
            """
            tz = self._device_tz()
    
            shift_cutoff = str(
                self.cfg.operation.get("shift_cutoff_hhmm")
                or self.cfg.operation.get("shift_cutoff")
                or "03:00"
            ).strip() or "03:00"
    
            close_lookahead = str(self.cfg.export.get("close_lookahead_hhmm") or "12:00").strip() or "12:00"
    
            break_max_minutes = int(self.cfg.export.get("break_max_minutes", 75))
            rest_min_minutes = int(self.cfg.export.get("min_rest_between_shifts_minutes", 240))
            debounce_minutes = int(self.cfg.export.get("debounce_minutes", 3))
            max_shift_hours = int(self.cfg.export.get("max_shift_hours", 24))
    
            hybrid_close = self.cfg.export.get("hybrid_close") or {}
    
            d0 = date.fromisoformat(str(start_op_date).strip())
            d1 = date.fromisoformat(str(end_op_date).strip())
            if d1 < d0:
                d0, d1 = d1, d0
    
            # 1) Clear computed jornadas only (keep patterns)
            self.svc.db.clear_jornadas(preserve_patterns=True)
            self.svc.db.reset_employee_state_preserve_patterns()
    
            # 2) Set index cursor to (d0 - 1) at shift_cutoff (UTC)
            ctx_date = d0 - timedelta(days=1)
            hh, mm = [int(x) for x in shift_cutoff.split(":", 1)]
            start_local = datetime(ctx_date.year, ctx_date.month, ctx_date.day, hh, mm, 0, tzinfo=tz)
            start_ctx_utc = (
                start_local.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"
            )
            self.svc.db.upsert_state("jornada_index_last_utc", start_ctx_utc)
    
            # 3) Index until (d1 + 1) at close_lookahead (UTC)
            hh2, mm2 = [int(x) for x in close_lookahead.split(":", 1)]
            end_local = datetime(d1.year, d1.month, d1.day, hh2, mm2, 0, tzinfo=tz) + timedelta(days=1)
            end_utc = end_local.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"
    
            info = ensure_jornadas_indexed_until(
                self.svc.db,
                end_utc_iso=end_utc,
                device_tz=tz,
                cutoff_hhmm=shift_cutoff,
                break_max_minutes=break_max_minutes,
                rest_min_minutes=rest_min_minutes,
                debounce_minutes=debounce_minutes,
                max_shift_hours=max_shift_hours,
                rebuild=False,
                hybrid_close=hybrid_close,
            )
    
            return {
                "start_ctx_utc": start_ctx_utc,
                "end_utc": end_utc,
                "indexed_until": end_utc,
                "ensure_info": info,
            }



# --- Export (stable) ---

    def export_daily_excel(self, op_day: str, source_label: str = "DB") -> str:
        tz = self._device_tz()

        cutoff = (self.cfg.operation.get("shift_cutoff") or "03:00").strip() or "03:00"
        break_max = int(self.cfg.export.get("break_max_minutes", 75))
        rest_min = int(self.cfg.export.get("min_rest_between_shifts_minutes", 240))
        debounce = int(self.cfg.export.get("debounce_minutes", 3))
        max_shift = int(self.cfg.export.get("max_shift_hours", 24))
        lookahead = (self.cfg.export.get("close_lookahead_hhmm", "12:00") or "12:00").strip()
        hybrid_close = self.cfg.export.get("hybrid_close", {}) or {}

        d0 = datetime.strptime(op_day, "%Y-%m-%d").date()
        end_day = (d0 + timedelta(days=1)).isoformat()

        h, m = [int(x) for x in lookahead.split(":")]
        end_local = datetime(d0.year, d0.month, d0.day, h, m, 0, tzinfo=tz) + timedelta(days=1)
        end_utc = end_local.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"

        ensure_jornadas_indexed_until(
            self.svc.db,
            end_utc,
            device_tz=tz,
            cutoff_hhmm=cutoff,
            break_max_minutes=break_max,
            rest_min_minutes=rest_min,
            debounce_minutes=debounce,
            max_shift_hours=max_shift,
            rebuild=False,
            hybrid_close=hybrid_close,
        )

        jornadas = self.svc.db.get_jornadas_by_op_date(op_day)
        rows = jornadas_to_export_rows(jornadas, collapse_single_event_blocks=True)

        out_dir = os.path.join(self.cfg.storage["data_dir"], "exports")
        template = self.cfg.export.get("excel_template", "") or ""
        name = f"Eventos-{op_day}_a_{end_day}_{source_label}"
        export_id = str(uuid.uuid4())

        meta = {
            "range_start_op": op_day,
            "range_end_op": op_day,
            "source_label": source_label,
            "file_name": f"{name}.xlsx",
        }

        extra = None
        adv = (hybrid_close or {}).get("advanced_learning") or {}
        adv_audit = (adv or {}).get("audit") or {}
        audit_export_excel = bool((adv_audit or {}).get("export_excel", False))
        if audit_export_excel:
            extra = {"AUDIT_MODEL": self.svc.db.get_model_audit_range(op_day, op_day)}

        # Log export (best-effort)
        try:
            self.svc.db.insert_export_log(
                export_id or f"EXPORT_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
                range_start_op=op_day,
                range_end_op=op_day,
                source_label=source_label,
                file_name=f"{name}.xlsx",
            )
        except Exception:
            pass

        return export_excel_jornadas_summary(
            jornadas_rows=rows,
            out_dir=out_dir,
            name=name,
            template_path=template,
            extra_sheets=extra,
            export_id=export_id,
            meta=meta,
        )

    def export_daily_excel_filtered(
        self,
        op_day: str,
        employee_ids: List[str],
        source_label: str = "DB",
        order_employee_ids: Optional[List[str]] = None,
    ) -> str:
        """Export diario y aplica un filtrado/ordenamiento en capa wrapper.

        - No modifica el exportador original.
        - No agrega columnas de grupo; solo filtra y ordena filas.
        """

        base_path = self.export_daily_excel(op_day, source_label=source_label)
        return postprocess_export(
            base_path,
            allowed_employee_ids=employee_ids,
            order_employee_ids=order_employee_ids,
            xlsx_sheet_names=("JORNADAS_CIERRE", "AUDIT_MODEL"),
            xlsx_header_candidates=("employee_id",),
        )



    def export_range_excel(self, start_op: str, end_op: str, source_label: str = "DB") -> str:
        """Exporta jornadas para un rango de op_date (inclusive) a Excel.

        Nota: se mantiene el exportador original; este wrapper solo orquesta el rango.
        El nombre del archivo conserva la convención del export diario (fin exclusivo = end_op + 1 día).
        """
        tz = self._device_tz()

        cutoff = (self.cfg.operation.get("shift_cutoff") or "03:00").strip() or "03:00"
        break_max = int(self.cfg.export.get("break_max_minutes", 75))
        rest_min = int(self.cfg.export.get("min_rest_between_shifts_minutes", 240))
        debounce = int(self.cfg.export.get("debounce_minutes", 3))
        max_shift = int(self.cfg.export.get("max_shift_hours", 24))
        lookahead = (self.cfg.export.get("close_lookahead_hhmm", "12:00") or "12:00").strip()
        hybrid_close = self.cfg.export.get("hybrid_close", {}) or {}

        d_start = datetime.strptime(start_op, "%Y-%m-%d").date()
        d_end = datetime.strptime(end_op, "%Y-%m-%d").date()
        if d_end < d_start:
            raise ValueError("end_op debe ser >= start_op")

        # Fin exclusivo (convención del export diario)
        end_day_excl = (d_end + timedelta(days=1)).isoformat()

        h, m = [int(x) for x in lookahead.split(":")]
        end_local = datetime(d_end.year, d_end.month, d_end.day, h, m, 0, tzinfo=tz) + timedelta(days=1)
        end_utc = end_local.astimezone(ZoneInfo("UTC")).replace(tzinfo=None).isoformat(timespec="seconds") + "Z"

        ensure_jornadas_indexed_until(
            self.svc.db,
            end_utc,
            device_tz=tz,
            cutoff_hhmm=cutoff,
            break_max_minutes=break_max,
            rest_min_minutes=rest_min,
            debounce_minutes=debounce,
            max_shift_hours=max_shift,
            rebuild=False,
            hybrid_close=hybrid_close,
        )

        rows: List[Dict[str, Any]] = []
        cur = d_start
        while cur <= d_end:
            jornadas = self.svc.db.get_jornadas_by_op_date(cur.isoformat())
            rows.extend(jornadas_to_export_rows(jornadas, collapse_single_event_blocks=True))
            cur = cur + timedelta(days=1)

        out_dir = os.path.join(self.cfg.storage["data_dir"], "exports")
        template = self.cfg.export.get("excel_template", "") or ""
        name = f"Eventos-{start_op}_a_{end_day_excl}_{source_label}"
        export_id = str(uuid.uuid4())

        meta = {
            "range_start_op": start_op,
            "range_end_op": end_op,
            "source_label": source_label,
            "file_name": f"{name}.xlsx",
        }

        extra = None
        adv = (hybrid_close or {}).get("advanced_learning") or {}
        adv_audit = (adv or {}).get("audit") or {}
        audit_export_excel = bool((adv_audit or {}).get("export_excel", False))
        if audit_export_excel:
            extra = {"AUDIT_MODEL": self.svc.db.get_model_audit_range(start_op, end_op)}

        # Log export (best-effort)
        try:
            self.svc.db.insert_export_log(
                export_id or f"EXPORT_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
                range_start_op=start_op,
                range_end_op=end_op,
                source_label=source_label,
                file_name=f"{name}.xlsx",
            )
        except Exception:
            pass

        return export_excel_jornadas_summary(
            jornadas_rows=rows,
            out_dir=out_dir,
            name=name,
            template_path=template,
            extra_sheets=extra,
            export_id=export_id,
            meta=meta,
        )

    def export_range_excel_filtered(
        self,
        start_op: str,
        end_op: str,
        employee_ids: List[str],
        source_label: str = "DB",
        order_employee_ids: Optional[List[str]] = None,
    ) -> str:
        base_path = self.export_range_excel(start_op, end_op, source_label=source_label)
        return postprocess_export(
            base_path,
            allowed_employee_ids=employee_ids,
            order_employee_ids=order_employee_ids,
            xlsx_sheet_names=("JORNADAS_CIERRE", "AUDIT_MODEL"),
            xlsx_header_candidates=("employee_id",),
        )

    def export_operational_week_excel(self, containing_day: str, source_label: str = "DB") -> str:
        """Exporta la semana operativa (Mié→Mar) que contiene `containing_day` (YYYY-MM-DD)."""
        d = datetime.strptime(containing_day, "%Y-%m-%d").date()
        wd = d.weekday()
        delta_to_wed = (wd - 2) % 7
        start_day = d - timedelta(days=delta_to_wed)
        start_op = start_day.isoformat()
        end_op = (start_day + timedelta(days=6)).isoformat()
        return self.export_range_excel(start_op, end_op, source_label=source_label)

    def export_operational_week_excel_filtered(
        self,
        containing_day: str,
        employee_ids: List[str],
        source_label: str = "DB",
        order_employee_ids: Optional[List[str]] = None,
    ) -> str:
        d = datetime.strptime(containing_day, "%Y-%m-%d").date()
        wd = d.weekday()
        delta_to_wed = (wd - 2) % 7
        start_day = d - timedelta(days=delta_to_wed)
        start_op = start_day.isoformat()
        end_op = (start_day + timedelta(days=6)).isoformat()
        return self.export_range_excel_filtered(start_op, end_op, employee_ids=employee_ids, source_label=source_label, order_employee_ids=order_employee_ids)

    def export_processed_csv_range(
        self,
        start_op: str,
        end_op: str,
        source_label: str = "DB",
        employee_ids: Optional[List[str]] = None,
        order_employee_ids: Optional[List[str]] = None,
    ) -> str:
        """Exporta processed_events (por op_date) a CSV. Filtra/ordena opcionalmente por employee_id."""
        d_start = datetime.strptime(start_op, "%Y-%m-%d").date()
        d_end = datetime.strptime(end_op, "%Y-%m-%d").date()
        if d_end < d_start:
            raise ValueError("end_op debe ser >= start_op")

        rows: List[Dict[str, Any]] = []
        cur = d_start
        while cur <= d_end:
            rows.extend(self.svc.db.get_processed_by_date(cur.isoformat()))
            cur = cur + timedelta(days=1)

        rows = filter_sort_records(
            rows,
            allowed_employee_ids=employee_ids,
            order_employee_ids=order_employee_ids,
            employee_getter=lambda r: str(r.get("employee_id") or "").strip(),
            time_getter=lambda r: str(r.get("event_time_utc") or ""),
        )

        out_dir = os.path.join(self.cfg.storage["data_dir"], "exports")
        os.makedirs(out_dir, exist_ok=True)
        name = f"Processed-{start_op}_a_{end_op}_{source_label}"
        out = os.path.join(out_dir, f"{name}.csv")
        headers = [
            "event_uid",
            "device_ip",
            "event_date",
            "event_time",
            "event_time_utc",
            "event_type",
            "employee_id",
            "employee_name",
            "raw_json",
        ]
        with open(out, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=headers)
            w.writeheader()
            for r in rows:
                w.writerow({k: r.get(k) for k in headers})
        return out

    def export_raw_csv_range(
        self,
        start_utc_iso: str,
        end_utc_iso: str,
        source_label: str = "DB",
        employee_ids: Optional[List[str]] = None,
        order_employee_ids: Optional[List[str]] = None,
    ) -> str:
        """Exporta raw_events por rango UTC a CSV. Si se pasa employee_ids, filtra parseando payload_json."""
        rows = self.svc.db.get_raw_by_utc_range(start_utc_iso, end_utc_iso)
        rows = filter_sort_records(
            rows,
            allowed_employee_ids=employee_ids,
            order_employee_ids=order_employee_ids,
            employee_getter=lambda r: extract_employee_id_from_payload(r.get("payload_json")),
            time_getter=lambda r: str(r.get("event_time_utc") or ""),
        )

        out_dir = os.path.join(self.cfg.storage["data_dir"], "exports")
        os.makedirs(out_dir, exist_ok=True)
        name = f"Raw-{start_utc_iso.replace(':','').replace('Z','')}_a_{end_utc_iso.replace(':','').replace('Z','')}_{source_label}"
        out = os.path.join(out_dir, f"{name}.csv")
        headers = ["device_ip", "event_time", "event_time_utc", "received_at", "payload_json"]
        with open(out, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=headers)
            w.writeheader()
            for r in rows:
                w.writerow({k: r.get(k) for k in headers})
        return out

@contextlib.contextmanager
def capture_stdout() -> Any:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        yield buf


