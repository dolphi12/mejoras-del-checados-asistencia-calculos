from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class SafeCommand:
    key: str
    title: str
    description: str


SAFE_COMMANDS = [
    SafeCommand("status", "Estado", "Métricas clave (DB, ping/pull, últimos eventos, modelos/patrones)."),
    SafeCommand("ping", "Ping", "Verifica conectividad con el checador (sin pull)."),
    SafeCommand("pull_once", "Pull (una vez)", "Ejecuta un pull incremental y guarda en DB."),
    SafeCommand("start_normal", "Iniciar servicio (normal)", "Loop en segundo plano con intervalo normal."),
    SafeCommand("start_realtime", "Iniciar servicio (realtime)", "Loop en segundo plano con intervalo realtime."),
    SafeCommand("stop", "Detener servicio", "Detiene el loop en segundo plano."),
]


def is_safe_command(cmd: str) -> bool:
    return cmd in {c.key for c in SAFE_COMMANDS}


def explain_blocked(cmd: str) -> str:
    return (
        "Comando bloqueado por modo seguro. "
        "La consola web solo permite operaciones del collector predefinidas (sin shell, sin eval)."
    )
