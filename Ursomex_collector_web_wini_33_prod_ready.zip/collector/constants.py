CHECADOR_LABEL = "Checador Asistencias"


DEFAULT_TIMEZONE = "America/Tijuana"
