from __future__ import annotations
import os


from dataclasses import dataclass
from typing import Any, Dict, Optional

import streamlit as st

from utils.auth_store import authenticate, append_audit, ensure_store, list_users, set_password
from utils.session_tokens import issue_token, revoke_token, store_path as sessions_store_path, validate_token


@dataclass
class SessionUser:
    username: str
    role: str


AUTH_QP_KEY = "auth"


def _qp_get() -> Dict[str, Any]:
    try:
        return st.experimental_get_query_params()  # type: ignore[attr-defined]
    except Exception:
        try:
            return dict(getattr(st, "query_params").to_dict())  # type: ignore[attr-defined]
        except Exception:
            return {}


def _qp_set(params: Dict[str, Any]) -> None:
    try:
        st.experimental_set_query_params(**params)  # type: ignore[attr-defined]
        return
    except Exception:
        pass
    try:
        getattr(st, "query_params").from_dict(params)  # type: ignore[attr-defined]
    except Exception:
        return


def _qp_clear_key(key: str) -> None:
    qp = _qp_get()
    if key in qp:
        qp.pop(key, None)
        _qp_set(qp)


def _store_path(data_dir: str) -> str:
    return os.path.join(data_dir, "web_users.json")


def current_user() -> Optional[SessionUser]:
    u = st.session_state.get("auth_user")
    if not isinstance(u, dict):
        return None
    if not u.get("username"):
        return None
    return SessionUser(username=u["username"], role=u.get("role", "viewer"))


def require_role(role: str) -> bool:
    u = current_user()
    if not u:
        return False
    if u.role == "admin":
        return True
    return u.role == role


def logout() -> None:
    tok = str(st.session_state.get("auth_token") or "").strip()
    data_dir = str(st.session_state.get("data_dir") or "").strip()
    if tok and data_dir:
        try:
            revoke_token(sessions_store_path(data_dir), tok)
        except Exception:
            pass
    st.session_state["auth_user"] = None
    st.session_state["auth_token"] = ""
    _qp_clear_key(AUTH_QP_KEY)


def _restore_from_token(data_dir: str) -> Optional[SessionUser]:
    if current_user():
        return current_user()
    qp = _qp_get()
    raw = qp.get(AUTH_QP_KEY)
    tok = ""
    if isinstance(raw, list) and raw:
        tok = str(raw[-1] or "")
    elif isinstance(raw, str):
        tok = raw
    tok = str(tok).strip()
    if not tok:
        return None
    tu = validate_token(sessions_store_path(data_dir), tok)
    if not tu:
        _qp_clear_key(AUTH_QP_KEY)
        return None
    st.session_state["auth_user"] = {"username": tu.username, "role": tu.role}
    st.session_state["auth_token"] = tok
    return SessionUser(username=tu.username, role=tu.role)


def _ensure_token_in_url() -> None:
    tok = str(st.session_state.get("auth_token") or "").strip()
    if not tok:
        return
    qp = _qp_get()
    cur = qp.get(AUTH_QP_KEY)
    cur_tok = ""
    if isinstance(cur, list) and cur:
        cur_tok = str(cur[-1] or "")
    elif isinstance(cur, str):
        cur_tok = cur
    if str(cur_tok).strip() == tok:
        return
    qp[AUTH_QP_KEY] = tok
    _qp_set(qp)


def login_panel(data_dir: str) -> Optional[SessionUser]:
    store_path = _store_path(data_dir)
    ensure_store(store_path)

    st.session_state["data_dir"] = data_dir

    restored = _restore_from_token(data_dir)
    if restored:
        _ensure_token_in_url()
        return restored

    u = current_user()
    if u:
        st.sidebar.markdown(f"**Sesión:** `{u.username}`  ")
        st.sidebar.markdown(f"**Rol:** `{u.role}`")
        if st.sidebar.button("Cerrar sesión", width="stretch"):
            logout()
            st.rerun()
        _ensure_token_in_url()
        return u

    st.sidebar.markdown("### Acceso")
    username = st.sidebar.text_input("Usuario", key="login_user")
    password = st.sidebar.text_input("Contraseña", type="password", key="login_pass")
    remember = st.sidebar.checkbox("Mantener sesión", value=True, help="Guarda un token de sesión para no pedir login al recargar.")

    if st.sidebar.button("Entrar", width="stretch"):
        res = authenticate(store_path, username.strip(), password)
        if res.ok:
            st.session_state["auth_user"] = {"username": res.username, "role": res.role}
            if remember:
                try:
                    tok = issue_token(sessions_store_path(data_dir), res.username, res.role, ttl_days=14)
                    st.session_state["auth_token"] = tok
                    qp = _qp_get()
                    qp[AUTH_QP_KEY] = tok
                    _qp_set(qp)
                except Exception:
                    st.session_state["auth_token"] = ""
                    _qp_clear_key(AUTH_QP_KEY)
            else:
                st.session_state["auth_token"] = ""
                _qp_clear_key(AUTH_QP_KEY)
            append_audit(store_path, res.username, "login", {})
            st.rerun()
        else:
            st.sidebar.error(res.error)

    return None


def must_change_password(data_dir: str, username: str) -> bool:
    store_path = _store_path(data_dir)
    store = ensure_store(store_path)
    u = (store.get("users") or {}).get(username) or {}
    return bool(u.get("must_change_password", False))


def password_change_form(data_dir: str, username: str) -> None:
    store_path = _store_path(data_dir)
    with st.expander("Cambiar contraseña", expanded=must_change_password(data_dir, username)):
        p1 = st.text_input("Nueva contraseña", type="password", key="pw_new1")
        p2 = st.text_input("Repite nueva contraseña", type="password", key="pw_new2")
        if st.button("Guardar contraseña", width="stretch"):
            if not p1 or len(p1) < 8:
                st.error("La contraseña debe tener al menos 8 caracteres.")
                return
            if p1 != p2:
                st.error("Las contraseñas no coinciden.")
                return
            set_password(store_path, username, p1, require_change=False)
            append_audit(store_path, username, "password_change", {})
            st.success("Contraseña actualizada.")
