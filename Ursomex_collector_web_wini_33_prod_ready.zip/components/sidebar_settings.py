from __future__ import annotations

import os

import streamlit as st

from utils.runtime_store import get_cfg_path, set_cfg_path


def render_sidebar_settings() -> None:
    """Common sidebar settings for all pages."""

    with st.sidebar:
        lp = os.path.join("static", "logo.png")
        if os.path.exists(lp):
            # `use_column_width` is deprecated; fill the column by using width="stretch" as per new API【968516149440567†L213-L223】
            st.image(lp, width="stretch")

        st.markdown("### Ajustes")

        cfg_path = st.text_input(
            "Ruta config.json",
            value=get_cfg_path(),
            help="Ruta relativa o absoluta al config.json del collector.",
        )
        if cfg_path and cfg_path != get_cfg_path():
            set_cfg_path(cfg_path)

        opts = ["ursomex", "minimalista", "tecnologico"]
        cur = str(st.session_state.get("theme", "ursomex"))
        idx = opts.index(cur) if cur in opts else 0
        theme = st.selectbox("Tema", opts, index=idx)
        st.session_state["theme"] = theme

        st.session_state["accent_color"] = st.color_picker(
            "Color acento",
            value=st.session_state.get("accent_color", "#2BBBAD"),
        )
