from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional


def tail_file(path: str, max_lines: int = 500) -> List[str]:
    p = Path(path)
    if not p.exists():
        return []
    try:
        with p.open("r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        return [ln.rstrip("\n") for ln in lines[-int(max_lines):]]
    except Exception:
        return []
