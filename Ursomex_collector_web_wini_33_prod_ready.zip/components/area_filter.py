from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

import streamlit as st

from utils.areas_store import list_areas, ordered_employee_ids_for_areas


_ID_SPLIT_RE = re.compile(r"[\s,;]+")


def parse_employee_ids(text: str) -> List[str]:
    if not text:
        return []
    out: List[str] = []
    for raw in _ID_SPLIT_RE.split(str(text).strip()):
        x = str(raw).strip()
        if x:
            out.append(x)
    # unique, preserve order
    seen = set()
    uniq: List[str] = []
    for x in out:
        if x not in seen:
            uniq.append(x)
            seen.add(x)
    return uniq


def render_area_filter(
    parent: Any,
    data_dir: str,
    key_prefix: str,
    title: str = "Filtro por áreas",
    *,
    default_order_by_area: bool = True,
    show_order_by_area: bool = True,
    show_within_sort: bool = True,
    show_manual_ids: bool = True,
) -> Dict[str, Any]:
    """
    UI reusable para:
      - seleccionar Áreas
      - (opcional) orden interno y orden por área
      - (opcional) IDs manuales

    Devuelve:
      - filter_active: bool
      - employee_ids: List[str] (unión, sin duplicados, en orden)
      - order_in_export: bool (si debe reordenar filas por este orden)
      - sel_areas, within_sort, manual_ids
    """
    parent.markdown(f"##### {title}")
    parent.caption("Selecciona áreas (grupos) para filtrar IDs. No agrega columnas al exportar.")

    areas = list_areas(data_dir)
    area_codes = [str(a.get("code") or "").strip() for a in areas]
    area_labels = {str(a.get("code") or "").strip(): str(a.get("name") or a.get("code") or "").strip() for a in areas}

    sel_areas = parent.multiselect(
        "Áreas",
        options=area_codes,
        default=[],
        format_func=lambda c: f"{area_labels.get(c, c)}",
        key=f"{key_prefix}__areas",
    )

    within_sort = "numeric"
    if show_within_sort:
        within_sort = parent.selectbox(
            "Orden dentro de área",
            ["numeric", "lex", "as_is"],
            index=0,
            key=f"{key_prefix}__within",
        )

    order_by_area = default_order_by_area
    if show_order_by_area:
        order_by_area = parent.checkbox(
            "Ordenar por área",
            value=default_order_by_area,
            key=f"{key_prefix}__order_by_area",
        )

    manual_ids_raw = ""
    if show_manual_ids:
        manual_ids_raw = parent.text_area(
            "IDs extra (opcional; coma/espacio/nueva línea)",
            value="",
            height=90,
            key=f"{key_prefix}__manual_ids",
        )

    ids_from_areas = ordered_employee_ids_for_areas(data_dir, sel_areas, within_group_sort=within_sort) if sel_areas else []
    manual_ids = parse_employee_ids(manual_ids_raw)

    filter_active = bool(sel_areas) or bool(manual_ids)

    final_ids: List[str] = []
    seen = set()
    for x in (ids_from_areas + manual_ids):
        x = str(x).strip()
        if x and x not in seen:
            final_ids.append(x)
            seen.add(x)

    if filter_active:
        parent.caption(f"Filtro activo | IDs seleccionados: {len(final_ids)}")
    else:
        parent.caption("Sin filtro por áreas/IDs")
    if final_ids:
        parent.code(", ".join(final_ids[:40]) + (" …" if len(final_ids) > 40 else ""))

    return {
        "filter_active": filter_active,
        "employee_ids": final_ids,
        "order_in_export": bool(order_by_area),
        "order_employee_ids": (final_ids if order_by_area else None),
        "sel_areas": sel_areas,
        "within_sort": within_sort,
        "manual_ids": manual_ids,
    }
