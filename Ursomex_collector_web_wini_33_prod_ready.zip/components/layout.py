from __future__ import annotations

import base64
from pathlib import Path
from typing import Optional

import streamlit as st


def _b64_image(path: str) -> str:
    p = Path(path)
    if not p.exists():
        return ""
    data = p.read_bytes()
    return base64.b64encode(data).decode("utf-8")


def inject_global_css() -> None:
    """Global CSS + font. Safe to call multiple times."""
    css_path = Path("static") / "styles.css"
    css = css_path.read_text(encoding="utf-8") if css_path.exists() else ""

    st.markdown(
        """
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
""",
        unsafe_allow_html=True,
    )

    if css:
        st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def render_topbar(title: str, subtitle: str = "", *, show_user: bool = True) -> None:
    """Header bar with logo + title. Uses local static/logo.png if present."""

    logo_b64 = _b64_image(str(Path("static") / "logo.png"))
    logo_html = (
        f"<img class='ursomex-logo' src='data:image/png;base64,{logo_b64}'/>" if logo_b64 else ""
    )

    user_html = ""
    if show_user:
        u = st.session_state.get("auth_user")
        if isinstance(u, dict) and u.get("username"):
            role = str(u.get("role") or "viewer")
            uname = str(u.get("username") or "")
            user_html = f"<div class='ursomex-userchip'><span class='ursomex-user'>{uname}</span><span class='ursomex-role'>{role}</span></div>"

    subtitle_html = f"<div class='ursomex-subtitle'>{subtitle}</div>" if subtitle else ""

    st.markdown(
        f"""
<div class='ursomex-topbar'>
  <div class='ursomex-topbar-left'>
    {logo_html}
    <div>
      <div class='ursomex-title'>{title}</div>
      {subtitle_html}
    </div>
  </div>
  <div class='ursomex-topbar-right'>
    {user_html}
  </div>
</div>
""",
        unsafe_allow_html=True,
    )


def section_header(title: str, desc: str = "") -> None:
    """Section header. The description is short by design (no long parentheses)."""
    st.markdown(f"<div class='ursomex-section-title'>{title}</div>", unsafe_allow_html=True)
    if desc:
        st.markdown(f"<div class='ursomex-section-desc'>{desc}</div>", unsafe_allow_html=True)
