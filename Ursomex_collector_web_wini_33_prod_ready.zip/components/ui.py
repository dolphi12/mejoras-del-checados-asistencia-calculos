from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Optional


def load_css(css_path: str) -> str:
    p = Path(css_path)
    if not p.exists():
        return ""
    return p.read_text(encoding="utf-8")


def theme_css(theme_name: str, accent_hex: str = "#2BBBAD") -> str:
    """Returns a small CSS snippet to parameterize accent color."""
    accent_hex = (accent_hex or "#2BBBAD").strip()
    return f"""
    <style>
      :root {{
        --accent: {accent_hex};
        --brand-50: rgba(43,187,173,0.10);
        --brand-100: rgba(43,187,173,0.16);
        --brand-200: rgba(43,187,173,0.22);
        --brand-500: var(--accent);
        --ink: rgba(15, 23, 42, 1);
        --muted: rgba(15, 23, 42, 0.70);
        --border: rgba(15, 23, 42, 0.10);
      }}
      .ursomex-accent {{ color: var(--accent); }}
      .ursomex-pill {{
        display:inline-block; padding: 0.2rem 0.55rem; border-radius: 999px;
        background: rgba(0,0,0,0.05);
        border: 1px solid rgba(0,0,0,0.08);
        font-size: 0.85rem;
      }}
      .ursomex-card {{
        border: 1px solid rgba(0,0,0,0.08);
        border-radius: 14px;
        padding: 0.9rem 1rem;
        background: rgba(255,255,255,0.8);
      }}
      .ursomex-grid {{
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 0.75rem;
      }}
      @media (max-width: 1100px) {{
        .ursomex-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
      }}
      @media (max-width: 600px) {{
        .ursomex-grid {{ grid-template-columns: repeat(1, minmax(0, 1fr)); }}
      }}
      .ursomex-metric-title {{ font-size: 0.85rem; opacity: 0.75; margin-bottom: 0.25rem; }}
      .ursomex-metric-value {{ font-size: 1.45rem; font-weight: 700; }}
      .ursomex-muted {{ opacity: 0.7; }}
      .ursomex-ok {{ color: #14804A; }}
      .ursomex-bad {{ color: #B42318; }}

      .urs-kpi {{
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 0.95rem 1rem;
        background: rgba(255,255,255,0.92);
        box-shadow: 0 10px 30px rgba(15,23,42,0.06);
      }}
      .urs-kpi-title {{ font-size: 0.82rem; color: var(--muted); margin-bottom: 0.25rem; }}
      .urs-kpi-row {{ display:flex; align-items:baseline; justify-content:space-between; gap: 0.5rem; }}
      .urs-kpi-value {{ font-size: 1.55rem; font-weight: 750; letter-spacing: 0.2px; color: var(--ink); }}
      .urs-kpi-sub {{ font-size: 0.85rem; color: var(--muted); margin-top: 0.25rem; }}
      .urs-kpi-delta {{
        font-size: 0.78rem;
        padding: 0.12rem 0.5rem;
        border-radius: 999px;
        border: 1px solid rgba(15,23,42,0.10);
        background: rgba(15,23,42,0.03);
        color: var(--muted);
        white-space: nowrap;
      }}
      .urs-kpi-delta.up {{ background: rgba(20,128,74,0.10); border-color: rgba(20,128,74,0.20); color: #14804A; }}
      .urs-kpi-delta.down {{ background: rgba(180,35,24,0.10); border-color: rgba(180,35,24,0.20); color: #B42318; }}
    </style>
    """


def metric_card(title: str, value: str, subtitle: str = "", status: str = "neutral") -> str:
    cls = ""
    if status == "ok":
        cls = "ursomex-ok"
    elif status == "bad":
        cls = "ursomex-bad"
    return f"""
      <div class="ursomex-card">
        <div class="ursomex-metric-title">{title}</div>
        <div class="ursomex-metric-value {cls}">{value}</div>
        <div class="ursomex-muted" style="margin-top:0.25rem; font-size:0.85rem;">{subtitle}</div>
      </div>
    """


def kpi_card(title: str, value: str, subtitle: str = "", delta_text: str = "") -> str:
    delta_html = ""
    if delta_text:
        d = delta_text.strip()
        cls = ""
        if d.startswith("+"):
            cls = "up"
        elif d.startswith("-"):
            cls = "down"
        delta_html = f"<span class='urs-kpi-delta {cls}'>{d}</span>"
    return f"""
      <div class="urs-kpi">
        <div class="urs-kpi-title">{title}</div>
        <div class="urs-kpi-row">
          <div class="urs-kpi-value">{value}</div>
          {delta_html}
        </div>
        <div class="urs-kpi-sub">{subtitle}</div>
      </div>
    """
