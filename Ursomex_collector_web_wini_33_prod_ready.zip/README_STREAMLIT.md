# URSOMEX Collector Web (Streamlit)

Este directorio añade un **frontend web** para el proyecto existente del **collector**, sin modificar el código del módulo `collector` ni el ecosistema de aprendizaje.

## Principios (lo que NO se toca)
- El paquete `collector/` se conserva **sin cambios**.
- No se altera la lógica de entrenamiento/evaluación/persistencia.
- La web solo orquesta llamadas mediante **wrappers** en `utils/wrappers.py`.

## Estructura
- `app.py`: Home + ajustes + navegación.
- `pages/01_Dashboard.py`: métricas, tendencias, tablas.
- `pages/02_Consola.py`: consola segura (ping/pull/start/stop/backfill/export/import) + logs.
- `pages/03_Admin.py`: usuarios/roles + edición de `config.json` por patches + rollback.
- `utils/areas_store.py`: gestión de **áreas** (grupos de employee_id) para filtrado/orden de exportación.
- `utils/attendance_rules.py`: reglas editables del cálculo de asistencia (persisten en `attendance_rules.json`).
- `utils/attendance_calc.py`: motor de cálculo (puro, testeable) con soporte de permisos detallados.
- `utils/wrappers.py`: adaptadores que llaman a funciones originales.
- `static/styles.css`: CSS custom.

## Requisitos
- Python 3.10+
- Dependencias del proyecto + Streamlit.

Instalación recomendada:
```bash
python -m venv .venv
# Windows:
.\.venv\Scripts\activate
# Linux/Mac:
# source .venv/bin/activate

pip install -r requirements-web.txt
```

## Configuración
- Por defecto la web usa `config.web.json` (demo) para arrancar.
- En producción, cambia en la barra lateral la ruta a tu `config.json` real.

**Usuarios web**
- Se guardan en: `<data_dir>/web_users.json`
- Usuario inicial: `admin` / `admin` (se marca como *must_change_password* en el primer uso).

**Sesión persistente**
- Si marcas **Mantener sesión**, la web crea un token y lo conserva en la URL (query param `auth`).
- Los tokens se guardan en: `<data_dir>/web_sessions.json` con expiración (por defecto 14 días).
- Para cerrar, usa **Cerrar sesión** (revoca el token).

**Áreas / Grupos**
- Se guardan en: `<data_dir>/web_areas.json`
- Se crean por defecto: `000-`, `F-`, `FT-` (puedes agregar más).
- Uso: en **cualquier exportación** (Excel diario, Excel por rango, Excel semana operativa y CSVs) puedes filtrar por áreas y ordenar por el orden del área.
- Nota: los archivos exportados **no incluyen** columnas de área; el área solo afecta el **filtrado** y el **orden** de salida.; solo se filtran/ordenan filas.

### Añadir nuevos exports “areas-ready” (sin duplicar lógica)
La lógica de filtrado/orden por employee_id está centralizada en:

- `utils/export_filter.py` → `postprocess_export()` para post-procesar archivos (Excel/CSV)
- `utils/export_filter.py` → `filter_sort_records()` para filtrar/ordenar listas de registros antes de escribir

Patrón recomendado para un nuevo export que devuelve un archivo:
1) Genera el archivo normalmente (sin filtros).
2) Si hay filtro activo (employee_ids), llama `postprocess_export(path, employee_ids, order_employee_ids)`.

## Ejecutar
```bash
streamlit run app.py
```

## Checklist rápido de verificación
1. Inicia sesión.
2. Dashboard muestra totales y últimos eventos.
3. Consola:
   - `Ping` responde.
   - `Pull (una vez)` inserta eventos (si el checador está accesible).
   - `Exportar Excel diario` genera archivo descargable.
   - (Opcional) Filtra por áreas y confirma que solo salen esos IDs.
4. Admin:
   - Crear un usuario `operator`.
   - Cambiar parámetros de `export.hybrid_close` y guardar.
   - Ver backups y restaurar uno.
   - Configurar áreas y asignar IDs.

## Producción (guía breve)
### Opción A: Reverse proxy (recomendado)
- Ejecuta Streamlit en un puerto interno (ej. 8501).
- Pone Nginx/Apache/IIS como reverse proxy con TLS.
- Asegura que el `data_dir` sea el mismo que usa el collector (para DB/logs).

**Recomendación:** en producción usa TLS y acceso de red controlado (LAN/VPN). El token de sesión via URL es práctico para evitar re-login al recargar, pero se debe tratar como un secreto.

Ejemplo (Nginx, conceptual):
- `proxy_pass http://127.0.0.1:8501;`
- Habilita `proxy_set_header Upgrade $http_upgrade;` si usas websockets.

### Opción B: Servicio
- **Windows**: NSSM/Task Scheduler
  - Target: `streamlit`
  - Args: `run app.py --server.port 8501 --server.address 127.0.0.1`
- **Linux**: systemd
  - ExecStart: `.../python -m streamlit run app.py --server.port 8501 --server.address 127.0.0.1`

## Rollback / Reversión
Este frontend no sustituye la consola original.

- Para volver a la operación anterior:
  1) Detén Streamlit.
  2) Ejecuta tus scripts originales (ej. `python ejecutar.py`).

- Si cambiaste `config.json` desde Admin:
  - En `Admin > Config > Rollback` restaura un `config.json.bak_YYYYMMDD_HHMMSS`.

## Tests de integración (básicos)
```bash
pytest -q
```
Los tests verifican equivalencia funcional (wrappers vs llamadas directas a DB) y que el export genere un Excel.


## Cálculo de Asistencia (nuevo)
- Ubicación: `pages/04_Calculo_Asistencia.py`
- Lee archivos exportados del colector desde `storage/exports/`.
- Permite editar tiempos (entrada/comida/cena/salida/permisos) y recalcula en tiempo real.
- Exporta un Excel con columnas: ID, FECHA, NOMBRE, SALIDA A COMER, REGRESO DE COMER, SALIDA A CENAR, REGRESO DE CENAR, SALIDA, PERMISO, DESCUENTO NO LABORADO, TIEMPO TRABAJADO, HORAS EXTRA.


## Asistencia (reglas editables)
- Archivo de reglas: `<data_dir>/attendance_rules.json`
- Se puede modificar desde:
  - **Admin → Asistencia | Reglas** (persistente, auditable)
  - **Cálculo de Asistencia → sidebar (solo admin)** (aplicar/guardar/reset)

### Permisos detallados (avanzado)
En **Cálculo de Asistencia** puedes editar permisos como pares `Salida/Regreso` (ej. `13:00-13:30;14:00-14:10`).
El detalle no se exporta; solo se usa para calcular el total `PERMISO` y el descuento correspondiente.

También puedes usar **Autodetectar permisos** (por registro o para todos) para rellenar automáticamente los pares a partir de `_EVENTOS` (los eventos originales exportados por el colector), y luego solo corregir lo necesario antes de exportar.


## Auditoría (Asistencia)
- Archivo: `<data_dir>/audit/attendance_audit.jsonl`
- Registro append-only (JSONL) con: ediciones de tiempos (por celda), permisos detallados, cambios de reglas y exportaciones.
- Visualización/descarga: **Admin → Auditoría → Asistencia**.
